const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read rooms", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("rooms").get());
});

test("Authenticated user: can read and create rooms", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("rooms").get());

  await assertSucceeds(
    aliceDb.collection("rooms").doc("room_general").set({
      id: "room_general",
      title: "General Chat",
      topic: "Welcome",
      createdBy: ALICE_UID
    })
  );
});

test("Authenticated user: can create message with matching senderId", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("rooms").doc("room_general").collection("messages").doc("msg_1").set({
      id: "msg_1",
      roomId: "room_general",
      senderId: ALICE_UID,
      senderName: "Alice",
      text: "Hello everyone!"
    })
  );
});

test("Authenticated user: cannot impersonate other user senderId in messages", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("rooms").doc("room_general").collection("messages").doc("msg_fake").set({
      id: "msg_fake",
      roomId: "room_general",
      senderId: BOB_UID,
      senderName: "Bob",
      text: "I am Bob"
    })
  );
});
