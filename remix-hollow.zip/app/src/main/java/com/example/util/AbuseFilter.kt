package com.example.util

import java.util.regex.Pattern

object AbuseFilter {

    private val profanityList = listOf(
        // English abusive words
        "fuck", "fucking", "fucked", "fucker", "fuk", "bitch", "bitches", "bastard", 
        "asshole", "dick", "pussy", "whore", "slut", "cunt", "shit", "nigger", "nigga",
        "retard", "idiot", "dumbass", "motherfucker", "jackass", "scam", "spam", "hate"
    )

    private val pattern: Pattern by lazy {
        val regexString = profanityList.joinToString("|") { Pattern.quote(it) }
        Pattern.compile("\\b($regexString)\\b", Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE)
    }

    /**
     * Checks if the given text contains any abusive words (English or Urdu).
     */
    fun containsProfanity(text: String): Boolean {
        if (text.isBlank()) return false
        val matcher = pattern.matcher(text)
        return matcher.find()
    }

    /**
     * Filters profane and abusive words from the text, replacing them with asterisks (***).
     */
    fun filterProfanity(text: String): String {
        if (text.isBlank()) return text
        val matcher = pattern.matcher(text)
        val sb = StringBuffer()
        while (matcher.find()) {
            val matched = matcher.group()
            val replacement = "*".repeat(matched.length.coerceAtLeast(3))
            matcher.appendReplacement(sb, replacement)
        }
        matcher.appendTail(sb)
        return sb.toString()
    }

    /**
     * Sanitizes message, returns sanitized text and whether abuse was detected.
     */
    fun sanitize(text: String): Pair<String, Boolean> {
        val hasAbuse = containsProfanity(text)
        val cleanText = if (hasAbuse) filterProfanity(text) else text
        return cleanText to hasAbuse
    }
}
