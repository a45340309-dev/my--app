package com.example.util

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    ENGLISH("en", "English", "EN")
}

object Strings {
    fun appTitle(lang: AppLanguage = AppLanguage.ENGLISH) = "HOLLOW"
    fun slogan(lang: AppLanguage = AppLanguage.ENGLISH) = "Live Voice Lounge & Social Network"
    
    fun onlineStatus(lang: AppLanguage = AppLanguage.ENGLISH, count: Int) = 
        "$count Active Online"

    fun trendingTitle(lang: AppLanguage = AppLanguage.ENGLISH) = "🔥 Trending Across Pakistan"

    // Tabs
    fun tabRooms(lang: AppLanguage = AppLanguage.ENGLISH) = "Rooms"
    fun tabDirect(lang: AppLanguage = AppLanguage.ENGLISH) = "Direct Chats"
    fun tabMessages(lang: AppLanguage = AppLanguage.ENGLISH) = "Messages"
    fun tabProfile(lang: AppLanguage = AppLanguage.ENGLISH) = "Profile"
    fun tabMedia(lang: AppLanguage = AppLanguage.ENGLISH) = "Media Stream"

    // Categories
    fun catAll(lang: AppLanguage = AppLanguage.ENGLISH) = "All"
    fun catCities(lang: AppLanguage = AppLanguage.ENGLISH) = "Cities"
    fun catJobs(lang: AppLanguage = AppLanguage.ENGLISH) = "Jobs"
    fun catUniversity(lang: AppLanguage = AppLanguage.ENGLISH) = "University"
    fun catRishta(lang: AppLanguage = AppLanguage.ENGLISH) = "Social & Matrimony"
    fun catCricket(lang: AppLanguage = AppLanguage.ENGLISH) = "Cricket"
    fun catMemes(lang: AppLanguage = AppLanguage.ENGLISH) = "Memes"
    fun catGaming(lang: AppLanguage = AppLanguage.ENGLISH) = "Gaming"

    // Safe Space & Girls Protection
    fun safeSpaceBadge(lang: AppLanguage = AppLanguage.ENGLISH) = "🛡️ Safe Space for All Users"
    fun reportUser(lang: AppLanguage = AppLanguage.ENGLISH) = "Report User"
    fun blockUser(lang: AppLanguage = AppLanguage.ENGLISH) = "Block User"
    fun reportSubmitted(lang: AppLanguage = AppLanguage.ENGLISH) = "Report submitted to admin for immediate review."

    // Actions
    fun newRoom(lang: AppLanguage = AppLanguage.ENGLISH) = "New Room"
    fun searchPlaceholder(lang: AppLanguage = AppLanguage.ENGLISH) = "Search cities, jobs, or interest rooms..."
    fun typeMessage(lang: AppLanguage = AppLanguage.ENGLISH) = "Type a message..."
    fun adminPanel(lang: AppLanguage = AppLanguage.ENGLISH) = "Admin Panel"
    fun signOut(lang: AppLanguage = AppLanguage.ENGLISH) = "Sign Out"
}
