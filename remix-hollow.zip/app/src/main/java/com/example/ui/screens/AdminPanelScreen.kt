package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatRoom
import com.example.data.model.Message
import com.example.data.model.User
import com.example.ui.components.UserAvatar
import com.example.ui.theme.BusyRed
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.HollowCyan
import com.example.ui.theme.HollowCyanGlow
import com.example.ui.theme.HollowIndigo
import com.example.ui.theme.HollowMagenta
import com.example.ui.theme.HollowViolet
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TikTokRed
import com.example.ui.viewmodel.ChatViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val currentEmail = Firebase.auth.currentUser?.email
    val isAdmin = currentEmail?.equals("ahmadking32ha@gmail.com", ignoreCase = true) == true

    if (!isAdmin) {
        AccessDeniedView(userEmail = currentEmail, onBack = onBack)
        return
    }

    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val allRooms by viewModel.allRooms.collectAsStateWithLifecycle()
    val mediaMessages by viewModel.mediaStream.collectAsStateWithLifecycle()
    val allReports by viewModel.allReports.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Overview, 1: Users, 2: Rooms, 3: Messages, 4: Reports

    // Dialog States
    var userToMove by remember { mutableStateOf<User?>(null) }
    var userToBlockToggle by remember { mutableStateOf<User?>(null) }
    var roomToDelete by remember { mutableStateOf<ChatRoom?>(null) }
    var messageToDelete by remember { mutableStateOf<Message?>(null) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(listOf(HollowMagenta, HollowViolet))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Hollow Admin Panel",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Logged in: $currentEmail",
                                fontSize = 10.sp,
                                color = HollowCyan
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tabs
            val pendingCount = allReports.count { it.status == "pending" }
            val tabs = listOf(
                "Overview",
                "Users (${allUsers.size})",
                "Rooms (${allRooms.size})",
                "Messages",
                "Safety Reports ($pendingCount)"
            )
            SecondaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = SurfaceDark,
                contentColor = HollowCyan,
                indicator = {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(selectedTab),
                        color = HollowCyan,
                        height = 3.dp
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == 4 && pendingCount > 0) TikTokRed else TextPrimaryDark
                            )
                        }
                    )
                }
            }

            when (selectedTab) {
                0 -> AdminOverviewContent(
                    allUsers = allUsers,
                    allRooms = allRooms,
                    mediaMessages = mediaMessages,
                    viewModel = viewModel,
                    onNavigateTab = { selectedTab = it }
                )
                1 -> AdminUsersContent(
                    users = allUsers,
                    rooms = allRooms,
                    onBlockToggle = { userToBlockToggle = it },
                    onMoveToRoom = { userToMove = it }
                )
                2 -> AdminRoomsContent(
                    rooms = allRooms,
                    onDeleteRoom = { roomToDelete = it }
                )
                3 -> AdminMessagesContent(
                    rooms = allRooms,
                    viewModel = viewModel,
                    onDeleteMessage = { messageToDelete = it }
                )
                4 -> AdminReportsContent(
                    reports = allReports,
                    onBanUser = { report ->
                        viewModel.toggleUserBlock(report.reportedUserId, false)
                        viewModel.updateReportStatus(report.id, "banned")
                    },
                    onDismissReport = { report ->
                        viewModel.updateReportStatus(report.id, "resolved")
                    }
                )
            }
        }
    }

    // Move User Dialog
    userToMove?.let { user ->
        MoveUserDialog(
            user = user,
            rooms = allRooms,
            onDismiss = { userToMove = null },
            onConfirmMove = { targetRoom ->
                viewModel.moveUserToRoom(user, targetRoom)
                userToMove = null
            }
        )
    }

    // Block/Unblock User Dialog
    userToBlockToggle?.let { user ->
        val willBlock = !user.isBlocked
        AlertDialog(
            onDismissRequest = { userToBlockToggle = null },
            containerColor = SurfaceDark,
            title = {
                Text(
                    text = if (willBlock) "Block User?" else "Unblock User?",
                    color = TextPrimaryDark,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (willBlock)
                        "Blocking ${user.displayName} will prevent them from sending messages or participating in rooms."
                    else
                        "Unblocking ${user.displayName} will restore their access to chat rooms.",
                    color = TextSecondaryDark,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.toggleUserBlock(user.userId, user.isBlocked)
                        userToBlockToggle = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (willBlock) BusyRed else OnlineGreen,
                        contentColor = Color.White
                    )
                ) {
                    Text(if (willBlock) "Block User" else "Unblock User")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { userToBlockToggle = null }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            }
        )
    }

    // Delete Room Dialog
    roomToDelete?.let { room ->
        AlertDialog(
            onDismissRequest = { roomToDelete = null },
            containerColor = SurfaceDark,
            title = {
                Text("Delete Room #${room.title}?", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Are you sure you want to delete this room? All active real-time connections and room messages will be permanently removed.",
                    color = TextSecondaryDark,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRoomByAdmin(room.id)
                        roomToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BusyRed, contentColor = Color.White)
                ) {
                    Text("Delete Room")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { roomToDelete = null }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            }
        )
    }

    // Delete Message Dialog
    messageToDelete?.let { msg ->
        AlertDialog(
            onDismissRequest = { messageToDelete = null },
            containerColor = SurfaceDark,
            title = {
                Text("Delete Message?", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Delete message from ${msg.senderName}: \"${msg.text.take(60)}\"?",
                    color = TextSecondaryDark,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMessageByAdmin(msg.roomId, msg.id)
                        messageToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BusyRed, contentColor = Color.White)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { messageToDelete = null }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            }
        )
    }
}

@Composable
fun AccessDeniedView(userEmail: String?, onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(CardBackgroundDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(20.dp))
                .padding(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Access Denied",
                tint = BusyRed,
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Admin Access Denied",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "This area is restricted exclusively to ahmadking32ha@gmail.com.\n\nCurrent account: ${userEmail ?: "Not logged in"}",
                fontSize = 12.sp,
                color = TextSecondaryDark,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = HollowCyan, contentColor = Color(0xFF031625)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Return to Hollow", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AdminOverviewContent(
    allUsers: List<User>,
    allRooms: List<ChatRoom>,
    mediaMessages: List<Message>,
    viewModel: ChatViewModel,
    onNavigateTab: (Int) -> Unit
) {
    val blockedCount = allUsers.count { it.isBlocked }
    val officialHostCode by viewModel.officialHostCode.collectAsStateWithLifecycle()
    var editingCode by remember(officialHostCode) { mutableStateOf(officialHostCode) }
    var codeSavedNotice by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Badshah PK Official Host Passcode Control Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B160C)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFFD700).copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("👑", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Badshah PK Official Host Passcode",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD700),
                                fontSize = 13.5.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TikTokRed
                        ) {
                            Text(
                                text = "LIVE 9 PM",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Change the official passcode for Host entry (e.g. PK-8842, PK-SF1-88, PK-FINAL-77).",
                        fontSize = 11.5.sp,
                        color = Color(0xFFD4AF37).copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        androidx.compose.material3.OutlinedTextField(
                            value = editingCode,
                            onValueChange = {
                                editingCode = it.uppercase()
                                codeSavedNotice = false
                            },
                            singleLine = true,
                            textStyle = TextStyle(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            ),
                            placeholder = { Text("e.g. PK-8842", color = Color.Gray, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFD700),
                                unfocusedBorderColor = Color(0xFFFFD700).copy(alpha = 0.5f),
                                focusedContainerColor = Color(0xFF0F0B05),
                                unfocusedContainerColor = Color(0xFF0F0B05)
                            )
                        )

                        Button(
                            onClick = {
                                if (editingCode.isNotBlank()) {
                                    viewModel.updateOfficialHostCode(editingCode.trim())
                                    codeSavedNotice = true
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFD700),
                                contentColor = Color.Black
                            )
                        ) {
                            Text("Update Code", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    if (codeSavedNotice) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "✓ Passcode updated to $officialHostCode successfully!",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = OnlineGreen
                        )
                    }
                }
            }
        }
        item {
            Text(
                text = "System Metrics",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = HollowCyan
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Total Users",
                    value = allUsers.size.toString(),
                    subtitle = "${allUsers.count { it.isOnline }} online",
                    color = HollowCyan,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateTab(1) }
                )
                MetricCard(
                    title = "Blocked Users",
                    value = blockedCount.toString(),
                    subtitle = if (blockedCount > 0) "Action required" else "Clean",
                    color = if (blockedCount > 0) BusyRed else OnlineGreen,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateTab(1) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Active Rooms",
                    value = allRooms.size.toString(),
                    subtitle = "Community channels",
                    color = HollowIndigo,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateTab(2) }
                )
                MetricCard(
                    title = "Media Drops",
                    value = mediaMessages.size.toString(),
                    subtitle = "Photos & voice notes",
                    color = HollowMagenta,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateTab(3) }
                )
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = OnlineGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Admin Authority Privileges",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Delete any room: Instantly remove community or custom rooms\n" +
                                "• Move users: Reassign any participant to another room channel\n" +
                                "• Block users: Revoke user ability to send messages across all rooms\n" +
                                "• Message moderation: Delete bad or inappropriate messages in any room",
                        fontSize = 12.sp,
                        color = TextSecondaryDark,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, fontSize = 11.sp, color = TextSecondaryDark)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 10.sp, color = TextSecondaryDark)
        }
    }
}

@Composable
fun AdminUsersContent(
    users: List<User>,
    rooms: List<ChatRoom>,
    onBlockToggle: (User) -> Unit,
    onMoveToRoom: (User) -> Unit
) {
    if (users.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No users found", color = TextSecondaryDark)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(users, key = { it.userId }) { user ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (user.isBlocked) BusyRed.copy(alpha = 0.5f) else CardBorderDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            UserAvatar(
                                name = user.displayName,
                                colorHex = user.avatarColorHex,
                                size = 42.dp,
                                showOnlineBadge = true,
                                isOnline = user.isOnline
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = user.displayName,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark
                                    )
                                    if (user.isBlocked) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = BusyRed.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "BLOCKED",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = BusyRed,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = user.handle + (if (user.email != null) " • ${user.email}" else ""),
                                    fontSize = 11.sp,
                                    color = TextSecondaryDark,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (user.assignedRoomId != null) {
                                    val assignedRoom = rooms.find { it.id == user.assignedRoomId }
                                    Text(
                                        text = "Assigned: #${assignedRoom?.title ?: user.assignedRoomId}",
                                        fontSize = 10.sp,
                                        color = HollowCyan
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Move to Room Button
                            OutlinedButton(
                                onClick = { onMoveToRoom(user) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DriveFileMove,
                                    contentDescription = null,
                                    tint = HollowCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Move to Room", fontSize = 11.sp, color = HollowCyan)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Block / Unblock Button
                            Button(
                                onClick = { onBlockToggle(user) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (user.isBlocked) OnlineGreen else BusyRed,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(
                                    imageVector = if (user.isBlocked) Icons.Default.CheckCircle else Icons.Default.Block,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (user.isBlocked) "Unblock" else "Block",
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminRoomsContent(
    rooms: List<ChatRoom>,
    onDeleteRoom: (ChatRoom) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(rooms, key = { it.id }) { room ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "#${room.title}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = SurfaceVariantDark
                            ) {
                                Text(
                                    text = room.category,
                                    fontSize = 10.sp,
                                    color = HollowCyan,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = room.topic,
                            fontSize = 12.sp,
                            color = TextSecondaryDark,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${room.memberCount} members • ID: ${room.id}",
                            fontSize = 10.sp,
                            color = TextSecondaryDark
                        )
                    }

                    IconButton(
                        onClick = { onDeleteRoom(room) },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(BusyRed.copy(alpha = 0.15f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Room",
                            tint = BusyRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminMessagesContent(
    rooms: List<ChatRoom>,
    viewModel: ChatViewModel,
    onDeleteMessage: (Message) -> Unit
) {
    var selectedRoomId by remember { mutableStateOf(rooms.firstOrNull()?.id ?: "") }
    var expandedRoomDropdown by remember { mutableStateOf(false) }

    val currentRoom = rooms.find { it.id == selectedRoomId } ?: rooms.firstOrNull()
    val roomMessages by viewModel.activeRoomMessages.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        // Room Filter selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Select Room to Moderate:",
                fontSize = 12.sp,
                color = TextSecondaryDark
            )

            Box {
                OutlinedButton(
                    onClick = { expandedRoomDropdown = true },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "#${currentRoom?.title ?: "Select Room"}",
                        fontSize = 12.sp,
                        color = HollowCyan
                    )
                }

                DropdownMenu(
                    expanded = expandedRoomDropdown,
                    onDismissRequest = { expandedRoomDropdown = false }
                ) {
                    rooms.forEach { r ->
                        DropdownMenuItem(
                            text = { Text("#${r.title}") },
                            onClick = {
                                selectedRoomId = r.id
                                viewModel.openRoom(r.id)
                                expandedRoomDropdown = false
                            }
                        )
                    }
                }
            }
        }

        // Messages list in selected room
        if (roomMessages.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No messages in this room", color = TextSecondaryDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(roomMessages, key = { it.id }) { msg ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = msg.senderName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = HollowCyan
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(msg.timestamp))
                                    Text(
                                        text = timeStr,
                                        fontSize = 10.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (msg.mediaType == "image") "📷 [Photo] " + msg.text else msg.text,
                                    fontSize = 13.sp,
                                    color = TextPrimaryDark,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            IconButton(
                                onClick = { onDeleteMessage(msg) },
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(BusyRed.copy(alpha = 0.15f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Bad Message",
                                    tint = BusyRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MoveUserDialog(
    user: User,
    rooms: List<ChatRoom>,
    onDismiss: () -> Unit,
    onConfirmMove: (ChatRoom) -> Unit
) {
    var selectedRoom by remember { mutableStateOf(rooms.firstOrNull()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = {
            Text("Move ${user.displayName} to Room", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(
                    "Select the destination room to reassign ${user.displayName}:",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.height(200.dp)) {
                    items(rooms) { r ->
                        val isSelected = r.id == selectedRoom?.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) HollowCyan.copy(alpha = 0.2f) else SurfaceVariantDark)
                                .clickable { selectedRoom = r }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "#${r.title}",
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) HollowCyan else TextPrimaryDark
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { selectedRoom?.let { onConfirmMove(it) } },
                enabled = selectedRoom != null,
                colors = ButtonDefaults.buttonColors(containerColor = HollowCyan, contentColor = Color(0xFF031625))
            ) {
                Text("Confirm Move")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondaryDark)
            }
        }
    )
}

@Composable
fun AdminReportsContent(
    reports: List<com.example.data.model.UserReport>,
    onBanUser: (com.example.data.model.UserReport) -> Unit,
    onDismissReport: (com.example.data.model.UserReport) -> Unit
) {
    if (reports.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = OnlineGreen,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("No safety reports filed.", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                Text("Hollow community is safe and clean.", color = TextSecondaryDark, fontSize = 12.sp)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reports, key = { it.id }) { report ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (report.status == "pending") TikTokRed.copy(alpha = 0.5f) else CardBorderDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (report.status == "pending") TikTokRed.copy(alpha = 0.2f) else OnlineGreen.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = report.status.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (report.status == "pending") TikTokRed else OnlineGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            val timeStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(report.timestamp))
                            Text(text = timeStr, fontSize = 10.sp, color = TextSecondaryDark)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Reported User: ${report.reportedUserName}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Text(
                            text = "Reason: ${report.reason}",
                            fontSize = 12.sp,
                            color = TikTokRed,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (report.details.isNotBlank()) {
                            Text(
                                text = "Details: \"${report.details}\"",
                                fontSize = 12.sp,
                                color = TextSecondaryDark
                            )
                        }
                        Text(
                            text = "Reporter: ${report.reporterName}",
                            fontSize = 10.sp,
                            color = TextSecondaryDark
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedButton(
                                onClick = { onDismissReport(report) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Dismiss", fontSize = 11.sp, color = TextSecondaryDark)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onBanUser(report) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = TikTokRed, contentColor = Color.White),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ban & Block User", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

