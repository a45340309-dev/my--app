package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HollowCardDark
import com.example.ui.theme.HollowDeepBlack
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowGreenGlow
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.HollowNeonPurpleBright
import com.example.ui.theme.TikTokRed

@Composable
fun PasswordScreen(
    title: String = "Private Room Password",
    onBack: () -> Unit,
    onSuccess: (String) -> Unit,
    onCreateHostRoom: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    var enteredCode by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSetMode by remember { mutableStateOf(false) }

    fun onKeyClick(key: String) {
        errorMessage = null
        when (key) {
            "CLEAR" -> {
                enteredCode = ""
            }
            "BACK" -> {
                if (enteredCode.isNotEmpty()) {
                    enteredCode = enteredCode.dropLast(1)
                }
            }
            else -> {
                if (enteredCode.length < 4) {
                    val newCode = enteredCode + key
                    enteredCode = newCode
                    if (newCode.length == 4) {
                        if (isSetMode) {
                            // User sets 4-digit code and creates room
                            onCreateHostRoom?.invoke(newCode)
                        } else {
                            // Verify 4-digit code (default code: 7890)
                            if (newCode == "7890") {
                                onSuccess(newCode)
                            } else {
                                errorMessage = "Incorrect password! Try 7890 or set your own."
                            }
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        containerColor = HollowDeepBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HollowDeepBlack)
        ) {
            // Ambient neon purple #8A2BE2 and blue #00BFFF glow gradients
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0x358A2BE2),
                                Color(0x2200BFFF),
                                Color.Transparent
                            ),
                            center = Offset(540f, 200f),
                            radius = 700f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Bar with Back Arrow
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF161624))
                            .testTag("password_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = title,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Lock Icon with glowing background
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0x338A2BE2), Color(0x2200BFFF))
                            )
                        )
                        .border(
                            1.5.dp,
                            if (errorMessage != null) TikTokRed else HollowNeonPurple,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = if (errorMessage != null) TikTokRed else HollowNeonPurpleBright,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Subtitle / instructions
                Text(
                    text = if (isSetMode) "Set your 4-digit room password" else "Enter 4-digit code to join private room",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (isSetMode) "Friends will use this PIN to join your lounge" else "Friends only • Safe & encrypted entry",
                    fontSize = 12.sp,
                    color = Color(0xFFA0A0B2),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // 4 EMPTY BOXES ON TOP FOR DIGITS
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (i in 0 until 4) {
                        val digit = enteredCode.getOrNull(i)
                        val isFilled = digit != null
                        val isCurrentBox = enteredCode.length == i

                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    when {
                                        errorMessage != null -> Color(0xFF2C1018)
                                        isFilled -> Color(0xFF1E1A2E)
                                        isCurrentBox -> Color(0xFF18182A)
                                        else -> Color(0xFF14141F)
                                    }
                                )
                                .border(
                                    width = if (isFilled || isCurrentBox) 2.dp else 1.2.dp,
                                    brush = when {
                                        errorMessage != null -> SolidColor(TikTokRed)
                                        isFilled -> Brush.sweepGradient(
                                            listOf(HollowNeonPurpleBright, HollowNeonBlueSky, HollowNeonPurpleBright)
                                        )
                                        isCurrentBox -> SolidColor(HollowNeonBlueSky)
                                        else -> SolidColor(Color(0xFF2E2E40))
                                    },
                                    shape = RoundedCornerShape(16.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isFilled) {
                                Text(
                                    text = digit.toString(),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            } else if (isCurrentBox) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(HollowNeonBlueSky)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Error Message Notice
                AnimatedVisibility(visible = errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = TikTokRed.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, TikTokRed)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TikTokRed,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                // Quick Hint / Mode Toggle
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1F1C12),
                        border = BorderStroke(1.dp, HollowGold.copy(alpha = 0.6f)),
                        modifier = Modifier.clickable {
                            enteredCode = "7890"
                            onSuccess("7890")
                        }
                    ) {
                        Text(
                            text = "💡 Quick Code: 7890",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = HollowGold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1C1428),
                        border = BorderStroke(1.dp, HollowNeonPurple.copy(alpha = 0.6f)),
                        modifier = Modifier.clickable {
                            isSetMode = !isSetMode
                            enteredCode = ""
                            errorMessage = null
                        }
                    ) {
                        Text(
                            text = if (isSetMode) "Switch to Join 🔑" else "Set New PIN 👑",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = HollowNeonPurpleBright,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // CUSTOM NUMBER KEYPAD 0-9 WITH NEON GLOWING EFFECT
                val keypadRows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("CLEAR", "0", "BACK")
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    keypadRows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            row.forEach { key ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(58.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(HollowCardDark)
                                        .border(
                                            width = 1.2.dp,
                                            brush = when (key) {
                                                "CLEAR" -> SolidColor(Color(0xFF4A2530))
                                                "BACK" -> SolidColor(Color(0xFF2C2C46))
                                                else -> Brush.verticalGradient(
                                                    listOf(Color(0xFF382A52), Color(0xFF1E2838))
                                                )
                                            },
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        .clickable { onKeyClick(key) }
                                        .testTag("keypad_key_$key"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    when (key) {
                                        "CLEAR" -> {
                                            Text(
                                                text = "C",
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Black,
                                                color = TikTokRed
                                            )
                                        }
                                        "BACK" -> {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                                contentDescription = "Backspace",
                                                tint = Color(0xFFA0A0C0),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        else -> {
                                            Text(
                                                text = key,
                                                fontSize = 22.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
