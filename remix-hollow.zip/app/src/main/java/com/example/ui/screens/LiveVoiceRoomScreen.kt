package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Tag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.Message
import com.example.data.model.User
import com.example.ui.components.UserAvatar
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonBlue
import com.example.ui.theme.HollowNeonPink
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.HollowNeonPurpleBright
import com.example.ui.theme.HollowShinyBlack
import com.example.ui.theme.HollowSpeakingGreen
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokRed
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

data class VoiceParticipant(
    val id: String,
    val name: String,
    val role: String, // "host", "speaker", "listener"
    val isSpeaking: Boolean = false,
    val level: Int = 12,
    val avatarColorHex: String = "#8A2BE2",
    val isCurrentUser: Boolean = false
)

data class FloatingHeart(
    val id: Long,
    val startXFraction: Float,
    val color: Color
)

@Composable
fun LiveVoiceRoomScreen(
    viewModel: ChatViewModel,
    onNavigateTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val userLevel by viewModel.userLevel.collectAsStateWithLifecycle()
    val userXp by viewModel.userXp.collectAsStateWithLifecycle()
    val dailyHeartsLeft by viewModel.dailyHeartsLeft.collectAsStateWithLifecycle()
    val isMicMuted by viewModel.isMicMuted.collectAsStateWithLifecycle()
    val speakRequestStatus by viewModel.speakRequestStatus.collectAsStateWithLifecycle()
    val floatingHeartsTrigger by viewModel.floatingHeartsTrigger.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val roomMessages by viewModel.activeRoomMessages.collectAsStateWithLifecycle()
    val activeRoom by viewModel.activeRoom.collectAsStateWithLifecycle()
    val userHostedRoomIds by viewModel.userHostedRoomIds.collectAsStateWithLifecycle()
    val isHollowDostInRoom by viewModel.isHollowDostInRoom.collectAsStateWithLifecycle()
    val isHollowDostSpeaking by viewModel.isHollowDostSpeaking.collectAsStateWithLifecycle()
    val hollowDostCountdownSec by viewModel.hollowDostCountdownSec.collectAsStateWithLifecycle()
    val otherHumansInRoomCount by viewModel.otherHumansInRoomCount.collectAsStateWithLifecycle()

    var showHeartSystemDialog by remember { mutableStateOf(false) }
    var selectedParticipant by remember { mutableStateOf<VoiceParticipant?>(null) }
    var chatInputText by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    val isUserHost = remember(activeRoom, userHostedRoomIds, currentUser) {
        val r = activeRoom
        r != null && (
            userHostedRoomIds.contains(r.id) ||
            r.createdBy == currentUser?.userId ||
            (r.createdBy == "user_guest_pakistan" && userHostedRoomIds.contains(r.id))
        )
    }

    val currentUserName = currentUser?.displayName?.ifBlank { "Pakistan Explorer" } ?: "Pakistan Explorer"

    // 8 Voice Room Avatars in 2 Rows (4 + 4)
    val participants = remember(userLevel, isUserHost, currentUserName, activeRoom, isHollowDostInRoom, isHollowDostSpeaking) {
        if (isUserHost) {
            val list = mutableListOf<VoiceParticipant>()
            // Host (You)
            list.add(
                VoiceParticipant(
                    id = "p_you_host",
                    name = "$currentUserName (You)",
                    role = "host",
                    isSpeaking = false,
                    level = userLevel,
                    avatarColorHex = "#FFD700",
                    isCurrentUser = true
                )
            )

            // Slot 2: Hollow Dost if in room, else empty guest seat or participant
            if (isHollowDostInRoom) {
                list.add(
                    VoiceParticipant(
                        id = "p_hollow_dost",
                        name = "Hollow Dost 🤖",
                        role = "speaker",
                        isSpeaking = isHollowDostSpeaking,
                        level = 99,
                        avatarColorHex = "#00F2FE"
                    )
                )
            } else {
                list.add(
                    VoiceParticipant(
                        id = "p_empty_guest_1",
                        name = "Guest Seat",
                        role = "listener",
                        isSpeaking = false,
                        level = 1,
                        avatarColorHex = "#1E1E2E"
                    )
                )
            }

            // Other seats
            list.add(
                VoiceParticipant(
                    id = "p_empty_seat_2",
                    name = "Seat 3",
                    role = "listener",
                    isSpeaking = false,
                    level = 1,
                    avatarColorHex = "#1A1A28"
                )
            )
            list.add(
                VoiceParticipant(
                    id = "p_empty_seat_3",
                    name = "Seat 4",
                    role = "listener",
                    isSpeaking = false,
                    level = 1,
                    avatarColorHex = "#1A1A28"
                )
            )
            list.add(
                VoiceParticipant(
                    id = "p_empty_seat_4",
                    name = "Seat 5",
                    role = "listener",
                    isSpeaking = false,
                    level = 1,
                    avatarColorHex = "#141420"
                )
            )
            list.add(
                VoiceParticipant(
                    id = "p_empty_seat_5",
                    name = "Seat 6",
                    role = "listener",
                    isSpeaking = false,
                    level = 1,
                    avatarColorHex = "#141420"
                )
            )
            list.add(
                VoiceParticipant(
                    id = "p_empty_seat_6",
                    name = "Seat 7",
                    role = "listener",
                    isSpeaking = false,
                    level = 1,
                    avatarColorHex = "#141420"
                )
            )
            list.add(
                VoiceParticipant(
                    id = "p_empty_seat_7",
                    name = "Seat 8",
                    role = "listener",
                    isSpeaking = false,
                    level = 1,
                    avatarColorHex = "#141420"
                )
            )
            list
        } else {
            val hostName = when {
                activeRoom?.title?.contains("Vehari", ignoreCase = true) == true -> "Tariq (Vehari)"
                activeRoom?.title?.contains("Lahore", ignoreCase = true) == true -> "Usman (Lahore)"
                activeRoom?.title?.contains("Islamabad", ignoreCase = true) == true -> "Daniyal (ISB)"
                else -> "Ahmed"
            }
            listOf(
                VoiceParticipant(
                    id = "p_ahmed",
                    name = hostName,
                    role = "host",
                    isSpeaking = false,
                    level = 88,
                    avatarColorHex = "#FFD700"
                ),
                VoiceParticipant(
                    id = "p_sara",
                    name = "Sara",
                    role = "speaker",
                    isSpeaking = true,
                    level = 42,
                    avatarColorHex = "#00FF66"
                ),
                VoiceParticipant(
                    id = "p_zain",
                    name = "Zain",
                    role = "speaker",
                    isSpeaking = true,
                    level = 35,
                    avatarColorHex = "#00FF66"
                ),
                VoiceParticipant(
                    id = "p_ayesha",
                    name = "Ayesha",
                    role = "listener",
                    isSpeaking = false,
                    level = 26,
                    avatarColorHex = "#B026FF"
                ),
                VoiceParticipant(
                    id = "p_bilal",
                    name = "Bilal",
                    role = "listener",
                    isSpeaking = false,
                    level = 19,
                    avatarColorHex = "#00F2FE"
                ),
                VoiceParticipant(
                    id = "p_fatima",
                    name = "Fatima",
                    role = "listener",
                    isSpeaking = false,
                    level = 31,
                    avatarColorHex = "#FE2C55"
                ),
                VoiceParticipant(
                    id = "p_hamza",
                    name = "Hamza",
                    role = "listener",
                    isSpeaking = false,
                    level = 15,
                    avatarColorHex = "#8A2BE2"
                ),
                VoiceParticipant(
                    id = "p_you",
                    name = "You",
                    role = "listener",
                    isSpeaking = false,
                    level = userLevel,
                    avatarColorHex = "#00F2FE",
                    isCurrentUser = true
                )
            )
        }
    }

    // Floating hearts animation list
    val activeFloatingHearts = remember { mutableStateListOf<FloatingHeart>() }

    LaunchedEffect(floatingHeartsTrigger) {
        if (floatingHeartsTrigger > 0) {
            val colors = listOf(
                HollowNeonPink,
                Color(0xFFFF486E),
                HollowNeonPurpleBright,
                HollowNeonBlue,
                HollowGold
            )
            repeat(4) { idx ->
                val heart = FloatingHeart(
                    id = System.nanoTime() + idx,
                    startXFraction = 0.55f + Random.nextFloat() * 0.35f,
                    color = colors.random()
                )
                activeFloatingHearts.add(heart)
            }
        }
    }

    // Default room initial messages if empty
    val displayMessages = remember(roomMessages) {
        if (roomMessages.isEmpty()) {
            listOf(
                Message(
                    id = "msg_init_1",
                    roomId = "room_karachi_night_vibes",
                    senderId = "p_ahmed",
                    senderName = "Ahmed",
                    senderAvatarColor = "#FFD700",
                    text = "Welcome everyone to Karachi Night Vibes! 🌙 Grab your chai and chill.",
                    timestamp = System.currentTimeMillis() - 60000,
                    status = "read"
                ),
                Message(
                    id = "msg_init_2",
                    roomId = "room_karachi_night_vibes",
                    senderId = "p_sara",
                    senderName = "Sara",
                    senderAvatarColor = "#00FF66",
                    text = "Love the lo-fi track playing! Hope everyone is having a peaceful night ☕",
                    timestamp = System.currentTimeMillis() - 40000,
                    status = "read"
                ),
                Message(
                    id = "msg_init_3",
                    roomId = "room_karachi_night_vibes",
                    senderId = "p_zain",
                    senderName = "Zain",
                    senderAvatarColor = "#00FF66",
                    text = "Huge shoutout to all listeners from Karachi, Lahore & Islamabad! 🇵🇰",
                    timestamp = System.currentTimeMillis() - 20000,
                    status = "read"
                )
            )
        } else {
            roomMessages
        }
    }

    // Scroll to bottom on message count change
    LaunchedEffect(displayMessages.size) {
        if (displayMessages.isNotEmpty()) {
            listState.animateScrollToItem(displayMessages.size - 1)
        }
    }

    BackHandler {
        viewModel.closeRoom()
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        containerColor = HollowShinyBlack,
        bottomBar = {
            // Glassmorphic Bottom Navigation with 3 tabs: Rooms (#) selected purple glow, Messages, Profile
            GlassmorphicHollowBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { tabIndex ->
                    viewModel.setSelectedTab(tabIndex)
                    onNavigateTab(tabIndex)
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HollowShinyBlack)
        ) {
            // Shiny black background with purple and blue neon glowing ambient gradients
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0x358A2BE2),
                                Color(0x2200F2FE),
                                Color.Transparent
                            ),
                            center = Offset(540f, 180f),
                            radius = 650f
                        )
                    )
            )

            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Bar: HOLLOW PAKISTAN with 12.4K coins, Admin badge
                VoiceRoomTopBar(
                    onBackClick = { viewModel.closeRoom() },
                    coinsText = "12.4K",
                    isAdmin = isAdmin,
                    onCoinsClick = {
                        Toast.makeText(context, "🪙 12,400 Hollow Coins - Community balance for voice lounge events", Toast.LENGTH_SHORT).show()
                    },
                    onAdminClick = { viewModel.openAdminPanel() }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Room Topic Pill: active room with LIVE count
                val roomTitle = activeRoom?.title ?: "Karachi Night Vibes"
                val roomTopic = activeRoom?.topic ?: "Pakistani youth hangout • Late night chai & poetry • Safe Space"
                val liveMemberCount = if (activeRoom != null && activeRoom!!.memberCount > 0) {
                    if (activeRoom!!.memberCount >= 1000) String.format(java.util.Locale.US, "%.1fK", activeRoom!!.memberCount / 1000f) else "${activeRoom!!.memberCount}"
                } else "1.2K"
                RoomTopicPill(
                    topic = roomTitle,
                    liveCount = liveMemberCount,
                    subTitle = roomTopic
                )

                // Hollow Dost Agent Live Status Banner (Visible to Host in Everyone rooms)
                if (isUserHost) {
                    Spacer(modifier = Modifier.height(6.dp))
                    HollowDostStatusBanner(
                        isAgentInRoom = isHollowDostInRoom,
                        countdownSec = hollowDostCountdownSec,
                        otherHumansCount = otherHumansInRoomCount,
                        onSimulateJoin = {
                            viewModel.simulateHumanJoinedRoom("Hamza")
                            Toast.makeText(context, "Guest Hamza joined! Hollow Dost says farewell & leaves.", Toast.LENGTH_SHORT).show()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 8 Avatars in 2 Rows (4 + 4): Host Ahmed/You, Speakers Sara/Zain, others purple neon
                AvatarsStageSection(
                    participants = participants,
                    onParticipantClick = { participant ->
                        selectedParticipant = participant
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Live Chat with glassmorphic bubbles (takes available space)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(displayMessages, key = { it.id }) { message ->
                            GlassmorphicChatBubble(
                                message = message,
                                isMe = message.senderId == (currentUser?.userId ?: "user_me") || message.senderName == "You"
                            )
                        }
                    }

                    // Floating Hearts Animation overlay
                    activeFloatingHearts.forEach { heart ->
                        FloatingHeartItem(
                            heart = heart,
                            onAnimationEnd = {
                                activeFloatingHearts.remove(heart)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Bottom Controls: Request to Speak, Mic Mute, Free Heart FREE Lv.12, Leave
                VoiceRoomBottomControls(
                    userLevel = userLevel,
                    dailyHeartsLeft = dailyHeartsLeft,
                    isMicMuted = isMicMuted,
                    speakRequestStatus = speakRequestStatus,
                    onRequestToSpeak = {
                        viewModel.toggleRequestToSpeak()
                        val msg = if (speakRequestStatus == "none") "Request to speak sent to Host Ahmed 🎙️" else "Request cancelled"
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    },
                    onToggleMic = {
                        viewModel.toggleMic()
                        Toast.makeText(context, if (isMicMuted) "Mic Unmuted 🎙️" else "Mic Muted 🔇", Toast.LENGTH_SHORT).show()
                    },
                    onFreeHeartClick = {
                        if (dailyHeartsLeft > 0) {
                            viewModel.sendFreeHeart(targetUser = "Ahmed (Host)")
                        } else {
                            Toast.makeText(context, "Daily 10 Free Hearts used! Resets midnight PKT. 💖", Toast.LENGTH_LONG).show()
                        }
                    },
                    onFreeHeartLongClick = {
                        showHeartSystemDialog = true
                    },
                    onLeave = {
                        viewModel.closeRoom()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Bottom Input: 'Type a message as listener...' with purple send button
                VoiceRoomInputBar(
                    text = chatInputText,
                    onTextChange = { chatInputText = it },
                    onSend = {
                        if (chatInputText.isNotBlank()) {
                            viewModel.sendMessage(text = chatInputText.trim())
                            chatInputText = ""
                        }
                    }
                )

                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }

    // Free Heart System Dialog
    if (showHeartSystemDialog) {
        FreeHeartSystemDialog(
            userLevel = userLevel,
            userXp = userXp,
            dailyHeartsLeft = dailyHeartsLeft,
            onDismiss = { showHeartSystemDialog = false },
            onSendHeart = {
                if (dailyHeartsLeft > 0) {
                    viewModel.sendFreeHeart(targetUser = "Ahmed (Host)")
                }
            }
        )
    }

    // Participant Profile Card Dialog
    selectedParticipant?.let { p ->
        ParticipantProfileDialog(
            participant = p,
            dailyHeartsLeft = dailyHeartsLeft,
            onDismiss = { selectedParticipant = null },
            onSendHeart = {
                if (dailyHeartsLeft > 0) {
                    viewModel.sendFreeHeart(targetUser = p.name)
                    selectedParticipant = null
                } else {
                    Toast.makeText(context, "No Free Hearts left today (10/10 sent)!", Toast.LENGTH_SHORT).show()
                }
            },
            onDirectChat = {
                selectedParticipant = null
                viewModel.startDirectChat(
                    User(
                        userId = p.id,
                        displayName = p.name,
                        handle = "@${p.name.lowercase()}",
                        avatarColorHex = p.avatarColorHex
                    )
                )
            }
        )
    }
}

@Composable
fun VoiceRoomTopBar(
    onBackClick: () -> Unit,
    coinsText: String,
    isAdmin: Boolean,
    onCoinsClick: () -> Unit,
    onAdminClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF161624))
                    .testTag("voice_room_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Leave Voice Lounge",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "HOLLOW PAKISTAN",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = 1.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 12.4K coins pill
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF1E1E2E).copy(alpha = 0.9f),
                border = BorderStroke(1.dp, HollowGold.copy(alpha = 0.6f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onCoinsClick() }
                    .testTag("coins_pill")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(text = "🪙", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = coinsText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = HollowGold
                    )
                }
            }

            // Admin badge
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isAdmin) Color(0xFF2E1035) else Color(0xFF1E1E2E),
                border = BorderStroke(
                    1.dp,
                    if (isAdmin) HollowNeonPurpleBright else Color(0xFF38384E)
                ),
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onAdminClick() }
                    .testTag("admin_badge_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Admin",
                        tint = if (isAdmin) HollowNeonPurpleBright else Color(0xFF94A3B8),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Admin",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isAdmin) HollowNeonPurpleBright else Color(0xFFCBD5E1)
                    )
                }
            }
        }
    }
}

@Composable
fun RoomTopicPill(
    topic: String,
    liveCount: String,
    subTitle: String = "🇵🇰 Karachi Sea View vibes • Late night chai & poetry • Safe Space"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "live_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF181828).copy(alpha = 0.95f),
            border = BorderStroke(
                1.dp,
                Brush.horizontalGradient(
                    listOf(HollowNeonPurple, HollowNeonBlue)
                )
            ),
            modifier = Modifier.clip(RoundedCornerShape(20.dp))
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                // Red LIVE indicator with pulse
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(TikTokRed)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LIVE $liveCount",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TikTokRed,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(12.dp)
                        .background(Color(0xFF3E3E55))
                )
                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = topic,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = subTitle,
            fontSize = 11.sp,
            color = Color(0xFF8E8EA8),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HollowDostStatusBanner(
    isAgentInRoom: Boolean,
    countdownSec: Int,
    otherHumansCount: Int,
    onSimulateJoin: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isAgentInRoom) Color(0xFF0F262B) else Color(0xFF1E162B),
        border = BorderStroke(
            1.dp,
            if (isAgentInRoom) Color(0xFF00F2FE).copy(alpha = 0.7f) else HollowNeonPurple.copy(alpha = 0.5f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (isAgentInRoom) Color(0xFF00F2FE).copy(alpha = 0.2f) else HollowNeonPurple.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🤖", fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Hollow Dost Agent",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAgentInRoom) Color(0xFF00F2FE) else Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isAgentInRoom) Color(0xFF00FF66).copy(alpha = 0.2f) else Color(0xFFFFA500).copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (isAgentInRoom) "Active Guest 🎙️" else "${countdownSec}s Alone Timer",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAgentInRoom) Color(0xFF00FF66) else Color(0xFFFFA500),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isAgentInRoom) {
                            "Agent is here so you are never alone! Listening to you."
                        } else {
                            "If no guest arrives in 2 min, Hollow Dost joins automatically."
                        },
                        fontSize = 10.sp,
                        color = Color(0xFFA0A0B2),
                        maxLines = 1
                    )
                }
            }

            if (isAgentInRoom) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF261D38),
                    border = BorderStroke(1.dp, HollowNeonPurple.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSimulateJoin() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Add Human",
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F2FE)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AvatarsStageSection(
    participants: List<VoiceParticipant>,
    onParticipantClick: (VoiceParticipant) -> Unit
) {
    val row1 = participants.take(4)
    val row2 = participants.drop(4).take(4)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF13131F).copy(alpha = 0.85f),
        border = BorderStroke(1.dp, Color(0xFF26263B))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Row 1 (Ahmed [Host], Sara [Speaking], Zain [Speaking], Ayesha)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row1.forEach { p ->
                    VoiceAvatarItem(
                        participant = p,
                        onClick = { onParticipantClick(p) }
                    )
                }
            }

            // Row 2 (Bilal, Fatima, Hamza, You)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row2.forEach { p ->
                    VoiceAvatarItem(
                        participant = p,
                        onClick = { onParticipantClick(p) }
                    )
                }
            }
        }
    }
}

@Composable
fun VoiceAvatarItem(
    participant: VoiceParticipant,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(2.dp)
            .testTag("voice_avatar_${participant.id}")
    ) {
        Box(
            modifier = Modifier.size(56.dp),
            contentAlignment = Alignment.Center
        ) {
            // Speaking wave ring if speaker
            if (participant.isSpeaking) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .scale(waveScale)
                        .clip(CircleShape)
                        .background(HollowSpeakingGreen.copy(alpha = 0.2f))
                        .border(1.5.dp, HollowSpeakingGreen, CircleShape)
                )
            }

            // Host: Golden glow + Crown on top
            if (participant.role == "host") {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(HollowGold, Color(0xFFFFA500), HollowGold)
                            )
                        )
                        .padding(2.5.dp)
                        .clip(CircleShape)
                ) {
                    if (participant.isCurrentUser) {
                        Image(
                            painter = painterResource(id = R.drawable.pakistan_avatar_1791194955321),
                            contentDescription = participant.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF2A2210)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👑", fontSize = 22.sp)
                        }
                    }
                }

                // Crown Floating Above Avatar
                Text(
                    text = "👑",
                    fontSize = 16.sp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-10).dp)
                )
            } else if (participant.isCurrentUser) {
                // Current User Avatar
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .border(
                            2.dp,
                            Brush.sweepGradient(
                                listOf(HollowNeonPurple, HollowNeonBlue, HollowNeonPurple)
                            ),
                            CircleShape
                        )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.pakistan_avatar_1791194955321),
                        contentDescription = "You",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else if (participant.name.contains("Hollow Dost")) {
                // Hollow Dost Agent Avatar
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0F262B))
                        .border(
                            2.dp,
                            Brush.sweepGradient(
                                listOf(Color(0xFF00F2FE), HollowNeonPurple, Color(0xFF00F2FE))
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🤖", fontSize = 24.sp)
                }
            } else {
                // Regular participants (Sara, Zain, Ayesha, Bilal, etc.)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(
                            width = if (participant.isSpeaking) 2.dp else 1.8.dp,
                            color = if (participant.isSpeaking) HollowSpeakingGreen else HollowNeonPurpleBright,
                            shape = CircleShape
                        )
                ) {
                    UserAvatar(
                        name = participant.name,
                        colorHex = participant.avatarColorHex,
                        size = 48.dp
                    )
                }
            }

            // Speaking microphone badge
            if (participant.isSpeaking) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(HollowSpeakingGreen)
                        .border(1.5.dp, Color(0xFF0D0D15), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Speaking",
                        tint = Color.Black,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(3.dp))

        // Name
        Text(
            text = participant.name,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = if (participant.role == "host") HollowGold else Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        // Role / Status Pill
        val pillBg = when (participant.role) {
            "host" -> HollowGold.copy(alpha = 0.2f)
            "speaker" -> HollowSpeakingGreen.copy(alpha = 0.2f)
            else -> Color(0xFF1E1E2E)
        }
        val pillColor = when (participant.role) {
            "host" -> HollowGold
            "speaker" -> HollowSpeakingGreen
            else -> Color(0xFFA0A0B2)
        }
        val pillLabel = when {
            participant.role == "host" -> "Host"
            participant.isSpeaking -> "Speaking"
            participant.role == "speaker" -> "Speaker"
            else -> "Lv.${participant.level}"
        }

        Surface(
            shape = RoundedCornerShape(8.dp),
            color = pillBg,
            modifier = Modifier.padding(top = 1.dp)
        ) {
            Text(
                text = pillLabel,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                color = pillColor,
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
    }
}

@Composable
fun GlassmorphicChatBubble(
    message: Message,
    isMe: Boolean
) {
    val isSystem = message.text.contains("Free Heart") || message.senderName == "Hollow Bot"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isMe && !isSystem) {
            UserAvatar(
                name = message.senderName,
                colorHex = message.senderAvatarColor,
                size = 28.dp
            )
            Spacer(modifier = Modifier.width(6.dp))
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomStart = if (isMe) 14.dp else 4.dp,
                bottomEnd = if (isMe) 4.dp else 14.dp
            ),
            color = when {
                isSystem -> Color(0x33FF2E93)
                isMe -> Color(0xFF281C38).copy(alpha = 0.9f)
                else -> Color(0xFF191928).copy(alpha = 0.85f)
            },
            border = BorderStroke(
                1.dp,
                when {
                    isSystem -> HollowNeonPink.copy(alpha = 0.5f)
                    isMe -> HollowNeonPurple.copy(alpha = 0.6f)
                    else -> Color(0xFF2C2C40)
                }
            ),
            modifier = Modifier.fillMaxWidth(if (isSystem) 1f else 0.82f)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                if (!isSystem) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Sender Name
                        Text(
                            text = if (isMe) "You" else message.senderName,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (message.senderName) {
                                "Ahmed" -> HollowGold
                                "Sara", "Zain" -> HollowSpeakingGreen
                                else -> HollowNeonBlue
                            }
                        )

                        // Level badge Lv.12
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = HollowNeonPurple.copy(alpha = 0.25f)
                        ) {
                            Text(
                                text = if (isMe) "Lv.12" else "Lv.35",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = HollowNeonPurpleBright,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Message Text
                Text(
                    text = message.text,
                    fontSize = 12.5.sp,
                    color = if (isSystem) Color(0xFFFFD1E8) else Color(0xFFE2E8F0),
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun VoiceRoomBottomControls(
    userLevel: Int,
    dailyHeartsLeft: Int,
    isMicMuted: Boolean,
    speakRequestStatus: String,
    onRequestToSpeak: () -> Unit,
    onToggleMic: () -> Unit,
    onFreeHeartClick: () -> Unit,
    onFreeHeartLongClick: () -> Unit,
    onLeave: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. Request to Speak
        val isRequested = speakRequestStatus == "requested"
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isRequested) Color(0xFF1E3A2B) else Color(0xFF181828),
            border = BorderStroke(
                1.dp,
                if (isRequested) HollowSpeakingGreen else HollowNeonPurple.copy(alpha = 0.7f)
            ),
            modifier = Modifier
                .weight(1.1f)
                .clip(RoundedCornerShape(20.dp))
                .clickable { onRequestToSpeak() }
                .testTag("request_to_speak_button")
        ) {
            Row(
                modifier = Modifier.padding(vertical = 8.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = if (isRequested) HollowSpeakingGreen else HollowNeonPurpleBright,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isRequested) "Requested ✓" else "Request Speak",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isRequested) HollowSpeakingGreen else Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // 2. Mic Mute
        Surface(
            shape = CircleShape,
            color = if (isMicMuted) Color(0xFF2C141E) else Color(0xFF163322),
            border = BorderStroke(
                1.dp,
                if (isMicMuted) TikTokRed else HollowSpeakingGreen
            ),
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .clickable { onToggleMic() }
                .testTag("mic_mute_button")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = if (isMicMuted) "Unmute" else "Mute",
                    tint = if (isMicMuted) TikTokRed else HollowSpeakingGreen,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // 3. Free Heart FREE Lv.12
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF281128),
            border = BorderStroke(
                1.5.dp,
                Brush.horizontalGradient(
                    listOf(HollowNeonPink, HollowNeonPurple)
                )
            ),
            modifier = Modifier
                .weight(1.2f)
                .clip(RoundedCornerShape(20.dp))
                .clickable { onFreeHeartClick() }
                .testTag("free_heart_button")
        ) {
            Row(
                modifier = Modifier.padding(vertical = 8.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Send Free Heart",
                    tint = HollowNeonPink,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "FREE Lv.$userLevel",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "$dailyHeartsLeft/10 left",
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = HollowNeonPink
                    )
                }
            }
        }

        // 4. Leave button
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1E1E28),
            border = BorderStroke(1.dp, Color(0xFF38384E)),
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { onLeave() }
                .testTag("leave_room_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = "Leave",
                    tint = TikTokRed,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Leave",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TikTokRed
                )
            }
        }
    }
}

@Composable
fun VoiceRoomInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF161624).copy(alpha = 0.95f),
        border = BorderStroke(1.dp, Color(0xFF28283E))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier
                    .weight(1f)
                    .testTag("live_chat_input"),
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 13.5.sp
                ),
                cursorBrush = SolidColor(HollowNeonPurpleBright),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                decorationBox = { innerTextField ->
                    if (text.isEmpty()) {
                        Text(
                            text = "Type a message as listener...",
                            color = Color(0xFF75758E),
                            fontSize = 13.sp
                        )
                    }
                    innerTextField()
                }
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Purple Send Button
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(HollowNeonPurple, Color(0xFF6B21A8))
                        )
                    )
                    .clickable { onSend() }
                    .testTag("live_chat_send_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun GlassmorphicHollowBottomNav(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF0F0F1A).copy(alpha = 0.96f),
        border = BorderStroke(1.dp, Color(0xFF222234))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 1: Rooms (#) - selected with purple glow
            BottomNavItem(
                label = "Rooms",
                icon = Icons.Default.Tag,
                unselectedIcon = Icons.Outlined.Tag,
                isSelected = selectedTab == 0,
                glowColor = HollowNeonPurple,
                onClick = { onTabSelected(0) },
                testTag = "tab_rooms"
            )

            // Tab 2: Messages
            BottomNavItem(
                label = "Messages",
                icon = Icons.Default.ChatBubble,
                unselectedIcon = Icons.Outlined.ChatBubbleOutline,
                isSelected = selectedTab == 1,
                glowColor = HollowNeonBlue,
                onClick = { onTabSelected(1) },
                testTag = "tab_messages"
            )

            // Tab 4 (Special): Badshah PK Showdown with Amber Glow & LIVE Badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onTabSelected(3) }
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .testTag("tab_badshah_pk")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    // Amber glowing backdrop
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                if (selectedTab == 3) Color(0x66FFD700) else Color(0x33FFB300)
                            )
                    )

                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Badshah PK",
                        tint = if (selectedTab == 3) Color(0xFFFFD700) else Color(0xFFFFC107),
                        modifier = Modifier.size(26.dp)
                    )

                    // LIVE badge on top-right of trophy
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TikTokRed,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-4).dp)
                    ) {
                        Text(
                            text = "LIVE",
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                        )
                    }
                }
                Text(
                    text = "Badshah PK",
                    fontSize = 10.5.sp,
                    fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == 3) Color(0xFFFFD700) else Color.White.copy(alpha = 0.65f)
                )
            }

            // Tab 3: Profile
            BottomNavItem(
                label = "Profile",
                icon = Icons.Default.Person,
                unselectedIcon = Icons.Outlined.PersonOutline,
                isSelected = selectedTab == 2,
                glowColor = HollowNeonPurpleBright,
                onClick = { onTabSelected(2) },
                testTag = "tab_profile"
            )
        }
    }
}

@Composable
fun BottomNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    glowColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .testTag(testTag)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(32.dp)
        ) {
            if (isSelected) {
                // Purple glow ring behind icon
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(glowColor.copy(alpha = 0.22f))
                )
            }
            Icon(
                imageVector = if (isSelected) icon else unselectedIcon,
                contentDescription = label,
                tint = if (isSelected) glowColor else Color(0xFF8E8EA8),
                modifier = Modifier.size(22.dp)
            )
        }

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else Color(0xFF8E8EA8)
        )
    }
}

@Composable
fun FloatingHeartItem(
    heart: FloatingHeart,
    onAnimationEnd: () -> Unit
) {
    val animOffsetY = remember { Animatable(0f) }
    val animAlpha = remember { Animatable(1f) }
    val animScale = remember { Animatable(0.5f) }

    LaunchedEffect(heart.id) {
        launch {
            animScale.animateTo(1.2f, tween(300))
        }
        launch {
            animOffsetY.animateTo(-450f, tween(1600, easing = LinearEasing))
            onAnimationEnd()
        }
        launch {
            delay(900)
            animAlpha.animateTo(0f, tween(700))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .offset {
                IntOffset(
                    x = (heart.startXFraction * 800).toInt(),
                    y = (700 + animOffsetY.value).toInt()
                )
            }
            .scale(animScale.value)
    ) {
        Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = null,
            tint = heart.color.copy(alpha = animAlpha.value),
            modifier = Modifier.size(28.dp)
        )
    }
}

@Composable
fun FreeHeartSystemDialog(
    userLevel: Int,
    userXp: Int,
    dailyHeartsLeft: Int,
    onDismiss: () -> Unit,
    onSendHeart: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF161626),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = HollowNeonPink,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Free Heart System",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E1E32),
                    border = BorderStroke(1.dp, Color(0xFF2C2C46))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "🎁 No Paid Gifts!",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = HollowGold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Hollow Pakistan is 100% free. Every user receives 10 Free Hearts every single day to support hosts and speakers without spending money.",
                            fontSize = 11.5.sp,
                            color = Color(0xFFB0B0C4),
                            lineHeight = 15.sp
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Level: Lv.$userLevel",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = HollowNeonPurpleBright
                    )
                    Text(
                        text = "$userXp / 100 XP",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                LinearProgressIndicator(
                    progress = { userXp / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = HollowNeonPurpleBright,
                    trackColor = Color(0xFF2A2A3E)
                )

                Text(
                    text = "Level Scale: Lv.1 to Lv.100. Each Free Heart sent gives you +15 XP!",
                    fontSize = 11.sp,
                    color = Color(0xFF8E8EA8)
                )

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF241424),
                    border = BorderStroke(1.dp, HollowNeonPink.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Hearts Left:",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "$dailyHeartsLeft / 10",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = HollowNeonPink
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSendHeart()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = HollowNeonPink
                ),
                shape = RoundedCornerShape(18.dp),
                enabled = dailyHeartsLeft > 0
            ) {
                Text(
                    text = if (dailyHeartsLeft > 0) "Send Heart 💖" else "Daily Limit Reached",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent
                )
            ) {
                Text("Close", color = Color(0xFFA0A0B2))
            }
        }
    )
}

@Composable
fun ParticipantProfileDialog(
    participant: VoiceParticipant,
    dailyHeartsLeft: Int,
    onDismiss: () -> Unit,
    onSendHeart: () -> Unit,
    onDirectChat: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141424),
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .border(
                            2.5.dp,
                            if (participant.role == "host") HollowGold else HollowNeonPurpleBright,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (participant.role == "host") {
                        Text("👑", fontSize = 36.sp)
                    } else {
                        UserAvatar(
                            name = participant.name,
                            colorHex = participant.avatarColorHex,
                            size = 80.dp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = participant.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Text(
                    text = "@${participant.name.lowercase().replace(" ", "")} • Level ${participant.level}",
                    fontSize = 12.sp,
                    color = Color(0xFFA0A0B2)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onSendHeart,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = HollowNeonPink),
                        shape = RoundedCornerShape(18.dp),
                        enabled = dailyHeartsLeft > 0
                    ) {
                        Text("💖 Heart", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onDirectChat,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222238)),
                        border = BorderStroke(1.dp, HollowNeonBlue.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Text("💬 Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = HollowNeonBlue)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Text("Dismiss", color = Color(0xFF8E8EA8))
            }
        }
    )
}
