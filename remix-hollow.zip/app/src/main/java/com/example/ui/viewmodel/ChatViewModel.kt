package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.agent.HollowDostBrain
import com.example.data.model.ChatRoom
import com.example.data.model.Message
import com.example.data.model.User
import com.example.data.repository.ChatRepository
import com.example.ui.auth.signOut
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class HollowNavScreen {
    VEHARI_HOME,
    FEMALE_ONLY_ROOMS,
    CITY,
    GENDER,
    ROOM_TYPE,
    PASSWORD,
    LIVE_ROOM
}

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ChatRepository(application.applicationContext)

    init {
        viewModelScope.launch {
            repository.seedInitialRoomsIfNeeded()
        }
    }

    fun onUserAuthenticated() {
        viewModelScope.launch {
            repository.seedInitialRoomsIfNeeded()
        }
    }

    // 4-Screen Flow & Vehari Navigation
    private val _currentScreen = MutableStateFlow(HollowNavScreen.VEHARI_HOME)
    val currentScreen: StateFlow<HollowNavScreen> = _currentScreen.asStateFlow()

    private val _selectedCity = MutableStateFlow("Vehari")
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val _selectedGender = MutableStateFlow("Combine")
    val selectedGender: StateFlow<String> = _selectedGender.asStateFlow()

    private val _customPrivateCode = MutableStateFlow("7890")
    val customPrivateCode: StateFlow<String> = _customPrivateCode.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Rooms, 1: Direct, 2: Profile
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Mood Onboarding (defaults to false so Home screen shows first)
    private val _showMoodOnboarding = MutableStateFlow(false)
    val showMoodOnboarding: StateFlow<Boolean> = _showMoodOnboarding.asStateFlow()

    private val _userMood = MutableStateFlow<String?>("Chill")
    val userMood: StateFlow<String?> = _userMood.asStateFlow()

    // Hosted Rooms by Current User
    private val _userHostedRoomIds = MutableStateFlow<Set<String>>(emptySet())
    val userHostedRoomIds: StateFlow<Set<String>> = _userHostedRoomIds.asStateFlow()

    // Official Badshah PK Showdown State (Controlled from Admin Panel or default)
    private val _officialHostCode = MutableStateFlow("PK-8842")
    val officialHostCode: StateFlow<String> = _officialHostCode.asStateFlow()

    fun updateOfficialHostCode(newCode: String) {
        _officialHostCode.value = newCode.trim().uppercase()
    }

    // Hollow Dost Agent State
    private val _isHollowDostInRoom = MutableStateFlow(false)
    val isHollowDostInRoom: StateFlow<Boolean> = _isHollowDostInRoom.asStateFlow()

    private val _isHollowDostSpeaking = MutableStateFlow(false)
    val isHollowDostSpeaking: StateFlow<Boolean> = _isHollowDostSpeaking.asStateFlow()

    private val _hollowDostCountdownSec = MutableStateFlow(120)
    val hollowDostCountdownSec: StateFlow<Int> = _hollowDostCountdownSec.asStateFlow()

    private val _otherHumansInRoomCount = MutableStateFlow(0)
    val otherHumansInRoomCount: StateFlow<Int> = _otherHumansInRoomCount.asStateFlow()

    private var hollowDostJob: Job? = null
    private var hollowDostSpeakingResetJob: Job? = null

    // Free Heart & Level System (Lv.1 to Lv.100, 10 Daily Hearts)
    private val _userLevel = MutableStateFlow(12)
    val userLevel: StateFlow<Int> = _userLevel.asStateFlow()

    private val _userXp = MutableStateFlow(45)
    val userXp: StateFlow<Int> = _userXp.asStateFlow()

    private val _dailyHeartsLeft = MutableStateFlow(10)
    val dailyHeartsLeft: StateFlow<Int> = _dailyHeartsLeft.asStateFlow()

    // Voice Room Microphone & Speaking State
    private val _isMicMuted = MutableStateFlow(true)
    val isMicMuted: StateFlow<Boolean> = _isMicMuted.asStateFlow()

    private val _speakRequestStatus = MutableStateFlow("none") // "none", "requested", "speaking"
    val speakRequestStatus: StateFlow<String> = _speakRequestStatus.asStateFlow()

    private val _floatingHeartsTrigger = MutableStateFlow(0)
    val floatingHeartsTrigger: StateFlow<Int> = _floatingHeartsTrigger.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Vehari")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    val publicRooms: StateFlow<List<ChatRoom>> = combine(
        repository.publicRooms,
        _searchQuery,
        _selectedCategory
    ) { rooms, query, category ->
        rooms.filter { room ->
            val matchesCategory = when (category) {
                "All" -> true
                "Vehari" -> room.title.contains("Vehari", ignoreCase = true) ||
                        room.topic.contains("Vehari", ignoreCase = true) ||
                        room.category.equals("Vehari", ignoreCase = true)
                "Karachi" -> room.title.contains("Karachi", ignoreCase = true) ||
                        room.category.equals("Karachi", ignoreCase = true)
                "Lahore" -> room.title.contains("Lahore", ignoreCase = true) ||
                        room.category.equals("Lahore", ignoreCase = true)
                "Islamabad" -> room.title.contains("Islamabad", ignoreCase = true) ||
                        room.category.equals("Islamabad", ignoreCase = true)
                "Multan" -> room.title.contains("Multan", ignoreCase = true) ||
                        room.category.equals("Multan", ignoreCase = true)
                "Faisalabad" -> room.title.contains("Faisalabad", ignoreCase = true) ||
                        room.category.equals("Faisalabad", ignoreCase = true)
                "Peshawar" -> room.title.contains("Peshawar", ignoreCase = true) ||
                        room.category.equals("Peshawar", ignoreCase = true)
                "Quetta" -> room.title.contains("Quetta", ignoreCase = true) ||
                        room.category.equals("Quetta", ignoreCase = true)
                else -> room.category.equals(category, ignoreCase = true) ||
                        room.title.contains(category, ignoreCase = true)
            }
            val matchesQuery = query.isBlank() ||
                    room.title.contains(query, ignoreCase = true) ||
                    room.topic.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }.sortedWith(
            compareByDescending<ChatRoom> { it.title.contains("Vehari", ignoreCase = true) || it.id == "room_vehari" }
                .thenByDescending { it.memberCount }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val nearbyRooms: StateFlow<List<ChatRoom>> = repository.publicRooms.map { rooms ->
        rooms.sortedWith(
            compareByDescending<ChatRoom> { it.title.contains("Vehari", ignoreCase = true) || it.id == "room_vehari" }
                .thenByDescending { it.id == "room_karachi_night_vibes" }
                .thenByDescending { it.title.contains("Multan", ignoreCase = true) }
                .thenByDescending { it.memberCount }
        ).take(6)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val directChats: StateFlow<List<ChatRoom>> = combine(
        repository.directChats,
        _searchQuery
    ) { chats, query ->
        chats.filter { chat ->
            query.isBlank() || chat.title.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<User>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentUser: StateFlow<User?> = repository.currentUserProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Active Room State
    private val _activeRoomId = MutableStateFlow<String?>(null)
    val activeRoomId: StateFlow<String?> = _activeRoomId.asStateFlow()

    val activeRoom: StateFlow<ChatRoom?> = combine(
        repository.allRooms,
        _activeRoomId
    ) { rooms, activeId ->
        rooms.find { it.id == activeId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeRoomMessages: StateFlow<List<Message>> = _activeRoomId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getMessagesForRoom(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mediaStream: StateFlow<List<Message>> = repository.allRooms.flatMapLatest { rooms ->
        combine(rooms.map { r -> repository.getMessagesForRoom(r.id) }) { arrays ->
            arrays.flatMap { it }.filter { !it.mediaUri.isNullOrBlank() }
                .sortedByDescending { it.timestamp }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isTypingSimulated = MutableStateFlow(false)
    val isTypingSimulated: StateFlow<Boolean> = _isTypingSimulated.asStateFlow()

    private val _typingUserName = MutableStateFlow<String?>("Someone")
    val typingUserName: StateFlow<String?> = _typingUserName.asStateFlow()

    private val _replyingTo = MutableStateFlow<Message?>(null)
    val replyingTo: StateFlow<Message?> = _replyingTo.asStateFlow()

    private val _fullscreenImageUri = MutableStateFlow<String?>(null)
    val fullscreenImageUri: StateFlow<String?> = _fullscreenImageUri.asStateFlow()

    private val _showCreateRoomDialog = MutableStateFlow(false)
    val showCreateRoomDialog: StateFlow<Boolean> = _showCreateRoomDialog.asStateFlow()

    private val _showProfileDialog = MutableStateFlow(false)
    val showProfileDialog: StateFlow<Boolean> = _showProfileDialog.asStateFlow()

    private val _showRoomInfoSheet = MutableStateFlow(false)
    val showRoomInfoSheet: StateFlow<Boolean> = _showRoomInfoSheet.asStateFlow()

    val allRooms: StateFlow<List<ChatRoom>> = repository.allRooms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trendingRooms: StateFlow<List<ChatRoom>> = repository.allRooms.map { rooms ->
        rooms.sortedByDescending { it.memberCount }.take(6)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val onlineUsersCount: StateFlow<Int> = repository.allUsers.map { users ->
        2420 + users.count { it.isOnline } * 18
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2420)

    private val _currentLanguage = MutableStateFlow(com.example.util.AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<com.example.util.AppLanguage> = _currentLanguage.asStateFlow()

    fun toggleLanguage() {
        _currentLanguage.value = com.example.util.AppLanguage.ENGLISH
    }

    val allReports: StateFlow<List<com.example.data.model.UserReport>> = repository.allReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _userToReport = MutableStateFlow<User?>(null)
    val userToReport: StateFlow<User?> = _userToReport.asStateFlow()

    private val _reportSuccessNotice = MutableStateFlow<String?>(null)
    val reportSuccessNotice: StateFlow<String?> = _reportSuccessNotice.asStateFlow()

    fun openReportDialog(user: User) {
        _userToReport.value = user
    }

    fun closeReportDialog() {
        _userToReport.value = null
    }

    fun clearReportSuccessNotice() {
        _reportSuccessNotice.value = null
    }

    fun submitSafetyReport(user: User, reason: String, details: String) {
        viewModelScope.launch {
            try {
                repository.submitReport(
                    reportedUserId = user.userId,
                    reportedUserName = user.displayName,
                    reason = reason,
                    details = details
                )
                _userToReport.value = null
                _reportSuccessNotice.value = "Report sent to Hollow safety team. Thank you for keeping Pakistan safe!"
            } catch (e: Exception) {
                _sendErrorMessage.value = "Failed to submit report: ${e.message}"
            }
        }
    }

    fun updateReportStatus(reportId: String, status: String) {
        viewModelScope.launch {
            try {
                repository.updateReportStatus(reportId, status)
            } catch (e: Exception) {
                _sendErrorMessage.value = "Failed to update report: ${e.message}"
            }
        }
    }

    val isAdmin: StateFlow<Boolean> = flowOf(repository.isCurrentUserAdmin())
        .stateIn(viewModelScope, SharingStarted.Eagerly, repository.isCurrentUserAdmin())

    private val _showAdminPanel = MutableStateFlow(false)
    val showAdminPanel: StateFlow<Boolean> = _showAdminPanel.asStateFlow()

    private val _sendErrorMessage = MutableStateFlow<String?>(null)
    val sendErrorMessage: StateFlow<String?> = _sendErrorMessage.asStateFlow()

    fun openAdminPanel() {
        _showAdminPanel.value = true
    }

    fun closeAdminPanel() {
        _showAdminPanel.value = false
    }

    fun clearSendError() {
        _sendErrorMessage.value = null
    }

    fun deleteRoomByAdmin(roomId: String) {
        viewModelScope.launch {
            try {
                if (_activeRoomId.value == roomId) {
                    closeRoom()
                }
                repository.deleteRoom(roomId)
            } catch (e: Exception) {
                _sendErrorMessage.value = "Failed to delete room: ${e.message}"
            }
        }
    }

    fun deleteMessageByAdmin(roomId: String, messageId: String) {
        viewModelScope.launch {
            try {
                repository.deleteMessage(roomId, messageId)
            } catch (e: Exception) {
                _sendErrorMessage.value = "Failed to delete message: ${e.message}"
            }
        }
    }

    fun toggleUserBlock(userId: String, currentBlocked: Boolean) {
        viewModelScope.launch {
            try {
                repository.setUserBlocked(userId, !currentBlocked)
            } catch (e: Exception) {
                _sendErrorMessage.value = "Failed to update user block state: ${e.message}"
            }
        }
    }

    fun moveUserToRoom(user: User, targetRoom: ChatRoom) {
        viewModelScope.launch {
            try {
                repository.moveUserToRoom(user, targetRoom)
            } catch (e: Exception) {
                _sendErrorMessage.value = "Failed to move user: ${e.message}"
            }
        }
    }

    fun setSelectedTab(index: Int) {
        _selectedTab.value = index
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun openRoom(roomId: String) {
        _activeRoomId.value = roomId
        _currentScreen.value = HollowNavScreen.LIVE_ROOM
        checkAndStartHollowDostLifecycle(roomId)
    }

    fun closeRoom() {
        cancelHollowDostLifecycle()
        _activeRoomId.value = null
        _replyingTo.value = null
        _isTypingSimulated.value = false
        if (_currentScreen.value == HollowNavScreen.LIVE_ROOM) {
            _currentScreen.value = HollowNavScreen.ROOM_TYPE
        }
    }

    private fun checkAndStartHollowDostLifecycle(roomId: String) {
        cancelHollowDostLifecycle()
        val room = publicRooms.value.find { it.id == roomId } ?: activeRoom.value
        val isEveryoneRoom = room == null || !room.isPrivate

        // If it's a private room, Hollow Dost does not intrude
        if (!isEveryoneRoom) return

        // If user is host or room is just created/empty
        val isHost = isUserHostOfRoom(roomId)
        if (!isHost) return

        _otherHumansInRoomCount.value = 0
        _hollowDostCountdownSec.value = 120
        _isHollowDostInRoom.value = false
        _isHollowDostSpeaking.value = false

        hollowDostJob = viewModelScope.launch {
            // Count down 2 minutes (120 seconds).
            // Updates countdown state every second so the UI can show live time or trigger.
            for (sec in 120 downTo 1) {
                _hollowDostCountdownSec.value = sec
                delay(1000L)
                if (_otherHumansInRoomCount.value > 0) {
                    // Real human joined before 2 minutes
                    return@launch
                }
            }
            _hollowDostCountdownSec.value = 0

            // 2 minutes passed and still alone! Hollow Dost joins as Guest!
            _isHollowDostInRoom.value = true
            triggerHollowDostSpeaking(HollowDostBrain.GREETING_MESSAGE)
        }
    }

    private fun cancelHollowDostLifecycle() {
        hollowDostJob?.cancel()
        hollowDostJob = null
        hollowDostSpeakingResetJob?.cancel()
        hollowDostSpeakingResetJob = null
        _isHollowDostInRoom.value = false
        _isHollowDostSpeaking.value = false
        _hollowDostCountdownSec.value = 120
    }

    fun simulateHumanJoinedRoom(humanName: String = "Hamza") {
        _otherHumansInRoomCount.value = _otherHumansInRoomCount.value + 1
        if (_isHollowDostInRoom.value) {
            // Rule 6: As soon as a real person comes as guest or audience,
            // Agent says: "آپ لوگ بات کریں، میں چلتا ہوں، پھر ملیں گے" and leaves!
            viewModelScope.launch {
                triggerHollowDostSpeaking(HollowDostBrain.FAREWELL_MESSAGE)
                delay(3000L)
                _isHollowDostInRoom.value = false
                _isHollowDostSpeaking.value = false
            }
        }
    }

    private fun triggerHollowDostSpeaking(agentText: String) {
        val roomId = _activeRoomId.value ?: return
        viewModelScope.launch {
            _isHollowDostSpeaking.value = true
            try {
                repository.sendMessage(
                    roomId = roomId,
                    text = agentText
                )
            } catch (e: Exception) {
                // Ignore send error
            }

            hollowDostSpeakingResetJob?.cancel()
            hollowDostSpeakingResetJob = viewModelScope.launch {
                delay(4500L)
                _isHollowDostSpeaking.value = false
            }
        }
    }

    fun setReplyingTo(message: Message?) {
        _replyingTo.value = message
    }

    fun openFullscreenImage(uri: String?) {
        _fullscreenImageUri.value = uri
    }

    fun setCreateRoomDialogVisible(visible: Boolean) {
        _showCreateRoomDialog.value = visible
    }

    fun setProfileDialogVisible(visible: Boolean) {
        _showProfileDialog.value = visible
    }

    fun setRoomInfoSheetVisible(visible: Boolean) {
        _showRoomInfoSheet.value = visible
    }

    fun sendMessage(
        text: String,
        mediaUri: String? = null,
        mediaType: String = "none",
        voiceDurationSec: Int = 0
    ) {
        val roomId = _activeRoomId.value ?: return
        if (text.isBlank() && mediaUri == null && mediaType == "none") return

        val reply = _replyingTo.value
        _replyingTo.value = null

        viewModelScope.launch {
            try {
                repository.sendMessage(
                    roomId = roomId,
                    text = text,
                    mediaUri = mediaUri,
                    mediaType = mediaType,
                    voiceDurationSec = voiceDurationSec,
                    replyTo = reply
                )

                // If Hollow Dost is in the room as guest, understand host message and reply with the best matching line from the 200 lines
                if (_isHollowDostInRoom.value && text.isNotBlank()) {
                    viewModelScope.launch {
                        delay(1500L) // natural thoughtful pause
                        val bestLine = HollowDostBrain.pickBestLine(text)
                        triggerHollowDostSpeaking(bestLine)
                    }
                }
            } catch (e: Exception) {
                _sendErrorMessage.value = e.message ?: "Failed to send message"
            }
        }
    }

    fun toggleReaction(messageId: String, emoji: String) {
        val roomId = _activeRoomId.value ?: return
        viewModelScope.launch {
            repository.toggleReaction(roomId, messageId, emoji)
        }
    }

    fun createRoom(title: String, topic: String, category: String) {
        viewModelScope.launch {
            val newId = repository.createRoom(
                title = title.trim(),
                topic = topic.trim().ifEmpty { "Community voice room for #$title" },
                category = category
            )
            _userHostedRoomIds.value = _userHostedRoomIds.value + newId
            _showCreateRoomDialog.value = false
            _selectedTab.value = 0
            openRoom(newId)
        }
    }

    fun isUserHostOfRoom(roomId: String?): Boolean {
        if (roomId == null) return false
        if (_userHostedRoomIds.value.contains(roomId)) return true
        val room = publicRooms.value.find { it.id == roomId } ?: activeRoom.value?.takeIf { it.id == roomId }
        val user = currentUser.value
        return room != null && (room.createdBy == user?.userId || (room.createdBy == "user_guest_pakistan" && _userHostedRoomIds.value.contains(roomId)))
    }

    fun updateProfile(displayName: String, handle: String, statusText: String, colorHex: String) {
        viewModelScope.launch {
            repository.updateCurrentUser(displayName, handle, statusText, colorHex)
            _showProfileDialog.value = false
        }
    }

    fun startDirectChat(user: User) {
        val dmRoomId = "dm_${user.userId}"
        openRoom(dmRoomId)
    }

    // Mood Onboarding Actions
    fun dismissMoodOnboarding() {
        _showMoodOnboarding.value = false
        openRoom("room_karachi_night_vibes")
    }

    fun selectMoodAndOpenRoom(mood: String) {
        _userMood.value = mood
        _selectedCategory.value = mood
        _showMoodOnboarding.value = false
        openRoom("room_karachi_night_vibes")
    }

    fun openMoodOnboarding() {
        _showMoodOnboarding.value = true
    }

    // Voice Room Microphone & Speaking Actions
    fun toggleMic() {
        _isMicMuted.value = !_isMicMuted.value
    }

    fun toggleRequestToSpeak() {
        _speakRequestStatus.value = if (_speakRequestStatus.value == "none") "requested" else "none"
    }

    // Free Heart System (No paid gifts, 10 daily free hearts, Lv.1 to Lv.100)
    fun sendFreeHeart(targetUser: String = "Host Ahmed") {
        if (_dailyHeartsLeft.value > 0) {
            _dailyHeartsLeft.value -= 1
            val newXp = _userXp.value + 15
            if (newXp >= 100) {
                _userLevel.value = (_userLevel.value + 1).coerceAtMost(100)
                _userXp.value = newXp - 100
            } else {
                _userXp.value = newXp
            }
            _floatingHeartsTrigger.value += 1
            sendMessage("💖 sent Free Heart to $targetUser! (Lv.${_userLevel.value})")
        }
    }

    // Vehari Home & Flow Navigation Methods
    fun openVehariHome() {
        _currentScreen.value = HollowNavScreen.VEHARI_HOME
    }

    fun openFemaleOnlyRooms() {
        _currentScreen.value = HollowNavScreen.FEMALE_ONLY_ROOMS
    }

    fun openCityScreen() {
        _currentScreen.value = HollowNavScreen.CITY
    }

    fun openMaleRooms() {
        selectGender("Male")
    }

    fun openCombineRooms() {
        selectGender("Combine")
    }

    fun selectCity(city: String) {
        _selectedCity.value = city
        _selectedCategory.value = city
        if (city.equals("Vehari", ignoreCase = true)) {
            _currentScreen.value = HollowNavScreen.VEHARI_HOME
        } else {
            _currentScreen.value = HollowNavScreen.GENDER
        }
    }

    fun selectGender(gender: String) {
        _selectedGender.value = gender
        _currentScreen.value = HollowNavScreen.ROOM_TYPE
    }

    fun openPasswordScreen() {
        _currentScreen.value = HollowNavScreen.PASSWORD
    }

    fun enterEveryoneRoom() {
        val city = _selectedCity.value
        val roomId = if (city.equals("Vehari", ignoreCase = true)) "room_vehari" else "room_karachi_night_vibes"
        openRoom(roomId)
    }

    fun verifyPasswordAndEnter(code: String): Boolean {
        if (code == "7890" || code == _customPrivateCode.value) {
            val roomId = "room_${_selectedCity.value.lowercase()}_private"
            openRoom(roomId)
            return true
        }
        return false
    }

    fun setPrivateCodeAndCreateRoom(code: String, roomName: String = "") {
        _customPrivateCode.value = code
        viewModelScope.launch {
            val title = roomName.ifBlank { "🔒 ${_selectedCity.value} Private Friends" }
            val newId = repository.createRoom(
                title = title,
                topic = "Private 4-digit locked room • Friends only",
                category = _selectedCity.value
            )
            _userHostedRoomIds.value = _userHostedRoomIds.value + newId
            openRoom(newId)
        }
    }

    fun navigateBackInFlow() {
        when (_currentScreen.value) {
            HollowNavScreen.LIVE_ROOM -> {
                closeRoom()
                _currentScreen.value = HollowNavScreen.VEHARI_HOME
            }
            HollowNavScreen.FEMALE_ONLY_ROOMS -> {
                _currentScreen.value = HollowNavScreen.VEHARI_HOME
            }
            HollowNavScreen.PASSWORD -> {
                _currentScreen.value = HollowNavScreen.ROOM_TYPE
            }
            HollowNavScreen.ROOM_TYPE -> {
                _currentScreen.value = HollowNavScreen.GENDER
            }
            HollowNavScreen.GENDER -> {
                _currentScreen.value = HollowNavScreen.CITY
            }
            HollowNavScreen.CITY -> {
                _currentScreen.value = HollowNavScreen.VEHARI_HOME
            }
            HollowNavScreen.VEHARI_HOME -> {}
        }
    }

    fun logOut(context: Context, credentialManager: CredentialManager, onSignedOut: () -> Unit) {
        closeRoom()
        signOut(context, credentialManager, onSignedOut, viewModelScope)
    }
}
