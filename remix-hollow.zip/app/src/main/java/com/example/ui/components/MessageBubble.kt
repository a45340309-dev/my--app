package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.AddReaction
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.Message
import com.example.ui.theme.AwayAmber
import com.example.ui.theme.BubbleIncoming
import com.example.ui.theme.BubbleOutgoing
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.HollowCyan
import com.example.ui.theme.HollowCyanGlow
import com.example.ui.theme.HollowMagenta
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun MessageBubble(
    message: Message,
    isCurrentUser: Boolean,
    isAdmin: Boolean = false,
    onMediaClick: (String) -> Unit,
    onReactionClick: (String, String) -> Unit,
    onReplyClick: (Message) -> Unit,
    onDeleteMessage: ((Message) -> Unit)? = null,
    onReportSender: ((Message) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showReactionPicker by remember { mutableStateOf(false) }
    var isVoicePlaying by remember { mutableStateOf(false) }

    val bubbleShape = if (isCurrentUser) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    }

    val bubbleBg = if (isCurrentUser) BubbleOutgoing else BubbleIncoming
    val bubbleBorder = if (isCurrentUser) HollowCyan.copy(alpha = 0.35f) else CardBorderDark

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = if (isCurrentUser) Alignment.End else Alignment.Start
    ) {
        // Quick reaction bar popover when activated
        AnimatedVisibility(visible = showReactionPicker) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .testTag("reaction_picker_${message.id}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("❤️", "🔥", "😂", "🚀", "👍", "👏").forEach { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 20.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable {
                                    onReactionClick(message.id, emoji)
                                    showReactionPicker = false
                                }
                                .padding(4.dp)
                        )
                    }
                    IconButton(
                        onClick = { onReplyClick(message); showReactionPicker = false },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Reply,
                            contentDescription = "Reply",
                            tint = HollowCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    if (isAdmin || isCurrentUser) {
                        IconButton(
                            onClick = {
                                showReactionPicker = false
                                onDeleteMessage?.invoke(message)
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Message",
                                tint = com.example.ui.theme.BusyRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    if (!isCurrentUser) {
                        IconButton(
                            onClick = {
                                showReactionPicker = false
                                onReportSender?.invoke(message)
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Report User / Harassment",
                                tint = com.example.ui.theme.TikTokRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.widthIn(max = 320.dp),
            horizontalArrangement = if (isCurrentUser) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Top
        ) {
            if (!isCurrentUser) {
                UserAvatar(
                    name = message.senderName,
                    colorHex = message.senderAvatarColor,
                    size = 32.dp,
                    modifier = Modifier.padding(end = 8.dp, top = 2.dp)
                )
            }

            Column(
                horizontalAlignment = if (isCurrentUser) Alignment.End else Alignment.Start
            ) {
                // Sender name if in room and not me
                if (!isCurrentUser) {
                    Text(
                        text = message.senderName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = HollowCyanGlow,
                        modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
                    )
                }

                // Main Bubble
                Box(
                    modifier = Modifier
                        .clip(bubbleShape)
                        .background(bubbleBg)
                        .border(1.dp, bubbleBorder, bubbleShape)
                        .combinedClickable(
                            onClick = { },
                            onLongClick = { showReactionPicker = !showReactionPicker }
                        )
                        .padding(10.dp)
                ) {
                    Column {
                        // Replying To preview
                        if (!message.replyToText.isNullOrBlank()) {
                            Row(
                                modifier = Modifier
                                    .padding(bottom = 6.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black.copy(alpha = 0.25f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(28.dp)
                                        .background(HollowCyan)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = message.replyToSender ?: "Reply",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = HollowCyan
                                    )
                                    Text(
                                        text = message.replyToText,
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // Media Image Rendering
                        if (message.mediaType == "image" && !message.mediaUri.isNullOrBlank()) {
                            val uri = message.mediaUri
                            Box(
                                modifier = Modifier
                                    .padding(bottom = 6.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .fillMaxWidth()
                                    .clickable { onMediaClick(uri) }
                            ) {
                                when {
                                    uri.startsWith("res:drawable:hollow_room_banner") -> {
                                        androidx.compose.foundation.Image(
                                            painter = painterResource(id = R.drawable.hollow_room_banner_1791097569067),
                                            contentDescription = "Shared image",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(180.dp)
                                        )
                                    }
                                    uri.startsWith("res:drawable:hollow_media_hero") -> {
                                        androidx.compose.foundation.Image(
                                            painter = painterResource(id = R.drawable.hollow_media_hero_1791097588610),
                                            contentDescription = "Shared image",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(180.dp)
                                        )
                                    }
                                    else -> {
                                        AsyncImage(
                                            model = ImageRequest.Builder(LocalContext.current)
                                                .data(uri)
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = "Shared media",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(180.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Voice Message Rendering
                        if (message.mediaType == "voice") {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                IconButton(
                                    onClick = { isVoicePlaying = !isVoicePlaying },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (isVoicePlaying) HollowMagenta else HollowCyan)
                                ) {
                                    Icon(
                                        imageVector = if (isVoicePlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play voice note",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Waveform animation
                                AnimatedVoiceWaveform(isPlaying = isVoicePlaying)

                                Spacer(modifier = Modifier.width(8.dp))

                                Text(
                                    text = "0:${message.voiceDurationSec.toString().padStart(2, '0')}",
                                    fontSize = 11.sp,
                                    color = TextSecondaryDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Text content
                        if (message.text.isNotBlank()) {
                            Text(
                                text = message.text,
                                fontSize = 14.sp,
                                color = TextPrimaryDark,
                                lineHeight = 19.sp
                            )
                        }

                        // Timestamp & Status
                        Row(
                            modifier = Modifier
                                .align(Alignment.End)
                                .padding(top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestamp))
                            Text(
                                text = timeStr,
                                fontSize = 10.sp,
                                color = TextSecondaryDark
                            )

                            if (isCurrentUser) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = if (message.status == "read") Icons.Default.DoneAll else Icons.Default.Check,
                                    contentDescription = "Status",
                                    tint = if (message.status == "read") HollowCyan else TextSecondaryDark,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }

                // Emoji reaction chips underneath
                if (message.reactions.isNotEmpty()) {
                    FlowRow(
                        modifier = Modifier
                            .padding(top = 2.dp, start = 4.dp, end = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        message.reactions.forEach { (emoji, count) ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BubbleIncoming,
                                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onReactionClick(message.id, emoji) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = emoji, fontSize = 11.sp)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = count.toString(),
                                        fontSize = 10.sp,
                                        color = TextSecondaryDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnimatedVoiceWaveform(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val heights = listOf(10.dp, 18.dp, 14.dp, 24.dp, 16.dp, 20.dp, 12.dp, 22.dp)

    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height(26.dp)
    ) {
        heights.forEachIndexed { index, baseHeight ->
            val scale by infiniteTransition.animateFloat(
                initialValue = 0.4f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 350 + (index * 80)),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$index"
            )

            val currentHeight = if (isPlaying) baseHeight * scale else baseHeight * 0.5f

            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(currentHeight.coerceAtLeast(4.dp))
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(if (isPlaying) HollowCyan else TextSecondaryDark.copy(alpha = 0.5f))
            )
        }
    }
}
