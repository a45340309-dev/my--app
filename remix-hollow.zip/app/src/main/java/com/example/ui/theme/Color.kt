package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TikTok Dark Mode Palette
val TikTokDark = Color(0xFF000000)
val TikTokSurface = Color(0xFF121214)
val TikTokSurfaceVariant = Color(0xFF1B1B1F)
val TikTokCard = Color(0xFF161619)
val TikTokBorder = Color(0xFF2A2A30)

// TikTok Signature Neons
val TikTokRed = Color(0xFFFE2C55)
val TikTokCyan = Color(0xFF25F4EE)
val TikTokGold = Color(0xFFFACE15)
val TikTokWhite = Color(0xFFFFFFFF)
val TikTokMuted = Color(0xFF8A8B8F)

// Hollow Compatibility Aliases
val BackgroundDark = TikTokDark
val SurfaceDark = TikTokSurface
val SurfaceVariantDark = TikTokSurfaceVariant
val CardBackgroundDark = TikTokCard
val CardBorderDark = TikTokBorder

val HollowCyan = TikTokCyan
val HollowCyanGlow = Color(0xFF67FAF6)
val HollowViolet = Color(0xFF9B42F5)
val HollowIndigo = Color(0xFF5B36F5)
val HollowMagenta = TikTokRed

val TextPrimaryDark = TikTokWhite
val TextSecondaryDark = TikTokMuted
val TextTertiaryDark = Color(0xFF5F6065)

val OnlineGreen = Color(0xFF20D67B)
val AwayAmber = Color(0xFFFFB800)
val BusyRed = TikTokRed

val BubbleOutgoing = TikTokRed
val BubbleOutgoingGlow = Color(0xFFFF486E)
val BubbleIncoming = Color(0xFF1C1C22)

val AccentGradientStart = TikTokCyan
val AccentGradientEnd = TikTokRed

// Hollow Pakistan Neon Gen Z Palette
val HollowShinyBlack = Color(0xFF0A0A0A)
val HollowDeepBlack = Color(0xFF0A0A0A)
val HollowCardDark = Color(0xFF1A1A1A)
val HollowCardGlass = Color(0x221E1E2E)
val HollowNeonPurple = Color(0xFF8A2BE2)
val HollowNeonPurpleBright = Color(0xFFB026FF)
val HollowNeonBlue = Color(0xFF00BFFF)
val HollowNeonBlueSky = Color(0xFF00BFFF)
val HollowNeonPink = Color(0xFFFF1493)
val HollowGold = Color(0xFFFFD700)
val HollowSpeakingGreen = Color(0xFF00FF88)
val HollowGreenGlow = Color(0xFF00FF88)
