package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material.icons.outlined.Tag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.ChatRoom
import com.example.data.model.Message
import com.example.data.model.User
import com.example.ui.components.CreateRoomDialog
import com.example.ui.components.ProfileEditDialog
import com.example.ui.components.SafetyReportDialog
import com.example.ui.components.TrendingRoomsSection
import com.example.ui.components.UserAvatar
import com.example.ui.theme.BusyRed
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.HollowCyan
import com.example.ui.theme.HollowCyanGlow
import com.example.ui.theme.HollowMagenta
import com.example.ui.theme.HollowViolet
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokDark
import com.example.ui.theme.TikTokRed
import com.example.ui.theme.TikTokWhite
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.AppLanguage
import com.example.util.Strings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val publicRooms by viewModel.publicRooms.collectAsStateWithLifecycle()
    val directChats by viewModel.directChats.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val mediaStream by viewModel.mediaStream.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()

    val language by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val trendingRooms by viewModel.trendingRooms.collectAsStateWithLifecycle()
    val onlineUsersCount by viewModel.onlineUsersCount.collectAsStateWithLifecycle()
    val userToReport by viewModel.userToReport.collectAsStateWithLifecycle()
    val reportSuccessNotice by viewModel.reportSuccessNotice.collectAsStateWithLifecycle()

    val showCreateRoomDialog by viewModel.showCreateRoomDialog.collectAsStateWithLifecycle()
    val showProfileDialog by viewModel.showProfileDialog.collectAsStateWithLifecycle()
    val userMood by viewModel.userMood.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = TikTokDark,
        bottomBar = {
            HollowBottomNavigation(
                selectedTab = selectedTab,
                unreadMessagesCount = directChats.sumOf { it.unreadCount },
                language = language,
                onTabSelected = { viewModel.setSelectedTab(it) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Top Header with Pakistan Branding, Online Count & Language Toggle
            TikTokTopHeader(
                currentUser = currentUser,
                language = language,
                onlineCount = onlineUsersCount,
                isAdmin = isAdmin,
                onLanguageToggle = { viewModel.toggleLanguage() },
                onAdminClick = { viewModel.openAdminPanel() },
                onProfileClick = { viewModel.setSelectedTab(2) }
            )

            // Girls Safe Space Banner (on Rooms & Messages tab)
            if (selectedTab != 2) {
                GirlsSafeSpacePill(language = language)
            }

            // Report Success Notice Banner
            AnimatedVisibility(visible = reportSuccessNotice != null) {
                Surface(
                    color = OnlineGreen.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = reportSuccessNotice ?: "",
                            fontSize = 12.sp,
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearReportSuccessNotice() },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color.White)
                        }
                    }
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Tab 1: Rooms Feed
                    // Featured Live Voice Room Banner
                    LiveVoiceRoomBanner(
                        userMood = userMood,
                        onEnterVoiceRoom = { viewModel.openRoom("room_karachi_night_vibes") },
                        onChangeMood = { viewModel.openMoodOnboarding() }
                    )

                    if (searchQuery.isBlank()) {
                        TrendingRoomsSection(
                            trendingRooms = trendingRooms,
                            language = language,
                            onRoomClick = { viewModel.openRoom(it.id) }
                        )
                    }

                    SearchBarRow(
                        query = searchQuery,
                        language = language,
                        onQueryChange = { viewModel.setSearchQuery(it) }
                    )

                    RoomsTabContent(
                        rooms = publicRooms,
                        selectedCategory = selectedCategory,
                        language = language,
                        onSelectCategory = { viewModel.setSelectedCategory(it) },
                        onRoomClick = { viewModel.openRoom(it.id) },
                        onCreateRoomClick = { viewModel.setCreateRoomDialogVisible(true) }
                    )
                }
                1 -> {
                    // Tab 2: Messages / Direct Chats Screen
                    DirectChatsTabContent(
                        directChats = directChats,
                        users = allUsers.filter { !it.isCurrentUser },
                        language = language,
                        onChatClick = { viewModel.openRoom(it.id) },
                        onUserClick = { viewModel.startDirectChat(it) },
                        onReportUser = { viewModel.openReportDialog(it) }
                    )
                }
                2 -> {
                    // Tab 3: Profile Screen
                    val context = LocalContext.current
                    ProfileTabContent(
                        user = currentUser,
                        language = language,
                        isAdmin = isAdmin,
                        publicRoomsCount = publicRooms.size,
                        directChatsCount = directChats.size,
                        onBack = { viewModel.setSelectedTab(0) },
                        onEditProfileClick = { viewModel.setProfileDialogVisible(true) },
                        onSaveProfile = { name, handle, status, color ->
                            viewModel.updateProfile(name, handle, status, color)
                        },
                        onOpenAdmin = { viewModel.openAdminPanel() },
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onSignOut = {
                            val credentialManager = androidx.credentials.CredentialManager.create(context)
                            viewModel.logOut(context, credentialManager) {}
                        }
                    )
                }
            }
        }
    }

    if (showCreateRoomDialog) {
        CreateRoomDialog(
            onDismiss = { viewModel.setCreateRoomDialogVisible(false) },
            onCreate = { title, topic, category ->
                viewModel.createRoom(title, topic, category)
            }
        )
    }

    if (showProfileDialog) {
        val context = LocalContext.current
        val credentialManager = remember { androidx.credentials.CredentialManager.create(context) }
        ProfileEditDialog(
            user = currentUser,
            onDismiss = { viewModel.setProfileDialogVisible(false) },
            onSave = { name, handle, status, color ->
                viewModel.updateProfile(name, handle, status, color)
            },
            onSignOut = {
                viewModel.logOut(context, credentialManager) {}
            },
            onOpenAdmin = {
                viewModel.openAdminPanel()
            }
        )
    }

    // Safety Report Dialog for Girls and Community
    userToReport?.let { user ->
        SafetyReportDialog(
            user = user,
            language = language,
            onDismiss = { viewModel.closeReportDialog() },
            onSubmitReport = { reason, details, alsoBlock ->
                viewModel.submitSafetyReport(user, reason, details)
                if (alsoBlock) {
                    viewModel.toggleUserBlock(user.userId, false)
                }
            }
        )
    }
}

@Composable
fun TikTokTopHeader(
    currentUser: User?,
    language: AppLanguage,
    onlineCount: Int,
    isAdmin: Boolean,
    onLanguageToggle: () -> Unit,
    onAdminClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Glowing TikTok aesthetic Pakistan badge
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.sweepGradient(listOf(TikTokRed, TikTokCyan, TikTokWhite, TikTokRed))
                    )
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(TikTokDark),
                contentAlignment = Alignment.Center
            ) {
                Text("🇵🇰", fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = Strings.appTitle(language),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = Color.White
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(OnlineGreen)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = Strings.onlineStatus(language, onlineCount),
                        fontSize = 10.sp,
                        color = TikTokCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Language Indicator (English)
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("language_toggle_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TikTokCyan
                    )
                }
            }

            if (isAdmin) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = TikTokRed.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TikTokRed),
                    modifier = Modifier
                        .clickable { onAdminClick() }
                        .padding(end = 8.dp)
                        .testTag("admin_panel_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Admin",
                            tint = TikTokRed,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Admin",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // User Avatar
            Box(
                modifier = Modifier
                    .clickable { onProfileClick() }
                    .testTag("current_user_avatar_button")
            ) {
                UserAvatar(
                    name = currentUser?.displayName ?: "Alex",
                    colorHex = currentUser?.avatarColorHex ?: "#FE2C55",
                    size = 38.dp,
                    showOnlineBadge = true,
                    isOnline = true
                )
            }
        }
    }
}

@Composable
fun GirlsSafeSpacePill(language: AppLanguage) {
    Surface(
        color = CardBackgroundDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, TikTokCyan.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = TikTokCyan,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Strings.safeSpaceBadge(language),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TikTokCyan
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "24/7 Moderated",
                fontSize = 9.sp,
                color = TextSecondaryDark
            )
        }
    }
}

@Composable
fun SearchBarRow(
    query: String,
    language: AppLanguage,
    onQueryChange: (String) -> Unit
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        placeholder = {
            Text(
                text = Strings.searchPlaceholder(language),
                fontSize = 12.sp,
                color = TextSecondaryDark
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = TextSecondaryDark,
                modifier = Modifier.size(18.dp)
            )
        },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear search",
                        tint = TextSecondaryDark,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = SurfaceVariantDark,
            unfocusedContainerColor = SurfaceVariantDark,
            focusedBorderColor = TikTokCyan,
            unfocusedBorderColor = CardBorderDark,
            focusedTextColor = TextPrimaryDark,
            unfocusedTextColor = TextPrimaryDark,
            cursorColor = TikTokCyan
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .testTag("home_search_input")
    )
}

@Composable
fun HollowBottomNavigation(
    selectedTab: Int,
    unreadMessagesCount: Int,
    language: AppLanguage,
    onTabSelected: (Int) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xEE0D0D15),
        contentColor = TikTokWhite,
        tonalElevation = 10.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color(0x55B026FF),
                        Color(0x6600F2FE),
                        Color(0x55B026FF)
                    )
                ),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            )
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .testTag("bottom_navigation_bar")
    ) {
        // Tab 1: Rooms (Hashtag icon with purple neon glow)
        NavigationBarItem(
            selected = selectedTab == 0,
            onClick = { onTabSelected(0) },
            icon = {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = if (selectedTab == 0) {
                        Modifier
                            .size(32.dp)
                            .background(Color(0x33B026FF), CircleShape)
                    } else Modifier
                ) {
                    Icon(
                        imageVector = if (selectedTab == 0) Icons.Filled.Tag else Icons.Outlined.Tag,
                        contentDescription = "Rooms",
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            label = {
                Text(
                    text = "Rooms",
                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFFB026FF),
                selectedTextColor = Color.White,
                unselectedIconColor = TextSecondaryDark,
                unselectedTextColor = TextSecondaryDark,
                indicatorColor = Color(0x33B026FF)
            ),
            modifier = Modifier.testTag("bottom_tab_rooms")
        )

        // Tab 2: Messages / Direct Chats (Chat Bubble icon)
        NavigationBarItem(
            selected = selectedTab == 1,
            onClick = { onTabSelected(1) },
            icon = {
                if (unreadMessagesCount > 0) {
                    BadgedBox(
                        badge = {
                            Badge(
                                containerColor = TikTokRed,
                                contentColor = Color.White
                            ) {
                                Text(unreadMessagesCount.toString(), fontSize = 10.sp)
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (selectedTab == 1) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "Messages",
                            modifier = Modifier.size(22.dp)
                        )
                    }
                } else {
                    Icon(
                        imageVector = if (selectedTab == 1) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Messages",
                        modifier = Modifier.size(22.dp)
                    )
                }
            },
            label = {
                Text(
                    text = "Messages",
                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = TikTokCyan,
                selectedTextColor = TikTokCyan,
                unselectedIconColor = TextSecondaryDark,
                unselectedTextColor = TextSecondaryDark,
                indicatorColor = TikTokCyan.copy(alpha = 0.18f)
            ),
            modifier = Modifier.testTag("bottom_tab_messages")
        )

        // Tab 4 (Special): Badshah PK with Amber Glow & LIVE Badge
        NavigationBarItem(
            selected = selectedTab == 3,
            onClick = { onTabSelected(3) },
            icon = {
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                if (selectedTab == 3) Color(0x66FFD700) else Color(0x33FFB300)
                            )
                    )
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Badshah PK",
                        modifier = Modifier.size(26.dp)
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TikTokRed,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-4).dp)
                    ) {
                        Text(
                            text = "LIVE",
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                        )
                    }
                }
            },
            label = {
                Text(
                    text = "Badshah PK",
                    fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFFFFD700),
                selectedTextColor = Color(0xFFFFD700),
                unselectedIconColor = Color(0xFFFFC107),
                unselectedTextColor = Color(0xFFFFD700).copy(alpha = 0.7f),
                indicatorColor = Color(0x44FFD700)
            ),
            modifier = Modifier.testTag("bottom_tab_badshah_pk")
        )

        // Tab 3: Profile (Person icon with purple neon glow)
        NavigationBarItem(
            selected = selectedTab == 2,
            onClick = { onTabSelected(2) },
            icon = {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = if (selectedTab == 2) {
                        Modifier
                            .size(32.dp)
                            .background(Color(0x33B026FF), CircleShape)
                    } else Modifier
                ) {
                    Icon(
                        imageVector = if (selectedTab == 2) Icons.Filled.Person else Icons.Outlined.PersonOutline,
                        contentDescription = "Profile",
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            label = {
                Text(
                    text = "Profile",
                    fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFFC084FC),
                selectedTextColor = Color(0xFFC084FC),
                unselectedIconColor = TextSecondaryDark,
                unselectedTextColor = TextSecondaryDark,
                indicatorColor = Color(0xFF9333EA).copy(alpha = 0.35f)
            ),
            modifier = Modifier.testTag("bottom_tab_profile")
        )
    }
}

@Composable
fun RoomsTabContent(
    rooms: List<ChatRoom>,
    selectedCategory: String,
    language: AppLanguage,
    onSelectCategory: (String) -> Unit,
    onRoomClick: (ChatRoom) -> Unit,
    onCreateRoomClick: (() -> Unit)? = null
) {
    val categories = listOf(
        "All" to Strings.catAll(language),
        "Cities" to Strings.catCities(language),
        "Pak Jobs" to Strings.catJobs(language),
        "University" to Strings.catUniversity(language),
        "Rishta" to Strings.catRishta(language),
        "Cricket PSL" to Strings.catCricket(language),
        "Memes" to Strings.catMemes(language),
        "Gaming" to Strings.catGaming(language)
    )

    Column(modifier = Modifier.fillMaxSize()) {
        // Pakistan & Interests Category Pills
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (onCreateRoomClick != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = TikTokRed.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TikTokRed.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onCreateRoomClick() }
                            .testTag("create_room_chip")
                    ) {
                        Text(
                            text = "✨ ${Strings.newRoom(language)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TikTokRed,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
            items(categories) { (catKey, catLabel) ->
                val isSelected = catKey == selectedCategory
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) TikTokRed else SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) TikTokRed else CardBorderDark
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onSelectCategory(catKey) }
                ) {
                    Text(
                        text = catLabel,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else TextSecondaryDark,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Rooms List
        if (rooms.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No rooms found for this category",
                    color = TextSecondaryDark,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                items(rooms, key = { it.id }) { room ->
                    RoomListItem(room = room, onClick = { onRoomClick(room) })
                }
            }
        }
    }
}

@Composable
fun RoomListItem(
    room: ChatRoom,
    onClick: () -> Unit
) {
    val formattedTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(room.lastMessageTimestamp))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("room_item_${room.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Room Icon / Banner Avatar
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceVariantDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.pakistan_hero_banner_1791099557518),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )
            Text(
                text = if (room.isDirectMessage) "@" else "#",
                fontWeight = FontWeight.Black,
                color = TikTokCyan,
                fontSize = 20.sp
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (room.isDirectMessage) room.title else "#${room.title}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = SurfaceVariantDark
                    ) {
                        Text(
                            text = room.category,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TikTokCyan,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }

                Text(
                    text = formattedTime,
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = if (room.lastMessageText.isNotBlank()) {
                    "${room.lastMessageSender}: ${room.lastMessageText}"
                } else {
                    room.topic
                },
                fontSize = 12.sp,
                color = TextSecondaryDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(3.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(OnlineGreen)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${room.memberCount} members",
                    fontSize = 10.sp,
                    color = TextSecondaryDark
                )
            }
        }
    }
}

@Composable
fun DirectChatsTabContent(
    directChats: List<ChatRoom>,
    users: List<User>,
    language: AppLanguage,
    onChatClick: (ChatRoom) -> Unit,
    onUserClick: (User) -> Unit,
    onReportUser: (User) -> Unit
) {
    var chatSearchQuery by remember { mutableStateOf("") }
    val filteredChats = remember(directChats, chatSearchQuery) {
        if (chatSearchQuery.isBlank()) directChats
        else directChats.filter {
            it.title.contains(chatSearchQuery, ignoreCase = true) ||
            it.lastMessageText.contains(chatSearchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Direct Messages Search Bar
        OutlinedTextField(
            value = chatSearchQuery,
            onValueChange = { chatSearchQuery = it },
            placeholder = {
                Text(
                    text = "Search direct messages or friends...",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = TextSecondaryDark,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (chatSearchQuery.isNotEmpty()) {
                    IconButton(onClick = { chatSearchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear",
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SurfaceVariantDark,
                unfocusedContainerColor = SurfaceVariantDark,
                focusedBorderColor = TikTokCyan,
                unfocusedBorderColor = CardBorderDark,
                focusedTextColor = TextPrimaryDark,
                unfocusedTextColor = TextPrimaryDark,
                cursorColor = TikTokCyan
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .testTag("direct_chat_search_input")
        )

        // Online Users Carousel
        Text(
            text = "Active Community (Tap to Message)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TikTokCyan,
            modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 8.dp)
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(users) { user ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onUserClick(user) }
                        .padding(2.dp)
                        .testTag("user_avatar_${user.userId}")
                ) {
                    UserAvatar(
                        name = user.displayName,
                        colorHex = user.avatarColorHex,
                        size = 50.dp,
                        showOnlineBadge = true,
                        isOnline = user.isOnline
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = user.displayName.split(" ").firstOrNull() ?: user.displayName,
                        fontSize = 11.sp,
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "🛡️ Report",
                        fontSize = 9.sp,
                        color = BusyRed,
                        modifier = Modifier
                            .clickable { onReportUser(user) }
                            .padding(top = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Direct Chats Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Direct Conversations",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
            )
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = SurfaceVariantDark
            ) {
                Text(
                    text = "${filteredChats.size} chats",
                    fontSize = 10.sp,
                    color = TikTokCyan,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        if (filteredChats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(TikTokCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChatBubble,
                                contentDescription = null,
                                tint = TikTokCyan,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "No Direct Messages Yet",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TikTokWhite
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap any active community member above to start a secure, private one-on-one conversation.",
                            color = TextSecondaryDark,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                items(filteredChats, key = { it.id }) { chat ->
                    RoomListItem(room = chat, onClick = { onChatClick(chat) })
                }
            }
        }
    }
}

@Composable
fun ProfileTabContent(
    user: User?,
    language: AppLanguage,
    isAdmin: Boolean,
    publicRoomsCount: Int,
    directChatsCount: Int,
    onBack: () -> Unit,
    onEditProfileClick: () -> Unit,
    onSaveProfile: (String, String, String, String) -> Unit,
    onOpenAdmin: () -> Unit,
    onToggleLanguage: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showMenu by remember { mutableStateOf(false) }

    val displayName = user?.displayName?.ifBlank { "Pakistan Explorer" } ?: "Pakistan Explorer"
    val username = if (user?.handle.isNullOrBlank()) "@pakistanexplorer" else user!!.handle
    val bio = user?.statusText?.ifBlank { "Exploring Pakistan 🇵🇰 | Karachi Vibes 🌙" } ?: "Exploring Pakistan 🇵🇰 | Karachi Vibes 🌙"
    val userIdStr = "823749"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0D15))
    ) {
        // Subtle ambient neon purple/blue glows behind profile header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0x358A2BE2),
                            Color(0x2000F2FE),
                            Color.Transparent
                        ),
                        center = Offset(540f, 220f),
                        radius = 650f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 92.dp)
        ) {
            // Top bar with back arrow left and 3 dots menu right
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("profile_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Text(
                    text = "Profile",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("profile_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Menu",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier
                            .background(Color(0xFF161622))
                            .border(1.dp, CardBorderDark, RoundedCornerShape(12.dp))
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit Profile", color = Color.White) },
                            onClick = {
                                showMenu = false
                                onEditProfileClick()
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = TikTokCyan)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Women & Community Safety", color = Color.White) },
                            onClick = {
                                showMenu = false
                                Toast.makeText(context, "National Helplines: 1099 (Human Rights) | 1121 (Child/Women)", Toast.LENGTH_LONG).show()
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Shield, contentDescription = null, tint = OnlineGreen)
                            }
                        )
                        if (isAdmin) {
                            DropdownMenuItem(
                                text = { Text("Admin Control Panel", color = TikTokRed) },
                                onClick = {
                                    showMenu = false
                                    onOpenAdmin()
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Shield, contentDescription = null, tint = TikTokRed)
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Switch Account / Sign Out", color = Color(0xFFA0A0B2)) },
                            onClick = {
                                showMenu = false
                                onSignOut()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Center large circular profile photo with double neon border glow (purple and blue) and blue verified badge at bottom right
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(128.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Purple & Blue Neon Glow Ring
                Box(
                    modifier = Modifier
                        .size(126.dp)
                        .clip(CircleShape)
                        .border(
                            width = 3.dp,
                            brush = Brush.sweepGradient(
                                listOf(
                                    Color(0xFFB026FF),
                                    Color(0xFF00F2FE),
                                    Color(0xFF8A2BE2),
                                    Color(0xFF00D4FF),
                                    Color(0xFFB026FF)
                                )
                            ),
                            shape = CircleShape
                        )
                        .padding(5.dp)
                        // Inner Blue Neon Ring
                        .border(
                            width = 2.5.dp,
                            color = Color(0xFF00F2FE),
                            shape = CircleShape
                        )
                        .clip(CircleShape)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.pakistan_avatar_1791194955321),
                        contentDescription = "Profile Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Blue verified badge at bottom right
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = (-4).dp, y = (-2).dp)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1D9BF0))
                        .border(2.5.dp, Color(0xFF0D0D15), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Verified Badge",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Display Name: 'Pakistan Explorer' bold white
            Text(
                text = displayName,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                modifier = Modifier.align(Alignment.CenterHorizontally),
                letterSpacing = (-0.3).sp
            )

            Spacer(modifier = Modifier.height(3.dp))

            // @username: '@pakistanexplorer' grey
            Text(
                text = username,
                fontSize = 14.sp,
                color = Color(0xFFA0A0B2),
                fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Bio: 'Exploring Pakistan 🇵🇰 | Karachi Vibes 🌙'
            Text(
                text = bio,
                fontSize = 13.5.sp,
                color = Color(0xFFE2E8F0),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(horizontal = 32.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // ID: 823749
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E1E2E).copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF2E2E44)),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                        clipboardManager.setText(AnnotatedString(userIdStr))
                        Toast.makeText(context, "ID: $userIdStr copied to clipboard!", Toast.LENGTH_SHORT).show()
                    }
                    .testTag("profile_id_chip")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "ID: $userIdStr",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFCBD5E1)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy ID",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Glossy gradient button from purple to blue with text 'Edit Profile'
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .fillMaxWidth(0.72f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color(0xFF8A2BE2),
                                Color(0xFF6B21A8),
                                Color(0xFF0284C7),
                                Color(0xFF00F2FE)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                Color(0x99FFFFFF),
                                Color(0x22FFFFFF)
                            )
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .clickable { onEditProfileClick() }
                    .testTag("edit_profile_gradient_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Edit Profile",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Stats row: 128.4K Followers, 892 Following, 1,024 Friends
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141420).copy(alpha = 0.9f)),
                border = BorderStroke(1.dp, Color(0xFF26263A)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp, horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Followers
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "128.4K",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Followers",
                            fontSize = 11.5.sp,
                            color = Color(0xFFA0A0B2),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Vertical Divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(28.dp)
                            .background(Color(0xFF2E2E44))
                    )

                    // Following
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "892",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Following",
                            fontSize = 11.5.sp,
                            color = Color(0xFFA0A0B2),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Vertical Divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(28.dp)
                            .background(Color(0xFF2E2E44))
                    )

                    // Friends
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "1,024",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Friends",
                            fontSize = 11.5.sp,
                            color = Color(0xFFA0A0B2),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Gen Z TikTok Pakistan Showcase Badges
            Text(
                text = "Community Badges & Spaces",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFC084FC),
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1B1B2A),
                    border = BorderStroke(1.dp, Color(0xFF33334D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🇵🇰", fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Pakistan Pioneer",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1B1B2A),
                    border = BorderStroke(1.dp, Color(0xFF33334D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🌊", fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Karachi Vibes",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TikTokCyan
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1B1B2A),
                    border = BorderStroke(1.dp, Color(0xFF33334D)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🛡️", fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Safe Community",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = OnlineGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Safety & Helpline Banner
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141420),
                border = BorderStroke(1.dp, Color(0xFF26263A)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00F2FE).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color(0xFF00F2FE),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Pakistan Women & Youth Safe Space",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Zero harassment tolerance. Helplines: 1099 | 1121",
                            fontSize = 10.5.sp,
                            color = Color(0xFFA0A0B2)
                        )
                    }
                }
            }

            if (isAdmin) {
                Spacer(modifier = Modifier.height(12.dp))
                // Admin Button
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = TikTokRed.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, TikTokRed.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onOpenAdmin() }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = TikTokRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Admin Control Panel",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Text(
                            text = "Open >",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TikTokRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LiveVoiceRoomBanner(
    userMood: String?,
    onEnterVoiceRoom: () -> Unit,
    onChangeMood: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { onEnterVoiceRoom() }
            .testTag("featured_voice_lounge_banner"),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF141424),
        border = BorderStroke(
            1.2.dp,
            Brush.horizontalGradient(
                listOf(Color(0xFF8A2BE2), Color(0xFF00F2FE))
            )
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFE2C55))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE 1.2K LISTENING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFE2C55),
                        letterSpacing = 0.5.sp
                    )
                }

                // Mood Tag Chip (Clickable to change mood!)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF221A35),
                    border = BorderStroke(1.dp, Color(0xFFB026FF).copy(alpha = 0.6f)),
                    modifier = Modifier.clickable { onChangeMood() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Vibe: ${userMood ?: "Chill"} ✨",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F2FE)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Karachi Night Vibes 🌙",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "Host Ahmed 👑 & Speakers Sara, Zain • 8 On Stage",
                        fontSize = 11.5.sp,
                        color = Color(0xFFB0B0C4)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF8A2BE2), Color(0xFF00F2FE))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = "Join Lounge 🎙️",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
