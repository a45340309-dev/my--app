package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.BusyRed
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.HollowCyan
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokDark
import com.example.ui.theme.TikTokRed
import com.example.util.AppLanguage
import androidx.compose.material3.ExperimentalMaterial3Api

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalAndPrivacyDialog(
    language: AppLanguage = AppLanguage.ENGLISH,
    onDismiss: () -> Unit,
    onDeleteAccountAndData: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Privacy Policy, 1: Terms & Conditions, 2: Account Deletion
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            shape = RoundedCornerShape(20.dp),
            color = TikTokDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(TikTokRed.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PrivacyTip,
                                contentDescription = null,
                                tint = TikTokRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Privacy & Terms",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_legal_dialog")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryDark)
                    }
                }

                // Tabs
                val tabs = listOf("Privacy Policy", "Terms & Conditions", "Delete Account")

                SecondaryTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = SurfaceDark,
                    contentColor = TikTokCyan,
                    indicator = {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(selectedTab),
                            color = if (selectedTab == 2) TikTokRed else TikTokCyan,
                            height = 3.dp
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == index) {
                                        if (index == 2) TikTokRed else TikTokCyan
                                    } else TextSecondaryDark
                                )
                            }
                        )
                    }
                }

                // Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (selectedTab) {
                        0 -> PrivacyPolicyContent()
                        1 -> TermsAndConditionsContent()
                        2 -> DeleteAccountContent(
                            onRequestDelete = { showDeleteConfirmDialog = true }
                        )
                    }
                }

                // Footer Close
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceVariantDark, contentColor = TextPrimaryDark),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Done")
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text(
                    text = "Permanently Delete Account & Data?",
                    color = TextPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = "In compliance with Google Play Policy, this will permanently purge your user profile, Google email reference, handle, and personal data from our Firestore databases. You will be signed out immediately.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDismiss()
                        onDeleteAccountAndData()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TikTokRed, contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("confirm_delete_account_button")
                ) {
                    Text("Yes, Delete Everything", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            }
        )
    }
}

@Composable
fun PrivacyPolicyContent() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            color = TikTokCyan.copy(alpha = 0.1f),
            border = androidx.compose.foundation.BorderStroke(1.dp, TikTokCyan.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = TikTokCyan)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "We collect name, email, and chat messages strictly to provide the chat service. We DO NOT sell your data.",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TikTokCyan
                )
            }
        }

        LegalSection(
            title = "1. Information We Collect",
            body = "When you authenticate via Google Sign-In, we receive basic profile info (Display Name, Google Email, Avatar). When you participate in chat rooms, your sent text messages, voice recordings, and shared images are stored in Google Cloud Firestore exclusively to enable real-time messaging between users."
        )

        LegalSection(
            title = "2. How We Use and Protect Your Data",
            body = "We process your data strictly to display community rooms, deliver direct messages, and enforce community safety (including auto abuse filters and girls safe space reporting). We DO NOT sell, trade, or monetize personal data to third-party ad networks or brokers."
        )

        LegalSection(
            title = "3. Firebase Zero-Trust Security",
            body = "All communication is safeguarded by strict Firebase Cloud Firestore security rules. Unauthenticated access is denied by default. Users can delete their own messages at any time."
        )
    }
}

@Composable
fun TermsAndConditionsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSection(
            title = "1. Respectful Conduct",
            body = "Hollow brings together people from across Vehari, Lahore, Karachi, Islamabad, Multan, Faisalabad, Peshawar, and Quetta. Members must treat all participants with respect and courtesy."
        )

        LegalSection(
            title = "2. Women & Girls Safe Space Protection",
            body = "We maintain zero tolerance for harassment, stalking, or inappropriate DMs directed at women and community members. Any user can report or block offenders immediately, triggering real-time escalation to the admin moderation team."
        )

        LegalSection(
            title = "3. Automated Abuse & Profanity Filter",
            body = "Our built-in abuse engine automatically filters vulgarity and profanity. Persistent violations will result in administrative room removal or permanent account suspension."
        )
    }
}

@Composable
fun DeleteAccountContent(
    onRequestDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackgroundDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, TikTokRed.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = TikTokRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Delete My Account & Delete My Data",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "In compliance with Google Play Policy on User Data & Account Deletion: You have the right to request full erasure of your account and associated personal data at any time. Clicking below permanently deletes your user profile and database records.",
                fontSize = 12.sp,
                color = TextSecondaryDark,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onRequestDelete,
                colors = ButtonDefaults.buttonColors(containerColor = TikTokRed, contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("delete_my_account_and_data_button")
            ) {
                Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Delete My Account & Delete My Data",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun LegalSection(title: String, body: String) {
    Column {
        Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = body, fontSize = 12.sp, color = TextSecondaryDark, lineHeight = 17.sp)
    }
}
