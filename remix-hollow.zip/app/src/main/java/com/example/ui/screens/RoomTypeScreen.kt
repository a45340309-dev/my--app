package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatRoom
import com.example.ui.components.CreateRoomDialog
import com.example.ui.theme.HollowCardDark
import com.example.ui.theme.HollowDeepBlack
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowGreenGlow
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.TikTokRed
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun RoomTypeScreen(
    title: String,
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    onEveryoneRoomClick: () -> Unit,
    onPrivateRoomClick: () -> Unit,
    onRoomClick: (ChatRoom) -> Unit,
    onCreateRoomClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val publicRooms by viewModel.publicRooms.collectAsStateWithLifecycle()
    val nearbyRooms by viewModel.nearbyRooms.collectAsStateWithLifecycle()
    val showCreateRoomDialog by viewModel.showCreateRoomDialog.collectAsStateWithLifecycle()

    val roomsToDisplay = if (publicRooms.isNotEmpty()) publicRooms else nearbyRooms

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        containerColor = HollowDeepBlack,
        bottomBar = {
            GlassmorphicHollowBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    viewModel.setSelectedTab(tab)
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HollowDeepBlack)
        ) {
            // Ambient neon purple #8A2BE2 and blue #00BFFF glow gradients
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0x358A2BE2),
                                Color(0x2000BFFF),
                                Color.Transparent
                            ),
                            center = Offset(540f, 150f),
                            radius = 650f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                // Top Bar with Back Arrow and Title: "Combine - Vehari"
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF161624))
                                .testTag("room_type_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = title,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = "Select lounge type or join live rooms",
                                fontSize = 11.5.sp,
                                color = Color(0xFFA0A0B2)
                            )
                        }
                    }

                    // Create Room Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(HollowNeonPurple, HollowNeonBlueSky)
                                )
                            )
                            .border(1.dp, Color(0x99FFFFFF), RoundedCornerShape(16.dp))
                            .clickable { onCreateRoomClick() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("room_type_create_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "Create",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // TOP 2 BUTTONS:
                // 1. Everyone Room - Open to All (green glow #00FF88)
                // 2. Private Room - Friends Only (purple glow #8A2BE2)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Button 1: Everyone Room
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { onEveryoneRoomClick() }
                            .testTag("everyone_room_button"),
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF132219),
                        border = BorderStroke(
                            1.5.dp,
                            HollowGreenGlow
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(HollowGreenGlow.copy(alpha = 0.2f))
                                        .border(1.2.dp, HollowGreenGlow, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Groups,
                                        contentDescription = "Everyone Room",
                                        tint = HollowGreenGlow,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "Everyone Room",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Open to All",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = HollowGreenGlow
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Public room • No password needed",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFFA0D0B5)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = HollowGreenGlow.copy(alpha = 0.18f),
                                border = BorderStroke(1.dp, HollowGreenGlow)
                            ) {
                                Text(
                                    text = "OPEN 🌐",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = HollowGreenGlow,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Button 2: Private Room
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { onPrivateRoomClick() }
                            .testTag("private_room_button"),
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF1E1428),
                        border = BorderStroke(
                            1.5.dp,
                            HollowNeonPurple
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(HollowNeonPurple.copy(alpha = 0.25f))
                                        .border(1.2.dp, HollowNeonPurple, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Private Room",
                                        tint = HollowNeonPurple,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "Private Room",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Friends Only",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = HollowNeonPurple
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Protected with 4-digit password",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFFD0B0F0)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = HollowNeonPurple.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, HollowNeonPurple)
                            ) {
                                Text(
                                    text = "PIN 🔒",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = HollowNeonPurple,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Section Title: Scrollable list of all Live Rooms
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Live Voice Rooms",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Text(
                        text = "${roomsToDisplay.size} Active",
                        fontSize = 11.sp,
                        color = HollowNeonBlueSky,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable list of all Live Rooms with room name, host name, listener count
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(roomsToDisplay, key = { it.id }) { room ->
                        LiveRoomCardItem(
                            room = room,
                            onClick = { onRoomClick(room) }
                        )
                    }
                }
            }
        }
    }

    if (showCreateRoomDialog) {
        CreateRoomDialog(
            onDismiss = { viewModel.setCreateRoomDialogVisible(false) },
            onCreate = { title, topic, category ->
                viewModel.createRoom(title, topic, category)
            }
        )
    }
}

@Composable
fun LiveRoomCardItem(
    room: ChatRoom,
    onClick: () -> Unit
) {
    val isVehari = room.title.contains("Vehari", ignoreCase = true) || room.id == "room_vehari"
    val isPrivate = room.title.contains("Private", ignoreCase = true) || room.topic.contains("Private", ignoreCase = true)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag("live_room_item_${room.id}"),
        shape = RoundedCornerShape(18.dp),
        color = HollowCardDark,
        border = BorderStroke(
            width = if (isVehari) 1.5.dp else 1.dp,
            color = when {
                isVehari -> HollowGold.copy(alpha = 0.8f)
                isPrivate -> HollowNeonPurple.copy(alpha = 0.7f)
                else -> Color(0xFF282838)
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Room Avatar
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isVehari -> Color(0x33FFD700)
                                isPrivate -> Color(0x338A2BE2)
                                else -> Color(0xFF1E1E2E)
                            }
                        )
                        .border(
                            1.dp,
                            when {
                                isVehari -> HollowGold
                                isPrivate -> HollowNeonPurple
                                else -> HollowNeonBlueSky
                            },
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when {
                            isVehari -> "👑"
                            isPrivate -> "🔒"
                            else -> "🎙️"
                        },
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    // Room name
                    Text(
                        text = room.title,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // Host name + topic
                    val hostName = when {
                        room.lastMessageSender.isNotBlank() && room.lastMessageSender != "Hollow Bot" -> room.lastMessageSender
                        isVehari -> "Host Tariq 👑"
                        else -> "Host Ahmed 👑"
                    }

                    Text(
                        text = "$hostName • ${room.topic}",
                        fontSize = 11.sp,
                        color = Color(0xFFA0A0B2),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Listener count & Live badge
            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF2C101A),
                    border = BorderStroke(1.dp, TikTokRed.copy(alpha = 0.7f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(TikTokRed)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LIVE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TikTokRed
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = "${room.memberCount} Listeners",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = HollowNeonBlueSky
                )
            }
        }
    }
}
