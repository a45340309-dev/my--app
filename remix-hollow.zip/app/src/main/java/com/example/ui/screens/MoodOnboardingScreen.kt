package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HollowNeonBlue
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.HollowShinyBlack

data class MoodItem(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val glowColor: Color,
    val tag: String
)

val moodItems = listOf(
    MoodItem(
        id = "happy",
        emoji = "😊",
        title = "Happy",
        description = "Positive energy & laughs",
        glowColor = Color(0xFFFFD700),
        tag = "Happy"
    ),
    MoodItem(
        id = "sad",
        emoji = "🥺",
        title = "Sad",
        description = "Need a listening ear",
        glowColor = Color(0xFF00D4FF),
        tag = "Sad"
    ),
    MoodItem(
        id = "bored",
        emoji = "🥱",
        title = "Bored",
        description = "Late-night masti & banter",
        glowColor = Color(0xFFB026FF),
        tag = "Bored"
    ),
    MoodItem(
        id = "anxious",
        emoji = "😰",
        title = "Anxious",
        description = "Calm talks & safe space",
        glowColor = Color(0xFF00F5A0),
        tag = "Anxious"
    ),
    MoodItem(
        id = "chill",
        emoji = "😎",
        title = "Chill",
        description = "Lo-fi music & chai vibes",
        glowColor = Color(0xFF00F2FE),
        tag = "Chill"
    ),
    MoodItem(
        id = "motivated",
        emoji = "🔥",
        title = "Motivated",
        description = "Hustle, career & ideas",
        glowColor = Color(0xFFFF2E93),
        tag = "Motivated"
    )
)

@Composable
fun MoodOnboardingScreen(
    onDismiss: () -> Unit,
    onMoodSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedMoodId by remember { mutableStateOf("chill") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(HollowShinyBlack)
            .statusBarsPadding()
    ) {
        // Ambient purple & blue neon radial glows
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0x358A2BE2),
                            Color(0x2000F2FE),
                            Color.Transparent
                        ),
                        center = Offset(200f, 300f),
                        radius = 800f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0x2500F2FE),
                            Color(0x188A2BE2),
                            Color.Transparent
                        ),
                        center = Offset(850f, 1400f),
                        radius = 700f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar with Hollow Pakistan Wordmark & X button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(HollowNeonPurple, HollowNeonBlue)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🇵🇰", fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "HOLLOW PAKISTAN",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }

                // Top-right X to skip
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E1E2E).copy(alpha = 0.8f))
                        .testTag("mood_skip_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Skip mood check-in",
                        tint = Color(0xFFA0A0B2),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Title: 'How are you feeling today?'
            Text(
                text = "How are you feeling today?",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                textAlign = TextAlign.Center,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Subtitle
            Text(
                text = "Select your current vibe to discover Pakistan's live voice rooms matching your mood",
                fontSize = 13.sp,
                color = Color(0xFFB0B0C4),
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 6 Glassmorphic Cards Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(4.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(moodItems, key = { it.id }) { item ->
                    val isSelected = selectedMoodId == item.id
                    GlassmorphicMoodCard(
                        mood = item,
                        isSelected = isSelected,
                        onClick = { selectedMoodId = item.id }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Button: 'Find My Vibe Tribe' gradient purple to blue
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFF8A2BE2),
                                Color(0xFF6B21A8),
                                Color(0xFF0284C7),
                                Color(0xFF00F2FE)
                            )
                        )
                    )
                    .border(
                        width = 1.5.dp,
                        brush = Brush.verticalGradient(
                            listOf(Color(0x99FFFFFF), Color(0x22FFFFFF))
                        ),
                        shape = RoundedCornerShape(26.dp)
                    )
                    .clickable {
                        val chosen = moodItems.find { it.id == selectedMoodId }?.tag ?: "Chill"
                        onMoodSelected(chosen)
                    }
                    .testTag("find_vibe_tribe_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Find My Vibe Tribe",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.3.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("✨", fontSize = 16.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Skip for now link
            Text(
                text = "Skip for now",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF8E8EA8),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onDismiss() }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .testTag("skip_for_now_link")
            )

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun GlassmorphicMoodCard(
    mood: MoodItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) mood.glowColor else Color(0xFF262638),
        animationSpec = tween(250),
        label = "card_border"
    )

    val borderWidth by animateDpAsState(
        targetValue = if (isSelected) 2.dp else 1.dp,
        animationSpec = tween(250),
        label = "border_width"
    )

    val cardBg = if (isSelected) {
        Color(0xFF1B1B2C).copy(alpha = 0.95f)
    } else {
        Color(0xFF141420).copy(alpha = 0.75f)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(cardBg)
            .border(
                width = borderWidth,
                brush = if (isSelected) {
                    Brush.sweepGradient(
                        listOf(
                            mood.glowColor,
                            HollowNeonPurple,
                            mood.glowColor,
                            HollowNeonBlue,
                            mood.glowColor
                        )
                    )
                } else {
                    Brush.verticalGradient(
                        listOf(Color(0xFF2E2E44), Color(0xFF1B1B2C))
                    )
                },
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onClick() }
            .testTag("mood_card_${mood.id}")
            .padding(14.dp)
    ) {
        // Subtle glow background if selected
        if (isSelected) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                mood.glowColor.copy(alpha = 0.22f),
                                Color.Transparent
                            ),
                            radius = 200f
                        )
                    )
            )
        }

        Column(
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Emoji with glowing circular backing
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) mood.glowColor.copy(alpha = 0.25f)
                            else Color(0xFF1E1E2F)
                        )
                        .border(
                            1.dp,
                            if (isSelected) mood.glowColor.copy(alpha = 0.6f) else Color(0xFF2E2E44),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = mood.emoji, fontSize = 22.sp)
                }

                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = mood.glowColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = mood.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFFE2E8F0)
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = mood.description,
                fontSize = 11.5.sp,
                color = if (isSelected) mood.glowColor.copy(alpha = 0.9f) else Color(0xFF8E8EA8),
                lineHeight = 14.sp
            )
        }
    }
}
