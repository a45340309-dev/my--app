package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatRoom
import com.example.ui.components.CreateRoomDialog
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonPink
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.OnlineGreen
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.volume.DeviceVolumeBanner
import com.example.ui.volume.GoogleSignInActionButton
import com.example.ui.volume.rememberDeviceVolume

data class FemaleRoomModel(
    val id: String,
    val title: String,
    val host: String,
    val topic: String,
    val listeners: Int,
    val speakers: Int,
    val isPrivate: Boolean = false,
    val category: String,
    val tags: List<String>
)

val defaultFemaleRooms = listOf(
    FemaleRoomModel(
        id = "room_female_vehari",
        title = "Vehari Sisters Chit-Chat 🌸",
        host = "Ayesha",
        topic = "Daily chit-chat, chai discussion and friendly sisterhood",
        listeners = 68,
        speakers = 4,
        category = "Chit-Chat",
        tags = listOf("Vehari", "Safe Space", "Sisterhood")
    ),
    FemaleRoomModel(
        id = "room_female_study",
        title = "Late Night Study & Chill 📚",
        host = "Zainab",
        topic = "Exams preparation, quiet focus lounge and soft lofi beats",
        listeners = 39,
        speakers = 3,
        category = "Study & Focus",
        tags = listOf("Study", "Focus", "Lofi")
    ),
    FemaleRoomModel(
        id = "room_female_poetry",
        title = "Vehari Ladies Poetry & Chai ☕",
        host = "Fatima",
        topic = "Poetry recitation, classic literature and aesthetic talk",
        listeners = 47,
        speakers = 5,
        category = "Poetry & Art",
        tags = listOf("Poetry", "Literature", "Chai")
    ),
    FemaleRoomModel(
        id = "room_female_career",
        title = "Women in Tech & Careers 💻",
        host = "Mariam",
        topic = "Freelancing, remote software engineering and career growth",
        listeners = 55,
        speakers = 2,
        category = "Career & Tech",
        tags = listOf("Career", "Tech", "Freelancing")
    ),
    FemaleRoomModel(
        id = "room_female_diary",
        title = "Secret Sisterhood Diary 🔒",
        host = "Sana",
        topic = "Private trusted circle for girls, emotional support and advice",
        listeners = 31,
        speakers = 4,
        isPrivate = true,
        category = "Chit-Chat",
        tags = listOf("Private", "Support", "Advice")
    ),
    FemaleRoomModel(
        id = "room_female_cooking",
        title = "Cooking, Life & Health Tips 🍰",
        host = "Hira",
        topic = "Healthy recipes, baking ideas, skincare and life hacks",
        listeners = 44,
        speakers = 3,
        category = "Chit-Chat",
        tags = listOf("Baking", "Recipes", "Health")
    )
)

@Composable
fun FemaleOnlyRoomsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    onOpenRoom: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val showCreateRoomDialog by viewModel.showCreateRoomDialog.collectAsStateWithLifecycle()
    var selectedCategory by remember { mutableStateOf("All Rooms") }

    val volumeState = rememberDeviceVolume()

    val categories = listOf("All Rooms", "Chit-Chat", "Study & Focus", "Poetry & Art", "Career & Tech")

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_female")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = Color(0xFF0A0A0A),
        bottomBar = {
            GlassmorphicHollowBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    if (tab == 0) {
                        onBack()
                    } else {
                        viewModel.setSelectedTab(tab)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.setCreateRoomDialogVisible(true) },
                containerColor = HollowNeonPink,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .testTag("fab_create_female_room")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create Room", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Start Room",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF0A0A0A)),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Top Bar with Back Button
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1C1C1E))
                            .testTag("female_screen_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Vehari Home",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "City Girls App",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("♀️", fontSize = 16.sp)
                        }
                        Text(
                            text = "Vehari • Ladies Safe Space & Female Only Rooms",
                            fontSize = 11.5.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    // Live badge
                    Surface(
                        color = HollowNeonPink.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, HollowNeonPink.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(HollowNeonPink)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "284 Live",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = HollowNeonPink
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Google Sign Up action button matching Flutter AppBar action
                    GoogleSignInActionButton()
                }
            }

            // Mobile Volume Controller Banner matching user Flutter code
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    DeviceVolumeBanner(
                        volumeState = volumeState,
                        title = "Mobile Volume"
                    )
                }
            }

            // Safety Guarantee Card
            item {
                Box(modifier = Modifier.scale(volumeState.viewScale)) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF1E101D),
                    border = BorderStroke(1.dp, HollowNeonPink.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(HollowNeonPink.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = HollowNeonPink,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "100% Verified Safe Space",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = HollowNeonPink,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Strict zero-harassment tolerance. Automated voice moderation and dedicated female ambassadors.",
                                fontSize = 11.5.sp,
                                color = Color.White.copy(alpha = 0.65f),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
                }
            }

            // Category Filter Chips
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { category ->
                        val isSelected = selectedCategory == category
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { selectedCategory = category }
                                .testTag("female_cat_$category"),
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) HollowNeonPink else Color(0xFF1C1C1E),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) HollowNeonPink else Color(0xFF2C2C2E)
                            )
                        ) {
                            Text(
                                text = category,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }

            // Section Title
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active Voice Rooms",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Vehari District",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
            }

            // Room Cards
            val filteredRooms = if (selectedCategory == "All Rooms") {
                defaultFemaleRooms
            } else {
                defaultFemaleRooms.filter { it.category == selectedCategory }
            }

            items(filteredRooms) { room ->
                FemaleRoomCardItem(
                    room = room,
                    onClick = { onOpenRoom(room.id) }
                )
            }
        }
    }

    if (showCreateRoomDialog) {
        CreateRoomDialog(
            onDismiss = { viewModel.setCreateRoomDialogVisible(false) },
            onCreate = { title, topic, category ->
                viewModel.createRoom(title, topic, "Female Only")
            }
        )
    }
}

@Composable
fun FemaleRoomCardItem(
    room: FemaleRoomModel,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag("female_room_card_${room.id}"),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF161219),
        border = BorderStroke(1.dp, Color(0xFF331D2E))
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Host Avatar with Pink Glowing Ring
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(HollowNeonPink, HollowNeonPurple)
                            )
                        )
                        .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = room.host.take(1),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = room.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        if (room.isPrivate) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = "Private Room",
                                tint = HollowGold,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Host: ${room.host} • ${room.topic}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        maxLines = 1
                    )
                }

                // Join button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(HollowNeonPink)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Join",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer with listeners, speakers, and tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.People,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${room.listeners} listening",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Headphones,
                            contentDescription = null,
                            tint = OnlineGreen,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${room.speakers} on mic",
                            fontSize = 11.sp,
                            color = OnlineGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Tags
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    room.tags.take(2).forEach { tag ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF241B26)
                        ) {
                            Text(
                                text = "#$tag",
                                fontSize = 10.sp,
                                color = HollowNeonPink.copy(alpha = 0.85f),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
