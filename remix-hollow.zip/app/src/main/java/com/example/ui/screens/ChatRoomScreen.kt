package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatRoom
import com.example.data.model.Message
import com.example.data.model.User
import com.example.ui.components.ChatInputBar
import com.example.ui.components.MediaViewerDialog
import com.example.ui.components.MessageBubble
import com.example.ui.components.RoomInfoSheet
import com.example.ui.components.UserAvatar
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.HollowCyan
import com.example.ui.theme.HollowMagenta
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatRoomScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.closeRoom()
    }

    val activeRoom by viewModel.activeRoom.collectAsStateWithLifecycle()
    val messages by viewModel.activeRoomMessages.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val isTypingSimulated by viewModel.isTypingSimulated.collectAsStateWithLifecycle()
    val typingUserName by viewModel.typingUserName.collectAsStateWithLifecycle()
    val replyingTo by viewModel.replyingTo.collectAsStateWithLifecycle()
    val fullscreenImageUri by viewModel.fullscreenImageUri.collectAsStateWithLifecycle()
    val showRoomInfoSheet by viewModel.showRoomInfoSheet.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val sendErrorMessage by viewModel.sendErrorMessage.collectAsStateWithLifecycle()
    val language by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val userToReport by viewModel.userToReport.collectAsStateWithLifecycle()

    var isVoiceLoungeActive by remember { mutableStateOf(false) }
    var showDeleteRoomDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    // Scroll to bottom on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val currentRoom = activeRoom ?: return

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { viewModel.setRoomInfoSheetVisible(true) }
                            .padding(vertical = 4.dp)
                    ) {
                        if (currentRoom.isDirectMessage) {
                            UserAvatar(
                                name = currentRoom.title,
                                colorHex = "#8A2BE2",
                                size = 36.dp,
                                showOnlineBadge = true,
                                isOnline = true
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Column {
                            Text(
                                text = if (currentRoom.isDirectMessage) currentRoom.title else "#${currentRoom.title}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(OnlineGreen)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (currentRoom.isDirectMessage) "Online" else "${currentRoom.memberCount} members connected",
                                    fontSize = 11.sp,
                                    color = TextSecondaryDark
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeRoom() },
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to rooms",
                            tint = TextPrimaryDark
                        )
                    }
                },
                actions = {
                    // Voice Lounge Toggle button
                    IconButton(
                        onClick = { isVoiceLoungeActive = !isVoiceLoungeActive },
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .testTag("voice_lounge_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Live Voice Lounge",
                            tint = if (isVoiceLoungeActive) HollowCyan else TextSecondaryDark
                        )
                    }

                    // Room Info
                    IconButton(
                        onClick = { viewModel.setRoomInfoSheetVisible(true) },
                        modifier = Modifier.testTag("room_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Room Info",
                            tint = TextSecondaryDark
                        )
                    }

                    // Admin Delete Room Button
                    if (isAdmin && !currentRoom.isDirectMessage) {
                        IconButton(
                            onClick = { showDeleteRoomDialog = true },
                            modifier = Modifier.testTag("admin_delete_room_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Room (Admin)",
                                tint = com.example.ui.theme.BusyRed
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark
                )
            )
        },
        bottomBar = {
            if (currentUser?.isBlocked == true) {
                Surface(
                    color = com.example.ui.theme.CardBackgroundDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.BusyRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = null,
                            tint = com.example.ui.theme.BusyRed
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "You are blocked by an administrator and cannot send messages.",
                            color = com.example.ui.theme.BusyRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                ChatInputBar(
                    replyingTo = replyingTo,
                    onClearReply = { viewModel.setReplyingTo(null) },
                    onSendMessage = { text, mediaUri, mediaType, voiceSec ->
                        viewModel.sendMessage(
                            text = text,
                            mediaUri = mediaUri,
                            mediaType = mediaType,
                            voiceDurationSec = voiceSec
                        )
                    }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Live Voice Lounge Ticker if active
            AnimatedVisibility(visible = isVoiceLoungeActive) {
                Surface(
                    color = SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(OnlineGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Live Voice Lounge Active",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnlineGreen
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy((-6).dp)
                        ) {
                            allUsers.take(3).forEach { user ->
                                UserAvatar(
                                    name = user.displayName,
                                    colorHex = user.avatarColorHex,
                                    size = 24.dp
                                )
                            }
                        }
                    }
                }
            }

            // Error Banner if sending fails or blocked
            AnimatedVisibility(visible = sendErrorMessage != null) {
                Surface(
                    color = com.example.ui.theme.BusyRed.copy(alpha = 0.9f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = sendErrorMessage ?: "",
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearSendError() },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color.White)
                        }
                    }
                }
            }

            // Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMe = msg.senderId == (currentUser?.userId ?: "user_me")
                    MessageBubble(
                        message = msg,
                        isCurrentUser = isMe,
                        isAdmin = isAdmin,
                        onMediaClick = { uri -> viewModel.openFullscreenImage(uri) },
                        onReactionClick = { msgId, emoji -> viewModel.toggleReaction(msgId, emoji) },
                        onReplyClick = { replyTarget -> viewModel.setReplyingTo(replyTarget) },
                        onDeleteMessage = { messageToDelete ->
                            viewModel.deleteMessageByAdmin(currentRoom.id, messageToDelete.id)
                        },
                        onReportSender = { reportedMsg ->
                            val targetUser = allUsers.find { it.userId == reportedMsg.senderId }
                                ?: User(
                                    userId = reportedMsg.senderId,
                                    displayName = reportedMsg.senderName,
                                    handle = "@" + reportedMsg.senderName.lowercase().replace(" ", ""),
                                    avatarColorHex = reportedMsg.senderAvatarColor
                                )
                            viewModel.openReportDialog(targetUser)
                        }
                    )
                }
            }

            // Real-time typing indicator
            AnimatedVisibility(
                visible = isTypingSimulated,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(HollowCyan)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${typingUserName ?: "Someone"} is typing...",
                        fontSize = 12.sp,
                        color = HollowCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    if (showRoomInfoSheet) {
        RoomInfoSheet(
            room = currentRoom,
            users = allUsers,
            onDismiss = { viewModel.setRoomInfoSheetVisible(false) },
            onUserClick = { user ->
                viewModel.setRoomInfoSheetVisible(false)
                viewModel.startDirectChat(user)
            }
        )
    }

    if (fullscreenImageUri != null) {
        MediaViewerDialog(
            mediaUri = fullscreenImageUri,
            onDismiss = { viewModel.openFullscreenImage(null) }
        )
    }

    if (showDeleteRoomDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteRoomDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text("Delete Room #${currentRoom.title}?", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "As an administrator, deleting this room will permanently remove the room and all its messages for all users.",
                    color = TextSecondaryDark,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteRoomDialog = false
                        viewModel.deleteRoomByAdmin(currentRoom.id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = com.example.ui.theme.BusyRed,
                        contentColor = Color.White
                    )
                ) {
                    Text("Delete Room")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteRoomDialog = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            }
        )
    }

    userToReport?.let { targetUser ->
        com.example.ui.components.SafetyReportDialog(
            user = targetUser,
            language = language,
            onDismiss = { viewModel.closeReportDialog() },
            onSubmitReport = { reason, details, alsoBlock ->
                viewModel.submitSafetyReport(targetUser, reason, details)
                if (alsoBlock) {
                    viewModel.toggleUserBlock(targetUser.userId, false)
                }
            }
        )
    }
}
