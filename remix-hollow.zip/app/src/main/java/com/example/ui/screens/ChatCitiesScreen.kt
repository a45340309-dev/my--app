package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.HollowGold
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.volume.GoogleSignInActionButton

data class ChatCityItem(
    val name: String,
    val desc: String,
    val isTop: Boolean = false
)

// Complete 24+ Pakistani cities list - permanent and always available
val allChatCities = listOf(
    ChatCityItem("Vehari", "King of Cotton • 15.4k members", isTop = true),
    ChatCityItem("Lahore", "Garden City • 12.1k members"),
    ChatCityItem("Karachi", "Port City • 9.8k members"),
    ChatCityItem("Islamabad", "Capital • 7.4k members"),
    ChatCityItem("Multan", "City of Saints • 8.2k members"),
    ChatCityItem("Faisalabad", "Manchester • 6.9k members"),
    ChatCityItem("Rawalpindi", "Pindi Boyz • 6.5k members"),
    ChatCityItem("Gujranwala", "Pehilwan City • 5.8k members"),
    ChatCityItem("Peshawar", "City of Flowers • 5.5k members"),
    ChatCityItem("Quetta", "Fruit Garden • 4.9k members"),
    ChatCityItem("Sialkot", "City of Sports • 4.7k members"),
    ChatCityItem("Bahawalpur", "City of Nawabs • 4.3k members"),
    ChatCityItem("Sargodha", "City of Eagles • 4.1k members"),
    ChatCityItem("Sahiwal", "Sahiwal • 3.9k members"),
    ChatCityItem("Burewala", "Burewala • 3.5k members"),
    ChatCityItem("Okara", "City of Dairy • 3.2k members"),
    ChatCityItem("Gujrat", "Pottery City • 3.0k members"),
    ChatCityItem("Jhang", "Heer Ranjha Land • 2.8k members"),
    ChatCityItem("Sheikhupura", "Historical Fort City • 2.6k members"),
    ChatCityItem("Rahim Yar Khan", "Gateway to Punjab • 2.4k members"),
    ChatCityItem("Kasur", "City of Bulleh Shah • 2.2k members"),
    ChatCityItem("Dera Ghazi Khan", "Suleman Hills • 2.0k members"),
    ChatCityItem("Bahawalnagar", "Border City • 1.9k members"),
    ChatCityItem("Mardan", "Takht-i-Bahi • 1.8k members"),
    ChatCityItem("Mingora", "Swat Valley Hub • 1.7k members"),
    ChatCityItem("Sukkur", "Lloyd Barrage • 1.6k members"),
    ChatCityItem("Larkana", "Mohenjo Daro • 1.5k members"),
    ChatCityItem("Hyderabad", "City of Winds • 4.2k members")
)

@Composable
fun ChatCitiesScreen(
    viewModel: ChatViewModel,
    onCitySelected: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    if (onBack != null) {
        BackHandler {
            onBack()
        }
    }

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }

    val filteredCities = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            allChatCities
        } else {
            allChatCities.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                    it.desc.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = Color(0xFF030A1A),
        bottomBar = {
            GlassmorphicHollowBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    viewModel.setSelectedTab(tab)
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF030A1A))
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0E1A33))
                            .testTag("chat_cities_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Chat Cities",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🇵🇰", fontSize = 16.sp)
                    }
                    Text(
                        text = "Join live lounges across 24+ Pakistani cities",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.54f)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Google Sign Up action button matching Flutter AppBar action
                GoogleSignInActionButton()
            }

            // Search Bar: matching Flutter container Color(0xFF0E1A33), borderRadius: 30
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xFF0E1A33))
                    .border(1.dp, Color(0xFF1A2A4A), RoundedCornerShape(30.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color.White.copy(alpha = 0.54f),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_cities_search_input"),
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 14.sp
                        ),
                        cursorBrush = SolidColor(Color(0xFF40C4FF)),
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "Search cities, regions...",
                                    style = TextStyle(
                                        color = Color.White.copy(alpha = 0.54f),
                                        fontSize = 14.sp
                                    )
                                )
                            }
                            innerTextField()
                        }
                    )
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear search",
                                tint = Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Scrollable List of Cities: ListView.builder
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("chat_cities_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(filteredCities, key = { it.name }) { city ->
                    CityTileItem(
                        city = city,
                        onJoinClick = { onCitySelected(city.name) }
                    )
                }
            }
        }
    }
}

@Composable
fun CityTileItem(
    city: ChatCityItem,
    onJoinClick: () -> Unit
) {
    val isVehari = city.isTop || city.name.equals("Vehari", ignoreCase = true)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { onJoinClick() }
            .testTag("city_tile_${city.name.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF0E1A33),
        border = BorderStroke(
            1.dp,
            if (isVehari) HollowGold.copy(alpha = 0.7f) else Color(0xFF448AFF).copy(alpha = 0.15f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circle Avatar: Color(0xFF1A2A4A), Location City icon
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        if (isVehari) Color(0xFF2E2210) else Color(0xFF1A2A4A)
                    )
                    .border(
                        1.dp,
                        if (isVehari) HollowGold else Color(0xFF40C4FF).copy(alpha = 0.3f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isVehari) {
                    Text("👑", fontSize = 18.sp)
                } else {
                    Icon(
                        imageVector = Icons.Default.LocationCity,
                        contentDescription = null,
                        tint = Color(0xFF40C4FF),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // City Name & Description
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = city.name,
                        style = TextStyle(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    )
                    if (isVehari) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = HollowGold.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, HollowGold)
                        ) {
                            Text(
                                text = "RECOMMENDED",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = HollowGold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = city.desc,
                    style = TextStyle(
                        color = Color.White.copy(alpha = 0.54f),
                        fontSize = 11.sp
                    )
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Join Button Container: borderRadius 20, border blueAccent.withOpacity(0.5)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (isVehari) HollowGold.copy(alpha = 0.15f) else Color(0xFF030A1A)
                    )
                    .border(
                        1.dp,
                        if (isVehari) HollowGold else Color(0xFF448AFF).copy(alpha = 0.5f),
                        RoundedCornerShape(20.dp)
                    )
                    .clickable { onJoinClick() }
                    .padding(horizontal = 18.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Join",
                    style = TextStyle(
                        color = if (isVehari) HollowGold else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
    }
}
