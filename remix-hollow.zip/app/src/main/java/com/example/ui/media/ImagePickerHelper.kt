package com.example.ui.media

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPink
import com.google.firebase.Firebase
import com.google.firebase.storage.storage
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Modern Android Photo Picker (zero-permission Google Play compliant replacement for Flutter image_picker).
 * Returns a lambda that triggers the system photo picker.
 */
@Composable
fun rememberImagePicker(
    onImagePicked: (Uri) -> Unit
): () -> Unit {
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onImagePicked(uri)
        }
    }

    return remember {
        {
            launcher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        }
    }
}

/**
 * Uploads an image to Firebase Storage and returns the public download URL.
 */
suspend fun uploadImageToFirebaseStorage(
    uri: Uri,
    folder: String = "chat_uploads"
): String {
    val storageRef = Firebase.storage.reference
    val filename = "${UUID.randomUUID()}.jpg"
    val fileRef = storageRef.child("$folder/$filename")
    
    fileRef.putFile(uri).await()
    return fileRef.downloadUrl.await().toString()
}

/**
 * Interactive Image Picker Button with optional Firebase Storage auto-upload.
 */
@Composable
fun ImagePickerButton(
    onUrlReady: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "Photo"
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isUploading by remember { mutableStateOf(false) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }

    val pickImage = rememberImagePicker { uri ->
        selectedUri = uri
        isUploading = true
        scope.launch {
            try {
                val url = uploadImageToFirebaseStorage(uri)
                isUploading = false
                Toast.makeText(context, "Image uploaded to Firebase Storage! 📸", Toast.LENGTH_SHORT).show()
                onUrlReady(url)
            } catch (e: Exception) {
                isUploading = false
                // Even if Firebase Storage is offline or unprovisioned, return local URI string
                onUrlReady(uri.toString())
            }
        }
    }

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = !isUploading) { pickImage() }
            .testTag("image_picker_button"),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF132B52),
        border = BorderStroke(1.dp, Color(0xFF4A6CF7).copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isUploading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = Color(0xFF2EC5CE)
                )
            } else if (selectedUri != null) {
                AsyncImage(
                    model = selectedUri,
                    contentDescription = "Selected Photo",
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = "Pick Image",
                    tint = Color(0xFF40C4FF),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = if (isUploading) "Uploading..." else label,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
