package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonBlue
import com.example.ui.theme.HollowNeonPink
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.TikTokRed
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun BadshahShowdownScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val officialHostCode by viewModel.officialHostCode.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    var enteredCode by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val livePulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "live_pulse"
    )

    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding(),
        containerColor = Color.Black,
        bottomBar = {
            GlassmorphicHollowBottomNav(
                selectedTab = 3,
                onTabSelected = { tab ->
                    viewModel.setSelectedTab(tab)
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.Black)
        ) {
            // Ambient glow: Amber / Gold & Red glow
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0x40FFD700),
                                Color(0x25FF2E50),
                                Color.Transparent
                            ),
                            center = Offset(540f, 180f),
                            radius = 750f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Header Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1E1608),
                    border = BorderStroke(1.dp, HollowGold.copy(alpha = 0.8f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "👑", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HOLLOW GRAND ARENA",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black,
                            color = HollowGold,
                            letterSpacing = 1.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title: Daily Badshah Showdown - 9 PM
                Text(
                    text = "Daily Badshah Showdown - 9 PM",
                    style = TextStyle(
                        color = Color(0xFFFFD700),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        shadow = Shadow(
                            color = Color(0xFFFFD700).copy(alpha = 0.7f),
                            blurRadius = 25f
                        )
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Live Match Subtitles
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .scale(livePulse)
                            .clip(CircleShape)
                            .background(TikTokRed)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SEMI FINAL 1: Top 1 vs Top 3 - LIVE",
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = "SEMI FINAL 2: Top 2 vs Top 4 - Starting Soon",
                    style = TextStyle(
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                // VS Arena Display Card
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFF12121A),
                    border = BorderStroke(
                        1.5.dp,
                        Brush.horizontalGradient(
                            listOf(Color(0xFFFFD700), Color(0xFFFF2E50), Color(0xFF9333EA))
                        )
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp, horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Top 1 Contender
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.sweepGradient(
                                            listOf(HollowGold, Color(0xFFFFA500), HollowGold)
                                        )
                                    )
                                    .padding(3.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF281C08)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "T1",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFFFD700)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Top 1",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "1.8M Points",
                                fontSize = 11.sp,
                                color = HollowGold
                            )
                        }

                        // VS Animated
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "VS",
                                style = TextStyle(
                                    color = TikTokRed,
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.Black,
                                    shadow = Shadow(
                                        color = TikTokRed,
                                        blurRadius = 30f
                                    )
                                )
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = TikTokRed.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, TikTokRed)
                            ) {
                                Text(
                                    text = "PK BATTLE",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TikTokRed,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Top 2 Contender
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.sweepGradient(
                                            listOf(Color(0xFFB026FF), Color(0xFF00F2FE), Color(0xFFB026FF))
                                        )
                                    )
                                    .padding(3.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF200E2E)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "T2",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFE9D5FF)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Top 2",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "1.6M Points",
                                fontSize = 11.sp,
                                color = Color(0xFF00F2FE)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(26.dp))

                // Private Code System Card
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF14141E),
                    border = BorderStroke(1.dp, Color(0xFF2E2E42)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = HollowGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Official Host Private Passcode",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Enter your official Host Passcode to enter as PK Battler, or join as audience spectator.",
                            fontSize = 11.5.sp,
                            color = Color(0xFFA0A0B2)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Text Field for Code
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF0D0D15),
                            border = BorderStroke(
                                1.dp,
                                if (codeError != null) TikTokRed else HollowGold.copy(alpha = 0.6f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BasicTextField(
                                    value = enteredCode,
                                    onValueChange = {
                                        enteredCode = it.uppercase()
                                        codeError = null
                                    },
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 2.sp
                                    ),
                                    cursorBrush = SolidColor(HollowGold),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("badshah_code_input"),
                                    decorationBox = { innerTextField ->
                                        if (enteredCode.isEmpty()) {
                                            Text(
                                                text = "e.g. $officialHostCode",
                                                color = Color.White.copy(alpha = 0.35f),
                                                fontSize = 14.sp
                                            )
                                        }
                                        innerTextField()
                                    }
                                )

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF261D0C)
                                ) {
                                    Text(
                                        text = "HOST ONLY",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = HollowGold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        if (codeError != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = codeError ?: "",
                                fontSize = 11.sp,
                                color = TikTokRed
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Buttons: Join as Host vs Join as Audience
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Join as Host Button
                            Button(
                                onClick = {
                                    if (enteredCode.trim().equals(officialHostCode.trim(), ignoreCase = true)) {
                                        Toast.makeText(context, "Welcome Host! Entering PK Arena Stage 🎙️", Toast.LENGTH_SHORT).show()
                                        viewModel.openRoom("room_badshah_pk_showdown")
                                    } else {
                                        codeError = "Invalid Code! Ask Admin or check panel (Current: $officialHostCode)"
                                    }
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFFD700)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("join_as_host_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = "🎙️", fontSize = 15.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Join as Host",
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.Black
                                    )
                                }
                            }

                            // Join as Audience Button
                            OutlinedButton(
                                onClick = {
                                    Toast.makeText(context, "Entering as Audience Spectator 🍿", Toast.LENGTH_SHORT).show()
                                    viewModel.openRoom("room_badshah_pk_showdown")
                                },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, Color(0xFFB026FF)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFF1E102E)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("join_as_audience_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Visibility,
                                        contentDescription = null,
                                        tint = Color(0xFF00F2FE),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Audience View",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Tournament Bracket Info Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF0D0D15),
                    border = BorderStroke(1.dp, Color(0xFF1F1F30)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🏆 Today's Grand Rewards",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = HollowGold
                            )
                            Text(
                                text = "500,000 Coins",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF00FF66)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• 1st Place: Badshah Crown Badge + 300K Coins\n• 2nd Place: Royal Diamond Badge + 150K Coins\n• 3rd & 4th: 25K Coins each",
                            fontSize = 11.sp,
                            color = Color(0xFFA0A0B2),
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
