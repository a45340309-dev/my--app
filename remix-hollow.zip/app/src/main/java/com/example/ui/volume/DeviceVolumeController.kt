package com.example.ui.volume

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.ui.auth.onGoogleSignInClicked
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPink
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.OnlineGreen
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

@Stable
class DeviceVolumeState(
    initialVolume: Float,
    private val audioManager: AudioManager
) {
    var volume by mutableFloatStateOf(initialVolume)
        internal set

    val volumePercent: Int
        get() = (volume * 100).toInt().coerceIn(0, 100)

    val viewScale: Float
        get() = (0.85f + (volume * 0.35f)).coerceIn(0.85f, 1.2f)

    val isMuted: Boolean
        get() = volume <= 0.02f

    fun setVolume(newVolume: Float) {
        val clamped = newVolume.coerceIn(0f, 1f)
        volume = clamped
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val targetIndex = (clamped * max).toInt().coerceIn(0, max)
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetIndex, 0)
        } catch (_: Exception) {}
    }
}

/**
 * Reactive mobile volume listener in Jetpack Compose matching Flutter VolumeController().listener.
 * Automatically updates when physical device volume buttons are pressed or changed.
 */
@Composable
fun rememberDeviceVolume(): DeviceVolumeState {
    val context = LocalContext.current
    val audioManager = remember(context) {
        context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    fun getCurrentNormalizedVolume(): Float {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        return (current.toFloat() / max.toFloat()).coerceIn(0f, 1f)
    }

    val state = remember(audioManager) {
        DeviceVolumeState(getCurrentNormalizedVolume(), audioManager)
    }

    DisposableEffect(context, audioManager) {
        // 1. Broadcast receiver for VOLUME_CHANGED_ACTION
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                state.volume = getCurrentNormalizedVolume()
            }
        }
        val filter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        try {
            context.registerReceiver(receiver, filter)
        } catch (_: Exception) {}

        // 2. ContentObserver on settings for instant reactive updates
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                super.onChange(selfChange)
                state.volume = getCurrentNormalizedVolume()
            }
        }
        try {
            context.contentResolver.registerContentObserver(
                Settings.System.CONTENT_URI,
                true,
                observer
            )
        } catch (_: Exception) {}

        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {}
            try {
                context.contentResolver.unregisterContentObserver(observer)
            } catch (_: Exception) {}
        }
    }

    return state
}

/**
 * Mobile Volume Display Banner matching user Flutter code:
 * "Mobile Volume: ${(volume * 100).toInt()}%"
 * With real-time reactive transform scale and quick slider control.
 */
@Composable
fun DeviceVolumeBanner(
    volumeState: DeviceVolumeState,
    modifier: Modifier = Modifier,
    title: String = "Mobile Volume",
    expandedByDefault: Boolean = false
) {
    var isExpanded by remember { mutableStateOf(expandedByDefault) }
    val animatedScale by animateFloatAsState(
        targetValue = volumeState.viewScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "view_scale_animation"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { isExpanded = !isExpanded }
            .animateContentSize()
            .testTag("device_volume_banner"),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF0E1A33),
        border = BorderStroke(1.dp, Color(0xFF1E335C))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Volume Icon with dynamic pulse
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .scale(if (volumeState.volume > 0.6f) 1.05f else 1f)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF4A6CF7), Color(0xFF2EC5CE))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        val icon = when {
                            volumeState.volume <= 0.02f -> Icons.Default.VolumeMute
                            volumeState.volume < 0.4f -> Icons.Default.VolumeDown
                            else -> Icons.Default.VolumeUp
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Volume",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        // "Mobile Volume: 75%" as requested in Flutter code
                        Text(
                            text = "$title: ${volumeState.volumePercent}%",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (volumeState.isMuted) "Muted • Tap to unmute" else "Reactive View Scale: ${String.format("%.2f", animatedScale)}x",
                            color = Color.White.copy(alpha = 0.55f),
                            fontSize = 10.5.sp
                        )
                    }
                }

                // Volume percentage pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (volumeState.isMuted) Color(0xFF3A1C20) else Color(0xFF132B52),
                    border = BorderStroke(1.dp, if (volumeState.isMuted) Color(0xFFFE2C55) else Color(0xFF4A6CF7))
                ) {
                    Text(
                        text = if (volumeState.isMuted) "MUTED" else "${volumeState.volumePercent}%",
                        color = if (volumeState.isMuted) Color(0xFFFE2C55) else Color(0xFF40C4FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    // Slider
                    Slider(
                        value = volumeState.volume,
                        onValueChange = { volumeState.setVolume(it) },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF2EC5CE),
                            activeTrackColor = Color(0xFF4A6CF7),
                            inactiveTrackColor = Color(0xFF1E335C)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .testTag("device_volume_slider")
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Preset buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(0f to "0%", 0.3f to "30%", 0.6f to "60%", 1.0f to "100%").forEach { (level, label) ->
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                color = if (kotlin.math.abs(volumeState.volume - level) < 0.15f) Color(0xFF2EC5CE) else Color.White.copy(alpha = 0.5f),
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { volumeState.setVolume(level) }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Google Sign In Top Bar Action Button matching Flutter code:
 * IconButton(
 *   onPressed: signInWithGoogle,
 *   icon: Icon(Icons.login, color: Colors.white),
 *   tooltip: "Google Sign Up",
 * )
 */
@Composable
fun GoogleSignInActionButton(
    onSuccess: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth = Firebase.auth
    val currentUser = auth.currentUser

    var showAccountDialog by remember { mutableStateOf(false) }
    var isSigningIn by remember { mutableStateOf(false) }

    val credentialManager = remember { CredentialManager.create(context) }

    IconButton(
        onClick = {
            if (currentUser != null) {
                showAccountDialog = true
            } else {
                isSigningIn = true
                onGoogleSignInClicked(
                    context = context,
                    credentialManager = credentialManager,
                    onAuthSuccess = {
                        isSigningIn = false
                        Toast.makeText(context, "Signed in successfully with Google! 🇵🇰", Toast.LENGTH_SHORT).show()
                        onSuccess()
                    },
                    onAuthError = { err ->
                        isSigningIn = false
                        Toast.makeText(context, "Google Sign-In: $err", Toast.LENGTH_LONG).show()
                    },
                    scope = scope,
                    onAuthCancelled = {
                        isSigningIn = false
                    }
                )
            }
        },
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (currentUser != null) Color(0xFF132B52) else Color(0xFF1C1C1E))
            .border(
                1.dp,
                if (currentUser != null) OnlineGreen.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.2f),
                CircleShape
            )
            .testTag("google_sign_in_action_button")
    ) {
        if (currentUser != null) {
            // Signed In Avatar
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = currentUser.displayName?.take(1)?.uppercase() ?: "G",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        } else {
            Icon(
                imageVector = Icons.Default.Login,
                contentDescription = "Google Sign Up",
                tint = Color.White,
                modifier = Modifier.size(19.dp)
            )
        }
    }

    if (showAccountDialog && currentUser != null) {
        AlertDialog(
            onDismissRequest = { showAccountDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = OnlineGreen,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Google Account",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = currentUser.displayName ?: "Authenticated User",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = currentUser.email ?: "",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = OnlineGreen.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, OnlineGreen.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "Verified Google Member 🇵🇰",
                            color = OnlineGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        auth.signOut()
                        showAccountDialog = false
                        Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color(0xFFFE2C55), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sign Out", color = Color(0xFFFE2C55))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAccountDialog = false }) {
                    Text("Close", color = Color.White)
                }
            },
            containerColor = Color(0xFF0E1A33)
        )
    }
}
