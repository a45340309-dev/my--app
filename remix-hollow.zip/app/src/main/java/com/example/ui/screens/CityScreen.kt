package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CreateRoomDialog
import com.example.ui.theme.HollowCardDark
import com.example.ui.theme.HollowDeepBlack
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.HollowNeonPurpleBright
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokRed
import com.example.ui.viewmodel.ChatViewModel

data class CityInfo(
    val id: String,
    val name: String,
    val sub: String,
    val isRecommended: Boolean = false,
    val liveCount: String = "124 Live"
)

val pakistanCities = listOf(
    CityInfo("vehari", "Vehari", "Punjab • 2.1M population", isRecommended = true, liveCount = "124 Live"),
    CityInfo("lahore", "Lahore", "Punjab • 14.1M population", liveCount = "124 Live"),
    CityInfo("karachi", "Karachi", "Sindh • 16.1M population", liveCount = "124 Live"),
    CityInfo("islamabad", "Islamabad", "Capital Territory • 1.2M population", liveCount = "124 Live"),
    CityInfo("multan", "Multan", "Punjab • 1.9M population", liveCount = "124 Live"),
    CityInfo("faisalabad", "Faisalabad", "Punjab • 3.6M population", liveCount = "124 Live"),
    CityInfo("rawalpindi", "Rawalpindi", "Punjab • 2.3M population", liveCount = "124 Live"),
    CityInfo("gujranwala", "Gujranwala", "Punjab • 2.1M population", liveCount = "124 Live"),
    CityInfo("peshawar", "Peshawar", "KPK • 2.0M population", liveCount = "124 Live"),
    CityInfo("quetta", "Quetta", "Balochistan • 1.2M population", liveCount = "124 Live"),
    CityInfo("sialkot", "Sialkot", "Punjab • 1.5M population", liveCount = "124 Live"),
    CityInfo("bahawalpur", "Bahawalpur", "Punjab • 0.9M population", liveCount = "124 Live"),
    CityInfo("sargodha", "Sargodha", "Punjab • 0.7M population", liveCount = "124 Live"),
    CityInfo("sahiwal", "Sahiwal", "Punjab • 0.4M population", liveCount = "124 Live"),
    CityInfo("okara", "Okara", "Punjab • 0.4M population", liveCount = "124 Live"),
    CityInfo("gujrat", "Gujrat", "Punjab • 0.4M population", liveCount = "124 Live"),
    CityInfo("jhang", "Jhang", "Punjab • 0.4M population", liveCount = "124 Live"),
    CityInfo("sheikhupura", "Sheikhupura", "Punjab • 0.5M population", liveCount = "124 Live"),
    CityInfo("rahim_yar_khan", "Rahim Yar Khan", "Punjab • 0.5M population", liveCount = "124 Live"),
    CityInfo("kasur", "Kasur", "Punjab • 0.4M population", liveCount = "124 Live"),
    CityInfo("dera_ghazi_khan", "Dera Ghazi Khan", "Punjab • 0.3M population", liveCount = "124 Live"),
    CityInfo("bahawalnagar", "Bahawalnagar", "Punjab • 0.2M population", liveCount = "124 Live"),
    CityInfo("mardan", "Mardan", "KPK • 0.4M population", liveCount = "124 Live"),
    CityInfo("mingora", "Mingora", "KPK • 0.3M population", liveCount = "124 Live"),
    CityInfo("sukkur", "Sukkur", "Sindh • 0.5M population", liveCount = "124 Live"),
    CityInfo("larkana", "Larkana", "Sindh • 0.5M population", liveCount = "124 Live"),
    CityInfo("hyderabad", "Hyderabad", "Sindh • 1.7M population", liveCount = "124 Live")
)

@Composable
fun CityScreen(
    viewModel: ChatViewModel,
    onCitySelected: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    ChatCitiesScreen(
        viewModel = viewModel,
        onCitySelected = onCitySelected,
        onBack = onBack,
        modifier = modifier
    )
}

@Composable
fun CityScreenAppBar(
    isAdmin: Boolean,
    onAdminClick: () -> Unit,
    onCreateRoomClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title: HOLLOW with purple & blue neon glow
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(HollowNeonPurple, HollowNeonBlueSky)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("🇵🇰", fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "HOLLOW",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.5.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(OnlineGreen)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "1,240 Online in Pakistan",
                        fontSize = 10.sp,
                        color = HollowNeonBlueSky,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Create Room Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(HollowNeonPurple, HollowNeonBlueSky)
                        )
                    )
                    .border(1.dp, Color(0x99FFFFFF), RoundedCornerShape(18.dp))
                    .clickable { onCreateRoomClick() }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
                    .testTag("city_create_room_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Create Room",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Create Room",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                }
            }

            // Admin badge if admin
            if (isAdmin) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = TikTokRed.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, TikTokRed),
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onAdminClick() }
                        .testTag("city_admin_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Admin",
                            tint = TikTokRed,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Admin",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = TikTokRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CityTileCard(
    city: CityInfo,
    onClick: () -> Unit
) {
    val isVehari = city.isRecommended || city.name.equals("Vehari", ignoreCase = true)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("city_tile_${city.id}"),
        shape = RoundedCornerShape(12.dp),
        color = if (isVehari) Color(0xFF1E1035) else Color(0xFF15111F),
        border = BorderStroke(
            width = if (isVehari) 2.dp else 1.dp,
            color = if (isVehari) Color(0xFFA855F7) else Color.White.copy(alpha = 0.1f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Leading Icon Container
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFA855F7).copy(alpha = 0.15f))
                        .border(
                            1.dp,
                            Color(0xFFA855F7).copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isVehari) {
                        // Golden crown icon
                        Text("👑", fontSize = 20.sp)
                    } else {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = city.name,
                            tint = Color(0xFFA855F7),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = city.name.uppercase(),
                            fontSize = 15.sp,
                            fontWeight = if (isVehari) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (isVehari) HollowGold else Color.White
                        )
                        if (isVehari) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xFFA855F7)
                            ) {
                                Text(
                                    text = "RECOMMENDED",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = city.sub,
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        maxLines = 1
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Live count badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isVehari) Color(0xFF2E154D) else Color(0xFF14241B),
                    border = BorderStroke(
                        1.dp,
                        if (isVehari) Color(0xFFA855F7).copy(alpha = 0.8f) else OnlineGreen.copy(alpha = 0.6f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isVehari) HollowGold else OnlineGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = city.liveCount,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isVehari) HollowGold else OnlineGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = "Open",
                    tint = Color.White.copy(alpha = 0.25f),
                    modifier = Modifier.size(13.dp)
                )
            }
        }
    }
}
