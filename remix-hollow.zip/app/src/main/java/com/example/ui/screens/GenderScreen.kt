package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.HollowCardDark
import com.example.ui.theme.HollowDeepBlack
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPink
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun GenderScreen(
    cityName: String,
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    onGenderSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        containerColor = HollowDeepBlack,
        bottomBar = {
            GlassmorphicHollowBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    viewModel.setSelectedTab(tab)
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HollowDeepBlack)
        ) {
            // Ambient neon purple #8A2BE2 and blue #00BFFF glow gradients
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0x358A2BE2),
                                Color(0x2500BFFF),
                                Color.Transparent
                            ),
                            center = Offset(540f, 150f),
                            radius = 650f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                // Top Bar with Back Arrow and Title: cityName (e.g. Vehari)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF161624))
                            .testTag("gender_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Cities",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = cityName,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "Choose your room atmosphere 🎙️",
                            fontSize = 12.sp,
                            color = Color(0xFFA0A0B2)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // 3 Vertical Cards: MALE, COMBINE (highlighted in center), FEMALE
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. MALE Card (Blue glow #00BFFF)
                    GenderOptionCard(
                        title = "MALE",
                        subtitle = "Boys Only",
                        description = "Boys hangout, late night gaming & sports banter",
                        liveCount = "58 Live",
                        glowColor = HollowNeonBlueSky,
                        emoji = "♂️",
                        isHighlighted = false,
                        onClick = { onGenderSelected("Male") },
                        testTag = "gender_card_male"
                    )

                    // 2. COMBINE Card (Golden glow #FFD700, highlighted in center)
                    GenderOptionCard(
                        title = "COMBINE",
                        subtitle = "Mixed Lounge",
                        description = "Open community lounge • Music, poetry & social chats",
                        liveCount = "124 Live • Most Active",
                        glowColor = HollowGold,
                        emoji = "👑",
                        isHighlighted = true,
                        onClick = { onGenderSelected("Combine") },
                        testTag = "gender_card_combine"
                    )

                    // 3. FEMALE Card (Pink glow #FF1493)
                    GenderOptionCard(
                        title = "FEMALE",
                        subtitle = "Ladies Safe Space",
                        description = "Verified ladies safe space, study & sisterhood circle",
                        liveCount = "42 Live",
                        glowColor = HollowNeonPink,
                        emoji = "♀️",
                        isHighlighted = false,
                        onClick = { onGenderSelected("Female") },
                        testTag = "gender_card_female"
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Safe space reassurance notice
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141A16),
                    border = BorderStroke(1.dp, Color(0xFF1F3A2A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🛡️", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Hollow Pakistan ensures a respectful, verified environment with zero harassment tolerance.",
                            fontSize = 11.5.sp,
                            color = Color(0xFFA0C0B0),
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GenderOptionCard(
    title: String,
    subtitle: String,
    description: String,
    liveCount: String,
    glowColor: Color,
    emoji: String,
    isHighlighted: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(20.dp),
        color = if (isHighlighted) Color(0xFF1E1A14) else HollowCardDark,
        border = BorderStroke(
            width = if (isHighlighted) 2.dp else 1.2.dp,
            brush = if (isHighlighted) {
                Brush.sweepGradient(
                    listOf(
                        HollowGold,
                        Color(0xFFFFA500),
                        HollowGold,
                        Color(0xFFFFE066),
                        HollowGold
                    )
                )
            } else {
                Brush.horizontalGradient(
                    listOf(glowColor.copy(alpha = 0.8f), glowColor.copy(alpha = 0.3f))
                )
            }
        )
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Ambient glow inside card if highlighted
            if (isHighlighted) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    glowColor.copy(alpha = 0.15f),
                                    Color.Transparent
                                ),
                                radius = 400f
                            )
                        )
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = if (isHighlighted) 20.dp else 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Emoji / Icon
                    Box(
                        modifier = Modifier
                            .size(if (isHighlighted) 52.dp else 46.dp)
                            .clip(CircleShape)
                            .background(glowColor.copy(alpha = 0.2f))
                            .border(1.2.dp, glowColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = if (isHighlighted) 24.sp else 20.sp)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = title,
                                fontSize = if (isHighlighted) 19.sp else 17.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isHighlighted) HollowGold else Color.White,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "• $subtitle",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = glowColor.copy(alpha = 0.9f)
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = description,
                            fontSize = 11.5.sp,
                            color = Color(0xFFA0A0B2),
                            lineHeight = 15.sp,
                            maxLines = 2
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Live count pill
                Column(horizontalAlignment = Alignment.End) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = glowColor.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, glowColor.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = liveCount,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = glowColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Go",
                        tint = glowColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
