package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CreateRoomDialog
import com.example.ui.theme.HollowGold
import com.example.ui.theme.HollowNeonBlueSky
import com.example.ui.theme.HollowNeonPink
import com.example.ui.theme.HollowNeonPurple
import com.example.ui.theme.OnlineGreen
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.volume.DeviceVolumeBanner
import com.example.ui.volume.GoogleSignInActionButton
import com.example.ui.volume.rememberDeviceVolume

data class VehariLiveRoom(
    val id: String,
    val title: String,
    val host: String,
    val topic: String,
    val listeners: Int,
    val speakers: Int,
    val category: String,
    val isFemaleOnly: Boolean = false,
    val isHot: Boolean = false
)

val vehariSampleRooms = listOf(
    VehariLiveRoom(
        id = "room_vehari_late_night",
        title = "Vehari Late Night Vibes 🌙",
        host = "Ahmed",
        topic = "Vehari youth lounge • Chai talks, music and campus gossips",
        listeners = 142,
        speakers = 6,
        category = "Chit-Chat",
        isHot = true
    ),
    VehariLiveRoom(
        id = "room_female_vehari",
        title = "Vehari Sisters Chit-Chat 🌸",
        host = "Ayesha",
        topic = "Verified Ladies Safe Space • Daily life, recipes and fun",
        listeners = 68,
        speakers = 4,
        category = "Female Only",
        isFemaleOnly = true,
        isHot = true
    ),
    VehariLiveRoom(
        id = "room_vehari_chai",
        title = "Chai Shai Vehari Club ☕",
        host = "Bilal",
        topic = "Burewala road discussions, cricket updates and banter",
        listeners = 95,
        speakers = 5,
        category = "Chit-Chat"
    ),
    VehariLiveRoom(
        id = "room_female_study",
        title = "Late Night Study & Chill 📚",
        host = "Zainab",
        topic = "Female Only • Exams preparation and quiet focus room",
        listeners = 39,
        speakers = 3,
        category = "Female Only",
        isFemaleOnly = true
    ),
    VehariLiveRoom(
        id = "room_vehari_gamers",
        title = "Vehari Gamers & Tech Hub 🎮",
        host = "Hamza",
        topic = "PUBG squads, FreeFire tournaments and gaming PC setups",
        listeners = 54,
        speakers = 3,
        category = "Gaming"
    ),
    VehariLiveRoom(
        id = "room_vehari_poetry",
        title = "Vehari Sufi & Poetry Night ✨",
        host = "Usman",
        topic = "Classical poetry recitation, ghazals and aesthetic night",
        listeners = 82,
        speakers = 4,
        category = "Poetry"
    )
)

@Composable
fun VehariHomeScreen(
    viewModel: ChatViewModel,
    onOpenFemaleOnlyRooms: () -> Unit,
    onOpenCityScreen: () -> Unit,
    onOpenRoom: (String) -> Unit,
    onOpenBadshahShowdown: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val showCreateRoomDialog by viewModel.showCreateRoomDialog.collectAsStateWithLifecycle()

    val volumeState = rememberDeviceVolume()

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_vehari")
    val pulseLive by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_live"
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = Color(0xFF0A0A0A),
        bottomBar = {
            GlassmorphicHollowBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    if (tab == 0) {
                        // Already on Rooms tab
                    } else {
                        viewModel.setSelectedTab(tab)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.setCreateRoomDialogVisible(true) },
                containerColor = HollowNeonPurple,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .testTag("fab_create_room_vehari")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create Room", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Create Room",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF0A0A0A)),
            contentPadding = PaddingValues(bottom = 85.dp)
        ) {
            // Top Bar matching user Flutter code: 9:41, HOLLOW, Search, Notifications
            item {
                PaddingTopBar(
                    isSearchActive = isSearchActive,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { searchQuery = it },
                    onToggleSearch = { isSearchActive = !isSearchActive },
                    onNotificationsClick = {
                        Toast.makeText(context, "No new notifications", Toast.LENGTH_SHORT).show()
                    },
                    isAdmin = isAdmin,
                    onAdminClick = { viewModel.openAdminPanel() }
                )
            }

            // Header Section: Home (45sp bold) and Vehari • Discover live rooms
            item {
                PaddingHeader(
                    onOpenCityScreen = onOpenCityScreen
                )
            }

            // Mobile Volume Controller Banner matching user Flutter code
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp, vertical = 4.dp)
                ) {
                    DeviceVolumeBanner(
                        volumeState = volumeState,
                        title = "Mobile Volume"
                    )
                }
            }

            // Female Only Card (Requested prominently in Flutter code)
            item {
                Box(modifier = Modifier.scale(volumeState.viewScale)) {
                    FemaleOnlyProminentCard(
                        pulseScale = pulseLive,
                        onClick = onOpenFemaleOnlyRooms
                    )
                }
            }

            // Co-ed Card (Requested in Flutter code)
            item {
                Box(modifier = Modifier.scale(volumeState.viewScale)) {
                    CoEdCombineCard(
                        pulseScale = pulseLive,
                        onClick = { viewModel.enterEveryoneRoom() }
                    )
                }
            }

            // Secondary Quick Atmosphere Card: Male Only Lounge
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp, vertical = 6.dp)
                ) {
                    QuickLoungeCard(
                        title = "MALE ONLY",
                        subtitle = "Boys banter & gaming lounge",
                        liveCount = "58 Live",
                        glowColor = HollowNeonBlueSky,
                        emoji = "♂️",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { viewModel.openMaleRooms() },
                        testTag = "card_male_only_vehari"
                    )
                }
            }

            // Badshah PK Showdown Grand Banner Card
            item {
                BadshahPKShowdownBanner(
                    pulseScale = pulseLive,
                    onClick = onOpenBadshahShowdown
                )
            }
        }
    }

    if (showCreateRoomDialog) {
        CreateRoomDialog(
            onDismiss = { viewModel.setCreateRoomDialogVisible(false) },
            onCreate = { title, topic, category ->
                viewModel.createRoom(title, topic, category)
            }
        )
    }
}

@Composable
private fun PaddingTopBar(
    isSearchActive: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToggleSearch: () -> Unit,
    onNotificationsClick: () -> Unit,
    isAdmin: Boolean,
    onAdminClick: () -> Unit
) {
    PaddingTopBarContent(
        isSearchActive = isSearchActive,
        searchQuery = searchQuery,
        onSearchQueryChange = onSearchQueryChange,
        onToggleSearch = onToggleSearch,
        onNotificationsClick = onNotificationsClick,
        isAdmin = isAdmin,
        onAdminClick = onAdminClick
    )
}

@Composable
private fun PaddingTopBarContent(
    isSearchActive: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToggleSearch: () -> Unit,
    onNotificationsClick: () -> Unit,
    isAdmin: Boolean,
    onAdminClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Time "9:41" as specified in Flutter code
            Text(
                text = "9:41",
                style = TextStyle(
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            )

            Spacer(modifier = Modifier.width(20.dp))

            // Center HOLLOW container: height 35, color #1C1C1E, borderRadius 20
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(35.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF1C1C1E)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "HOLLOW",
                    style = TextStyle(
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp,
                        fontSize = 13.sp
                    )
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Search Icon
            IconButton(
                onClick = onToggleSearch,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("vehari_search_icon")
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Notification Icon
            IconButton(
                onClick = onNotificationsClick,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("vehari_notification_icon")
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsNone,
                    contentDescription = "Notifications",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Google Sign In / Account Button matching Flutter AppBar actions
            GoogleSignInActionButton()

            if (isAdmin) {
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onAdminClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Admin Panel",
                        tint = HollowGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Animated Search Input Bar
        AnimatedVisibility(visible = isSearchActive) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF1C1C1E),
                border = BorderStroke(1.dp, HollowNeonPurple.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = HollowNeonPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(HollowNeonPurple),
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "Search live rooms in Vehari...",
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontSize = 14.sp
                                )
                            }
                            innerTextField()
                        }
                    )
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PaddingHeader(
    onOpenCityScreen: () -> Unit
) {
    PaddingHeaderContent(onOpenCityScreen = onOpenCityScreen)
}

@Composable
private fun PaddingHeaderContent(
    onOpenCityScreen: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        // "Home" (size 45, bold, white) as specified in Flutter code
        Text(
            text = "Home",
            style = TextStyle(
                color = Color.White,
                fontSize = 45.sp,
                fontWeight = FontWeight.Bold
            )
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // "Vehari • Discover live rooms"
            Text(
                text = "Vehari • Discover live rooms",
                style = TextStyle(
                    color = Color.White.copy(alpha = 0.54f),
                    fontSize = 14.sp
                )
            )

            // Golden Crown City Switcher
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onOpenCityScreen() }
                    .testTag("switch_city_button"),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF1E1624),
                border = BorderStroke(1.dp, HollowGold.copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("👑", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Vehari",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = HollowGold
                    )
                    Icon(
                        Icons.Default.KeyboardArrowDown,
                        contentDescription = "Switch City",
                        tint = HollowGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun FemaleOnlyProminentCard(
    pulseScale: Float,
    onClick: () -> Unit
) {
    // Flutter: margin: (15, 10), padding: 20, borderRadius: 25, gradient: LinearGradient([0xFFE89CAE, 0xFF9D4EDD])
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 15.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFFE89CAE), Color(0xFF9D4EDD))
                )
            )
            .clickable { onClick() }
            .padding(20.dp)
            .testTag("female_only_prominent_card")
    ) {
        Column {
            // Top row: Shield + "Female Only" (size 20, bold) and "PREMIUM" bordered pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Female Only",
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.dp, Color.White, RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "PREMIUM",
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3 Avatars: CircleAvatar(radius: 35) = 70.dp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AvatarCircleCard(
                    emoji = "🌸",
                    name = "Ayesha",
                    bgColor = Color(0xFFFFD1DC)
                )
                AvatarCircleCard(
                    emoji = "✨",
                    name = "Zainab",
                    bgColor = Color(0xFFE2B4FF)
                )
                AvatarCircleCard(
                    emoji = "💫",
                    name = "Fatima",
                    bgColor = Color(0xFFFFB7B2)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom row: People + "12 active now in Vehari"
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.People,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "12 active now in Vehari",
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
    }
}

@Composable
fun CoEdCombineCard(
    pulseScale: Float,
    onClick: () -> Unit
) {
    // Flutter: margin: (15, 8), padding: 20, borderRadius: 25, gradient: LinearGradient([0xFF4A6CF7), Color(0xFF2EC5CE)])
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 15.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF4A6CF7), Color(0xFF2EC5CE))
                )
            )
            .clickable { onClick() }
            .padding(20.dp)
            .testTag("coed_combine_card")
    ) {
        Column {
            // Top row: People + "Co-ed / Combine" (size 18, bold) and "OPEN" bordered pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.People,
                        contentDescription = "People",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Co-ed / Combine",
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.dp, Color.White, RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "OPEN",
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3 Avatars: CircleAvatar(radius: 35) = 70.dp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AvatarCircleCard(
                    emoji = "🎙️",
                    name = "Ahmed",
                    bgColor = Color(0xFF6B8AFF)
                )
                AvatarCircleCard(
                    emoji = "👑",
                    name = "Bilal",
                    bgColor = Color(0xFF38D9D6)
                )
                AvatarCircleCard(
                    emoji = "🎧",
                    name = "Hamza",
                    bgColor = Color(0xFF5BA4F8)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom row: People + "38 active now"
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.People,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "38 active now",
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
    }
}

@Composable
fun AvatarCircleCard(
    emoji: String,
    name: String,
    bgColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(bgColor)
                .border(2.5.dp, Color.White.copy(alpha = 0.9f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(emoji, fontSize = 28.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = name,
            fontSize = 11.sp,
            color = Color.White.copy(alpha = 0.9f),
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun QuickLoungeCard(
    title: String,
    subtitle: String,
    liveCount: String,
    glowColor: Color,
    emoji: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF14141A),
        border = BorderStroke(1.dp, glowColor.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 22.sp)
                Text(
                    text = liveCount,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = glowColor
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.55f),
                maxLines = 1
            )
        }
    }
}

@Composable
fun BadshahPKShowdownBanner(
    pulseScale: Float,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 15.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag("badshah_pk_banner_vehari"),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF18140B),
        border = BorderStroke(1.5.dp, HollowGold.copy(alpha = 0.65f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Trophy
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(HollowGold.copy(alpha = 0.2f))
                    .border(1.5.dp, HollowGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = HollowGold,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Badshah PK Showdown",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = HollowGold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFFE2C55)
                    ) {
                        Text(
                            text = "LIVE PK",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Official Host vs Host Grand Arena • Battle for the Crown",
                    fontSize = 11.5.sp,
                    color = Color.White.copy(alpha = 0.65f)
                )
            }

            // Arrow
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = HollowGold,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun VehariRoomCard(
    room: VehariLiveRoom,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 15.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag("vehari_room_card_${room.id}"),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF141419),
        border = BorderStroke(
            1.dp,
            if (room.isFemaleOnly) HollowNeonPink.copy(alpha = 0.5f) else Color(0xFF262630)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (room.isFemaleOnly) {
                            Brush.linearGradient(listOf(HollowNeonPink, HollowNeonPurple))
                        } else {
                            Brush.linearGradient(listOf(HollowNeonPurple, HollowNeonBlueSky))
                        }
                    )
                    .border(1.5.dp, Color.White.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = room.host.take(1),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = room.title,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    if (room.isHot) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("🔥", fontSize = 12.sp)
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Host: ${room.host} • ${room.topic}",
                    fontSize = 11.5.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.People,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${room.listeners} listening",
                        fontSize = 10.5.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Headphones,
                        contentDescription = null,
                        tint = OnlineGreen,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${room.speakers} mic",
                        fontSize = 10.5.sp,
                        color = OnlineGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Join Voice Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (room.isFemaleOnly) HollowNeonPink else HollowNeonPurple
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Join",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
