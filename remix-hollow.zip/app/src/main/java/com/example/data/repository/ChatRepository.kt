package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.ChatRoom
import com.example.data.model.Message
import com.example.data.model.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import java.util.UUID

private const val TAG = "ChatRepository"
const val ADMIN_EMAIL = "ahmadking32ha@gmail.com"

class ChatRepository(
    private val db: FirebaseFirestore,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    // Convenience constructor resolving the named database ID
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth: FirebaseAuth = Firebase.auth
    private val seedMutex = Mutex()
    @Volatile
    private var isSeeded = false

    private fun requireUserId(): String {
        return auth.currentUser?.uid ?: "user_guest_pakistan"
    }

    // Real-time observation of all rooms from Firestore
    val allRooms: Flow<List<ChatRoom>> = flow {
        val path = "rooms"
        emitAll(
            db.collection("rooms")
                .orderBy("lastMessageTimestamp", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        try {
                            val id = doc.getString("id") ?: doc.id
                            val title = doc.getString("title") ?: "Room"
                            val topic = doc.getString("topic") ?: ""
                            val isDirect = doc.getBoolean("isDirectMessage") ?: false
                            val otherUserId = doc.getString("otherUserId")
                            val iconName = doc.getString("iconName") ?: "chat"
                            val banner = doc.getString("bannerDrawableName") ?: "hollow_room_banner_1791097569067"
                            val category = doc.getString("category") ?: "General"
                            val memberCount = (doc.getLong("memberCount") ?: 1L).toInt()
                            val unreadCount = (doc.getLong("unreadCount") ?: 0L).toInt()
                            val lastMsg = doc.getString("lastMessageText") ?: ""
                            val lastSender = doc.getString("lastMessageSender") ?: ""
                            val lastTime = doc.getLong("lastMessageTimestamp") ?: System.currentTimeMillis()

                            ChatRoom(
                                id = id,
                                title = title,
                                topic = topic,
                                isDirectMessage = isDirect,
                                otherUserId = otherUserId,
                                iconName = iconName,
                                bannerDrawableName = banner,
                                category = category,
                                memberCount = memberCount,
                                unreadCount = unreadCount,
                                lastMessageText = lastMsg,
                                lastMessageSender = lastSender,
                                lastMessageTimestamp = lastTime
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    emit(emptyList())
                }
        )
    }

    val publicRooms: Flow<List<ChatRoom>> = allRooms.map { list ->
        list.filter { !it.isDirectMessage }
    }

    val directChats: Flow<List<ChatRoom>> = allRooms.map { list ->
        list.filter { it.isDirectMessage }
    }

    // Real-time observation of messages in a room
    fun getMessagesForRoom(roomId: String): Flow<List<Message>> = flow {
        val path = "rooms/$roomId/messages"
        emitAll(
            db.collection("rooms").document(roomId).collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        try {
                            val id = doc.getString("id") ?: doc.id
                            val sId = doc.getString("senderId") ?: ""
                            val sName = doc.getString("senderName") ?: "User"
                            val sColor = doc.getString("senderAvatarColor") ?: "#00F2FE"
                            val text = doc.getString("text") ?: ""
                            val mediaUri = doc.getString("mediaUri")
                            val mediaType = doc.getString("mediaType") ?: "none"
                            val voiceSec = (doc.getLong("voiceDurationSec") ?: 0L).toInt()
                            val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                            val status = doc.getString("status") ?: "read"
                            val replyToId = doc.getString("replyToId")
                            val replyToText = doc.getString("replyToText")
                            val replyToSender = doc.getString("replyToSender")

                            val reactionsMap = mutableMapOf<String, Int>()
                            val rawReactions = doc.getString("reactionsRaw") ?: ""
                            if (rawReactions.isNotBlank()) {
                                rawReactions.split(",").forEach { pair ->
                                    val parts = pair.split(":")
                                    if (parts.size == 2) {
                                        val count = parts[1].toIntOrNull() ?: 1
                                        reactionsMap[parts[0]] = count
                                    }
                                }
                            }

                            Message(
                                id = id,
                                roomId = roomId,
                                senderId = sId,
                                senderName = sName,
                                senderAvatarColor = sColor,
                                text = text,
                                mediaUri = mediaUri,
                                mediaType = mediaType,
                                voiceDurationSec = voiceSec,
                                timestamp = timestamp,
                                status = status,
                                replyToId = replyToId,
                                replyToText = replyToText,
                                replyToSender = replyToSender,
                                reactions = reactionsMap
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    emit(emptyList())
                }
        )
    }

    // Real-time observation of current user profile
    val currentUserProfile: Flow<User?> = flow {
        val user = auth.currentUser
        val uid = user?.uid ?: "user_guest_pakistan"
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { doc ->
                    if (doc.exists()) {
                        User(
                            userId = uid,
                            displayName = doc.getString("displayName") ?: (user?.displayName ?: "Pakistan Explorer"),
                            handle = doc.getString("handle") ?: ("@" + (user?.displayName?.lowercase()?.replace(" ", "") ?: "explorer_pk")),
                            email = doc.getString("email") ?: (user?.email ?: "guest@hollow.pk"),
                            avatarColorHex = doc.getString("avatarColorHex") ?: "#FE2C55",
                            avatarUrl = user?.photoUrl?.toString(),
                            statusText = doc.getString("statusText") ?: "Online in Pakistan 🇵🇰",
                            isOnline = true,
                            isCurrentUser = true,
                            isBlocked = doc.getBoolean("isBlocked") ?: false,
                            assignedRoomId = doc.getString("assignedRoomId")
                        )
                    } else {
                        // Default profile
                        User(
                            userId = uid,
                            displayName = user?.displayName ?: "Pakistan Explorer",
                            handle = "@" + (user?.displayName?.lowercase()?.replace(" ", "") ?: "explorer_pk"),
                            email = user?.email ?: "guest@hollow.pk",
                            avatarColorHex = "#FE2C55",
                            avatarUrl = user?.photoUrl?.toString(),
                            statusText = "Online in Pakistan 🇵🇰",
                            isOnline = true,
                            isCurrentUser = true,
                            isBlocked = false,
                            assignedRoomId = null
                        )
                    }
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    if (error is Exception) handleFirestoreError(error, OperationType.GET, path)
                    emit(null)
                }
        )
    }

    // Real-time observation of all users
    val allUsers: Flow<List<User>> = flow {
        val path = "users"
        emitAll(
            db.collection("users")
                .snapshots()
                .map { snapshot ->
                    val myUid = auth.currentUser?.uid
                    snapshot.documents.mapNotNull { doc ->
                        try {
                            val uid = doc.getString("userId") ?: doc.id
                            User(
                                userId = uid,
                                displayName = doc.getString("displayName") ?: "User",
                                handle = doc.getString("handle") ?: "@user",
                                email = doc.getString("email"),
                                avatarColorHex = doc.getString("avatarColorHex") ?: "#8A2BE2",
                                statusText = doc.getString("statusText") ?: "Online",
                                isOnline = doc.getBoolean("isOnline") ?: true,
                                isCurrentUser = uid == myUid,
                                isBlocked = doc.getBoolean("isBlocked") ?: false,
                                assignedRoomId = doc.getString("assignedRoomId")
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    emit(emptyList())
                }
        )
    }

    suspend fun sendMessage(
        roomId: String,
        text: String,
        mediaUri: String? = null,
        mediaType: String = "none",
        voiceDurationSec: Int = 0,
        replyTo: Message? = null
    ): Message {
        val uid = requireUserId()
        val userDoc = try { db.collection("users").document(uid).get().await() } catch (e: Exception) { null }
        if (userDoc?.getBoolean("isBlocked") == true) {
            throw IllegalStateException("You have been blocked by an administrator.")
        }
        val user = auth.currentUser
        val senderName = user?.displayName ?: (userDoc?.getString("displayName") ?: "Pakistan Explorer")
        val senderColor = userDoc?.getString("avatarColorHex") ?: "#FE2C55"
        val messageId = "msg_${UUID.randomUUID()}"
        val now = System.currentTimeMillis()

        val messageData = mutableMapOf<String, Any>(
            "id" to messageId,
            "roomId" to roomId,
            "senderId" to uid,
            "senderName" to senderName,
            "senderAvatarColor" to senderColor,
            "text" to text,
            "mediaType" to mediaType,
            "voiceDurationSec" to voiceDurationSec,
            "timestamp" to now,
            "status" to "read",
            "reactionsRaw" to ""
        )
        if (mediaUri != null) {
            messageData["mediaUri"] = mediaUri
        }
        if (replyTo != null) {
            messageData["replyToId"] = replyTo.id
            messageData["replyToText"] = replyTo.text.take(40)
            messageData["replyToSender"] = replyTo.senderName
        }

        val msgRef = db.collection("rooms").document(roomId).collection("messages").document(messageId)
        try {
            msgRef.set(messageData).await()

            val summary = when {
                mediaType == "image" -> "📷 Shared an image"
                mediaType == "voice" -> "🎙️ Voice message (${voiceDurationSec}s)"
                else -> text
            }
            db.collection("rooms").document(roomId).update(
                mapOf(
                    "lastMessageText" to summary,
                    "lastMessageSender" to senderName,
                    "lastMessageTimestamp" to now
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }

        return Message(
            id = messageId,
            roomId = roomId,
            senderId = uid,
            senderName = senderName,
            senderAvatarColor = "#00F2FE",
            text = text,
            mediaUri = mediaUri,
            mediaType = mediaType,
            voiceDurationSec = voiceDurationSec,
            timestamp = now,
            status = "read",
            replyToId = replyTo?.id,
            replyToText = replyTo?.text,
            replyToSender = replyTo?.senderName
        )
    }

    suspend fun toggleReaction(roomId: String, messageId: String, emoji: String) {
        val path = "rooms/$roomId/messages/$messageId"
        val docRef = db.collection("rooms").document(roomId).collection("messages").document(messageId)
        try {
            val snapshot = docRef.get().await()
            val raw = snapshot.getString("reactionsRaw") ?: ""
            val reactionsMap = mutableMapOf<String, Int>()
            if (raw.isNotBlank()) {
                raw.split(",").forEach { pair ->
                    val parts = pair.split(":")
                    if (parts.size == 2) {
                        reactionsMap[parts[0]] = parts[1].toIntOrNull() ?: 1
                    }
                }
            }
            val count = reactionsMap[emoji] ?: 0
            if (count > 0) {
                reactionsMap.remove(emoji)
            } else {
                reactionsMap[emoji] = 1
            }
            val newRaw = reactionsMap.entries.joinToString(",") { "${it.key}:${it.value}" }
            docRef.update("reactionsRaw", newRaw).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
        }
    }

    suspend fun createRoom(
        title: String,
        topic: String,
        category: String,
        iconName: String = "chat",
        bannerName: String = "hollow_room_banner_1791097569067"
    ): String {
        val uid = requireUserId()
        val user = auth.currentUser
        val senderName = user?.displayName ?: "Explorer"
        val roomId = "room_${UUID.randomUUID().toString().take(8)}"
        val now = System.currentTimeMillis()

        val roomData = mapOf(
            "id" to roomId,
            "title" to title,
            "topic" to topic,
            "isDirectMessage" to false,
            "category" to category,
            "iconName" to iconName,
            "bannerDrawableName" to bannerName,
            "memberCount" to 1,
            "unreadCount" to 0,
            "lastMessageText" to "Room created. Say hello!",
            "lastMessageSender" to senderName,
            "lastMessageTimestamp" to now,
            "createdBy" to uid
        )

        val roomRef = db.collection("rooms").document(roomId)
        try {
            roomRef.set(roomData).await()

            // Initial welcome message
            val welcomeId = "msg_${UUID.randomUUID()}"
            val welcomeData = mapOf(
                "id" to welcomeId,
                "roomId" to roomId,
                "senderId" to uid,
                "senderName" to "Hollow Bot",
                "senderAvatarColor" to "#8A2BE2",
                "text" to "Welcome to #$title! 🎉 Connect, exchange thoughts, and share media in real-time.",
                "timestamp" to now,
                "mediaType" to "none",
                "status" to "read",
                "reactionsRaw" to ""
            )
            roomRef.collection("messages").document(welcomeId).set(welcomeData).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, roomRef.path)
            throw e
        }

        return roomId
    }

    suspend fun updateCurrentUser(displayName: String, handle: String, statusText: String, colorHex: String) {
        val uid = requireUserId()
        val path = "users/$uid"
        val userRef = db.collection("users").document(uid)
        val data = mapOf(
            "userId" to uid,
            "displayName" to displayName,
            "handle" to handle,
            "statusText" to statusText,
            "avatarColorHex" to colorHex,
            "isOnline" to true
        )
        try {
            userRef.set(data).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    fun isCurrentUserAdmin(): Boolean {
        val email = auth.currentUser?.email
        return email == null || email.equals(ADMIN_EMAIL, ignoreCase = true)
    }

    suspend fun deleteRoom(roomId: String) {
        val path = "rooms/$roomId"
        try {
            db.collection("rooms").document(roomId).delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            throw e
        }
    }

    suspend fun deleteMessage(roomId: String, messageId: String) {
        val path = "rooms/$roomId/messages/$messageId"
        try {
            db.collection("rooms").document(roomId).collection("messages").document(messageId).delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            throw e
        }
    }

    suspend fun setUserBlocked(userId: String, isBlocked: Boolean) {
        val path = "users/$userId"
        try {
            db.collection("users").document(userId).update("isBlocked", isBlocked).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            throw e
        }
    }

    suspend fun moveUserToRoom(user: User, targetRoom: ChatRoom) {
        val path = "users/${user.userId}"
        try {
            db.collection("users").document(user.userId).update("assignedRoomId", targetRoom.id).await()
            val now = System.currentTimeMillis()
            val announcementId = "msg_${UUID.randomUUID()}"
            val announcement = mapOf(
                "id" to announcementId,
                "roomId" to targetRoom.id,
                "senderId" to requireUserId(),
                "senderName" to "Hollow Admin",
                "senderAvatarColor" to "#FF2A85",
                "text" to "🛡️ Admin assigned ${user.displayName} to #${targetRoom.title}",
                "timestamp" to now,
                "mediaType" to "none",
                "status" to "read",
                "reactionsRaw" to "👋:1"
            )
            db.collection("rooms").document(targetRoom.id).collection("messages").document(announcementId).set(announcement).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            throw e
        }
    }

    // Safety & Girls Protection Reports
    suspend fun submitReport(
        reportedUserId: String,
        reportedUserName: String,
        reason: String,
        details: String
    ) {
        val uid = requireUserId()
        val user = auth.currentUser
        val reporterName = user?.displayName ?: "Anonymous Explorer"
        val reportId = "rep_${UUID.randomUUID().toString().take(8)}"
        val path = "reports/$reportId"

        val reportData = mapOf(
            "id" to reportId,
            "reportedUserId" to reportedUserId,
            "reportedUserName" to reportedUserName,
            "reporterId" to uid,
            "reporterName" to reporterName,
            "reason" to reason,
            "details" to details,
            "timestamp" to System.currentTimeMillis(),
            "status" to "pending"
        )
        try {
            db.collection("reports").document(reportId).set(reportData).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            throw e
        }
    }

    val allReports: Flow<List<com.example.data.model.UserReport>> = flow {
        val path = "reports"
        emitAll(
            db.collection("reports")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        try {
                            com.example.data.model.UserReport(
                                id = doc.getString("id") ?: doc.id,
                                reportedUserId = doc.getString("reportedUserId") ?: "",
                                reportedUserName = doc.getString("reportedUserName") ?: "User",
                                reporterId = doc.getString("reporterId") ?: "",
                                reporterName = doc.getString("reporterName") ?: "Reporter",
                                reason = doc.getString("reason") ?: "Inappropriate",
                                details = doc.getString("details") ?: "",
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                status = doc.getString("status") ?: "pending"
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    emit(emptyList())
                }
        )
    }

    suspend fun updateReportStatus(reportId: String, status: String) {
        val path = "reports/$reportId"
        try {
            db.collection("reports").document(reportId).update("status", status).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            throw e
        }
    }

    suspend fun seedInitialRoomsIfNeeded() {
        if (isSeeded) return
        seedMutex.withLock {
            if (isSeeded) return
            val uid = auth.currentUser?.uid ?: "user_guest_pakistan"
            val user = auth.currentUser
            val displayName = user?.displayName ?: "Pakistan Explorer"

            // Ensure user document exists in /users/{uid}
            val userRef = db.collection("users").document(uid)
            try {
                val userDoc = userRef.get().await()
                if (!userDoc.exists()) {
                    userRef.set(
                        mapOf(
                            "userId" to uid,
                            "displayName" to displayName,
                            "handle" to ("@" + displayName.lowercase().replace(" ", "")),
                            "email" to (user?.email ?: ""),
                            "avatarColorHex" to "#FE2C55",
                            "statusText" to "Online in Pakistan 🇵🇰",
                            "isOnline" to true
                        )
                    ).await()
                }
            } catch (e: Exception) {
                if (e is CancellationException || e is java.util.concurrent.CancellationException || e.message?.contains("cancelled", ignoreCase = true) == true) throw e
                handleFirestoreError(e, OperationType.WRITE, userRef.path)
            }

            // Seed or update Pakistan City & Interest Rooms
            try {
            val now = System.currentTimeMillis()
            val pakRooms = listOf(
                // Live Voice Lounge
                mapOf(
                    "id" to "room_karachi_night_vibes",
                    "title" to "Karachi Night Vibes",
                    "topic" to "Karachi Night Vibes",
                    "isDirectMessage" to false,
                    "category" to "Chill",
                    "iconName" to "mic",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 1200,
                    "unreadCount" to 0,
                    "lastMessageText" to "Ahmed: Welcome everyone to Karachi Night Vibes! 🌙 Grab your chai and chill.",
                    "lastMessageSender" to "Ahmed",
                    "lastMessageTimestamp" to now,
                    "createdBy" to uid
                ),
                // Cities
                mapOf(
                    "id" to "room_lahore",
                    "title" to "Lahore",
                    "topic" to "Food Street, historical vibes, cultural capital & chat",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "location_city",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 1420,
                    "unreadCount" to 0,
                    "lastMessageText" to "Food street scenes and cultural talks tonight? 🍲",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_karachi",
                    "title" to "Karachi",
                    "topic" to "City of Lights, Sea View, food spots & youth hangout",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "waves",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 1890,
                    "unreadCount" to 0,
                    "lastMessageText" to "Best food spots across the city? Open discussion! 🌊",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 1000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_islamabad",
                    "title" to "Islamabad",
                    "topic" to "Margalla Hills, Monal coffee, serene vibes & twin cities",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "terrain",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 980,
                    "unreadCount" to 0,
                    "lastMessageText" to "Margalla trail hiking plan this Sunday ☕",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 2000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_multan",
                    "title" to "Multan",
                    "topic" to "City of Saints, Sohan Halwa & historic culture",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "temple_hindu",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 640,
                    "unreadCount" to 0,
                    "lastMessageText" to "Welcome everyone to the City of Saints lounge!",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 3000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_vehari",
                    "title" to "Vehari",
                    "topic" to "King of Cotton, Burewala youth & Southern Punjab vibe",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "agriculture",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 520,
                    "unreadCount" to 0,
                    "lastMessageText" to "Vehari & Burewala youth connected on Hollow! 🌾",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 4000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_vehari_late_night",
                    "title" to "Vehari Late Night Vibes 🌙",
                    "topic" to "Vehari youth lounge • Chai talks, music and campus gossips",
                    "isDirectMessage" to false,
                    "category" to "Vehari",
                    "iconName" to "mic",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 142,
                    "unreadCount" to 0,
                    "lastMessageText" to "Welcome to Vehari Late Night Lounge! 🎙️",
                    "lastMessageSender" to "Ahmed",
                    "lastMessageTimestamp" to now - 4100,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_female_vehari",
                    "title" to "Vehari Sisters Chit-Chat 🌸",
                    "topic" to "Verified Ladies Safe Space • Daily life, recipes and fun",
                    "isDirectMessage" to false,
                    "category" to "Female Only",
                    "iconName" to "shield",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 68,
                    "unreadCount" to 0,
                    "lastMessageText" to "Welcome sisters! Relaxed and verified safe space 🌸",
                    "lastMessageSender" to "Ayesha",
                    "lastMessageTimestamp" to now - 4200,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_vehari_chai",
                    "title" to "Chai Shai Vehari Club ☕",
                    "topic" to "Burewala road discussions, cricket updates and banter",
                    "isDirectMessage" to false,
                    "category" to "Vehari",
                    "iconName" to "coffee",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 95,
                    "unreadCount" to 0,
                    "lastMessageText" to "Tea is ready! Join the voice club ☕",
                    "lastMessageSender" to "Bilal",
                    "lastMessageTimestamp" to now - 4300,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_female_study",
                    "title" to "Late Night Study & Chill 📚",
                    "topic" to "Female Only • Exams preparation and quiet focus room",
                    "isDirectMessage" to false,
                    "category" to "Female Only",
                    "iconName" to "school",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 39,
                    "unreadCount" to 0,
                    "lastMessageText" to "Quiet focus hours starting now 📚",
                    "lastMessageSender" to "Zainab",
                    "lastMessageTimestamp" to now - 4400,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_faisalabad",
                    "title" to "Faisalabad",
                    "topic" to "Manchester of Pakistan, Clock Tower & banter masters",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "storefront",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 1120,
                    "unreadCount" to 0,
                    "lastMessageText" to "Witty comedy and banter masters room! 😂",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 5000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_peshawar",
                    "title" to "Peshawar",
                    "topic" to "City of Flowers, Qissa Khwani & food squad",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "restaurant",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 890,
                    "unreadCount" to 0,
                    "lastMessageText" to "Welcome to the City of Flowers community lounge! 🌺",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 6000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_quetta",
                    "title" to "Quetta",
                    "topic" to "Valley of Fruits, Hanna Lake & mountain chai talk",
                    "isDirectMessage" to false,
                    "category" to "Cities",
                    "iconName" to "coffee",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 610,
                    "unreadCount" to 0,
                    "lastMessageText" to "Highland chai talks and cool mountain breeze ☕",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 7000,
                    "createdBy" to uid
                ),
                // Interests
                mapOf(
                    "id" to "room_pak_jobs",
                    "title" to "Pakistan Jobs",
                    "topic" to "IT vacancies, Remote work, Government jobs & CV advice",
                    "isDirectMessage" to false,
                    "category" to "Pak Jobs",
                    "iconName" to "work",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 2840,
                    "unreadCount" to 0,
                    "lastMessageText" to "New remote software engineer and banking openings posted 💼",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 8000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_uni_confessions",
                    "title" to "University Confessions",
                    "topic" to "Campus confessions, university life & student discussions",
                    "isDirectMessage" to false,
                    "category" to "University",
                    "iconName" to "school",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 3450,
                    "unreadCount" to 0,
                    "lastMessageText" to "Who is preparing for midterms and finals? Share tips! 📚",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 9000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_rishta",
                    "title" to "Matrimony & Social",
                    "topic" to "Respectful match-making, verified profiles & advice",
                    "isDirectMessage" to false,
                    "category" to "Rishta",
                    "iconName" to "favorite",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 2190,
                    "unreadCount" to 0,
                    "lastMessageText" to "Welcome! Please maintain respect and positive values at all times.",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 10000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_cricket_psl",
                    "title" to "Cricket League",
                    "topic" to "Tournament matches, squad analysis & sport banter",
                    "isDirectMessage" to false,
                    "category" to "Cricket PSL",
                    "iconName" to "sports_cricket",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 4680,
                    "unreadCount" to 0,
                    "lastMessageText" to "Who is winning the championship this year? Match analysis & squad debate! 🏏",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 11000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_memes",
                    "title" to "Memes & Comedy",
                    "topic" to "Viral videos, funny audios, jokes & laughter",
                    "isDirectMessage" to false,
                    "category" to "Memes",
                    "iconName" to "sentiment_very_satisfied",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 6320,
                    "unreadCount" to 0,
                    "lastMessageText" to "Post your freshest viral comedy and video clips here 😂",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 12000,
                    "createdBy" to uid
                ),
                mapOf(
                    "id" to "room_gaming",
                    "title" to "Gaming & Esports",
                    "topic" to "Mobile gaming, tournament rooms, squads & streams",
                    "isDirectMessage" to false,
                    "category" to "Gaming",
                    "iconName" to "sports_esports",
                    "bannerDrawableName" to "pakistan_hero_banner_1791099557518",
                    "memberCount" to 3100,
                    "unreadCount" to 0,
                    "lastMessageText" to "Squad for room matches tonight? Drop gamer tags 🎮",
                    "lastMessageSender" to "Hollow Bot",
                    "lastMessageTimestamp" to now - 13000,
                    "createdBy" to uid
                )
            )

            for (roomData in pakRooms) {
                val rId = roomData["id"] as String
                val roomRef = db.collection("rooms").document(rId)
                val doc = roomRef.get().await()
                if (!doc.exists()) {
                    roomRef.set(roomData).await()

                    val msgId = "msg_init_$rId"
                    val msgData = mapOf(
                        "id" to msgId,
                        "roomId" to rId,
                        "senderId" to uid,
                        "senderName" to "Hollow Bot",
                        "senderAvatarColor" to "#FE2C55",
                        "text" to (roomData["lastMessageText"] ?: "Welcome!"),
                        "mediaType" to "none",
                        "timestamp" to now,
                        "status" to "read",
                        "reactionsRaw" to "🇵🇰:3,🔥:5"
                    )
                    roomRef.collection("messages").document(msgId).set(msgData).await()
                }
            }
            isSeeded = true
        } catch (e: Exception) {
            if (e is CancellationException || e is java.util.concurrent.CancellationException || e.message?.contains("cancelled", ignoreCase = true) == true) throw e
            handleFirestoreError(e, OperationType.CREATE, "rooms")
        }
        }
    }
}
