package com.example.data.model

data class User(
    val userId: String,
    val displayName: String,
    val handle: String,
    val email: String? = null,
    val avatarColorHex: String,
    val avatarUrl: String? = null,
    val statusText: String = "Online",
    val isOnline: Boolean = true,
    val isCurrentUser: Boolean = false,
    val isBlocked: Boolean = false,
    val assignedRoomId: String? = null
)

data class ChatRoom(
    val id: String,
    val title: String,
    val topic: String,
    val isDirectMessage: Boolean = false,
    val otherUserId: String? = null,
    val iconName: String = "chat",
    val bannerDrawableName: String = "hollow_room_banner_1791097569067",
    val category: String = "General",
    val memberCount: Int = 1,
    val unreadCount: Int = 0,
    val lastMessageText: String = "",
    val lastMessageSender: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val createdBy: String? = null,
    val isPrivate: Boolean = false,
    val password: String? = null
)

data class Message(
    val id: String,
    val roomId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarColor: String,
    val text: String,
    val mediaUri: String? = null,
    val mediaType: String = "none", // "none", "image", "voice"
    val voiceDurationSec: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "read", // "sending", "sent", "delivered", "read"
    val replyToId: String? = null,
    val replyToText: String? = null,
    val replyToSender: String? = null,
    val reactions: Map<String, Int> = emptyMap() // emoji -> count
)

data class RoomParticipant(
    val user: User,
    val role: String = "Member", // "Host", "Moderator", "Member"
    val isSpeaking: Boolean = false
)

data class UserReport(
    val id: String,
    val reportedUserId: String,
    val reportedUserName: String,
    val reporterId: String,
    val reporterName: String,
    val reason: String,
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "pending"
)

