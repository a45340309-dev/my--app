package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ChatRoom
import com.example.data.model.Message
import com.example.data.model.User

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String,
    val displayName: String,
    val handle: String,
    val avatarColorHex: String,
    val avatarUrl: String? = null,
    val statusText: String = "Online",
    val isOnline: Boolean = true,
    val isCurrentUser: Boolean = false
) {
    fun toDomain(): User = User(
        userId = userId,
        displayName = displayName,
        handle = handle,
        avatarColorHex = avatarColorHex,
        avatarUrl = avatarUrl,
        statusText = statusText,
        isOnline = isOnline,
        isCurrentUser = isCurrentUser
    )

    companion object {
        fun fromDomain(user: User): UserEntity = UserEntity(
            userId = user.userId,
            displayName = user.displayName,
            handle = user.handle,
            avatarColorHex = user.avatarColorHex,
            avatarUrl = user.avatarUrl,
            statusText = user.statusText,
            isOnline = user.isOnline,
            isCurrentUser = user.isCurrentUser
        )
    }
}

@Entity(tableName = "rooms")
data class ChatRoomEntity(
    @PrimaryKey val id: String,
    val title: String,
    val topic: String,
    val isDirectMessage: Boolean = false,
    val otherUserId: String? = null,
    val iconName: String = "chat",
    val bannerDrawableName: String = "hollow_room_banner_1791097569067",
    val category: String = "General",
    val memberCount: Int = 1,
    val unreadCount: Int = 0,
    val lastMessageText: String = "",
    val lastMessageSender: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis()
) {
    fun toDomain(): ChatRoom = ChatRoom(
        id = id,
        title = title,
        topic = topic,
        isDirectMessage = isDirectMessage,
        otherUserId = otherUserId,
        iconName = iconName,
        bannerDrawableName = bannerDrawableName,
        category = category,
        memberCount = memberCount,
        unreadCount = unreadCount,
        lastMessageText = lastMessageText,
        lastMessageSender = lastMessageSender,
        lastMessageTimestamp = lastMessageTimestamp
    )

    companion object {
        fun fromDomain(room: ChatRoom): ChatRoomEntity = ChatRoomEntity(
            id = room.id,
            title = room.title,
            topic = room.topic,
            isDirectMessage = room.isDirectMessage,
            otherUserId = room.otherUserId,
            iconName = room.iconName,
            bannerDrawableName = room.bannerDrawableName,
            category = room.category,
            memberCount = room.memberCount,
            unreadCount = room.unreadCount,
            lastMessageText = room.lastMessageText,
            lastMessageSender = room.lastMessageSender,
            lastMessageTimestamp = room.lastMessageTimestamp
        )
    }
}

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val roomId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarColor: String,
    val text: String,
    val mediaUri: String? = null,
    val mediaType: String = "none",
    val voiceDurationSec: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "read",
    val replyToId: String? = null,
    val replyToText: String? = null,
    val replyToSender: String? = null,
    val reactionsRaw: String = "" // formatted e.g. "❤️:2,🔥:1"
) {
    fun toDomain(): Message {
        val reactionsMap = mutableMapOf<String, Int>()
        if (reactionsRaw.isNotBlank()) {
            reactionsRaw.split(",").forEach { pair ->
                val parts = pair.split(":")
                if (parts.size == 2) {
                    val count = parts[1].toIntOrNull() ?: 1
                    reactionsMap[parts[0]] = count
                }
            }
        }
        return Message(
            id = id,
            roomId = roomId,
            senderId = senderId,
            senderName = senderName,
            senderAvatarColor = senderAvatarColor,
            text = text,
            mediaUri = mediaUri,
            mediaType = mediaType,
            voiceDurationSec = voiceDurationSec,
            timestamp = timestamp,
            status = status,
            replyToId = replyToId,
            replyToText = replyToText,
            replyToSender = replyToSender,
            reactions = reactionsMap
        )
    }

    companion object {
        fun fromDomain(msg: Message): MessageEntity {
            val raw = msg.reactions.entries.joinToString(",") { "${it.key}:${it.value}" }
            return MessageEntity(
                id = msg.id,
                roomId = msg.roomId,
                senderId = msg.senderId,
                senderName = msg.senderName,
                senderAvatarColor = msg.senderAvatarColor,
                text = msg.text,
                mediaUri = msg.mediaUri,
                mediaType = msg.mediaType,
                voiceDurationSec = msg.voiceDurationSec,
                timestamp = msg.timestamp,
                status = msg.status,
                replyToId = msg.replyToId,
                replyToText = msg.replyToText,
                replyToSender = msg.replyToSender,
                reactionsRaw = raw
            )
        }
    }
}
