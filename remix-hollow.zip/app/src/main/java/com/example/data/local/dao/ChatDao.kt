package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ChatRoomEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM rooms ORDER BY lastMessageTimestamp DESC")
    fun getAllRooms(): Flow<List<ChatRoomEntity>>

    @Query("SELECT * FROM rooms WHERE isDirectMessage = 0 ORDER BY lastMessageTimestamp DESC")
    fun getPublicRooms(): Flow<List<ChatRoomEntity>>

    @Query("SELECT * FROM rooms WHERE isDirectMessage = 1 ORDER BY lastMessageTimestamp DESC")
    fun getDirectChats(): Flow<List<ChatRoomEntity>>

    @Query("SELECT * FROM rooms WHERE id = :roomId LIMIT 1")
    fun getRoomById(roomId: String): Flow<ChatRoomEntity?>

    @Query("SELECT * FROM messages WHERE roomId = :roomId ORDER BY timestamp ASC")
    fun getMessagesForRoom(roomId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE mediaUri IS NOT NULL AND mediaUri != '' ORDER BY timestamp DESC")
    fun getAllMediaMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE roomId = :roomId AND mediaUri IS NOT NULL AND mediaUri != '' ORDER BY timestamp DESC")
    fun getMediaMessagesForRoom(roomId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE isCurrentUser = 1 LIMIT 1")
    fun getCurrentUser(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoom(room: ChatRoomEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<ChatRoomEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE rooms SET lastMessageText = :text, lastMessageSender = :sender, lastMessageTimestamp = :timestamp WHERE id = :roomId")
    suspend fun updateRoomLastMessage(roomId: String, text: String, sender: String, timestamp: Long)

    @Query("UPDATE rooms SET unreadCount = 0 WHERE id = :roomId")
    suspend fun markRoomAsRead(roomId: String)

    @Query("UPDATE messages SET reactionsRaw = :reactionsRaw WHERE id = :messageId")
    suspend fun updateMessageReactions(messageId: String, reactionsRaw: String)

    @Query("SELECT * FROM messages WHERE id = :messageId LIMIT 1")
    suspend fun getMessageById(messageId: String): MessageEntity?

    @Query("DELETE FROM messages WHERE id = :messageId")
    suspend fun deleteMessage(messageId: String)

    @Query("DELETE FROM rooms WHERE id = :roomId")
    suspend fun deleteRoom(roomId: String)

    @Query("SELECT COUNT(*) FROM rooms")
    suspend fun getRoomCount(): Int
}
