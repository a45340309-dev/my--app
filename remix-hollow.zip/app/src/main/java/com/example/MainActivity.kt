package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.BadshahShowdownScreen
import com.example.ui.screens.ChatCitiesScreen
import com.example.ui.screens.ChatRoomScreen
import com.example.ui.screens.CityScreen
import com.example.ui.screens.FemaleOnlyRoomsScreen
import com.example.ui.screens.GenderScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveVoiceRoomScreen
import com.example.ui.screens.MoodOnboardingScreen
import com.example.ui.screens.PasswordScreen
import com.example.ui.screens.RoomTypeScreen
import com.example.ui.screens.VehariHomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.HollowNavScreen

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppContent(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AppContent(viewModel: ChatViewModel) {
    androidx.compose.runtime.LaunchedEffect(Unit) {
        viewModel.onUserAuthenticated()
    }

    AppNavigation(viewModel = viewModel)
}

@Composable
fun AppNavigation(viewModel: ChatViewModel) {
    val activeRoomId by viewModel.activeRoomId.collectAsStateWithLifecycle()
    val showAdminPanel by viewModel.showAdminPanel.collectAsStateWithLifecycle()
    val showMoodOnboarding by viewModel.showMoodOnboarding.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val selectedCity by viewModel.selectedCity.collectAsStateWithLifecycle()
    val selectedGender by viewModel.selectedGender.collectAsStateWithLifecycle()

    if (showMoodOnboarding) {
        MoodOnboardingScreen(
            onDismiss = { viewModel.dismissMoodOnboarding() },
            onMoodSelected = { mood -> viewModel.selectMoodAndOpenRoom(mood) }
        )
    } else if (showAdminPanel) {
        AdminPanelScreen(
            viewModel = viewModel,
            onBack = { viewModel.closeAdminPanel() }
        )
    } else if (selectedTab == 3) {
        // Tab 3: Badshah PK Showdown Grand Arena
        BadshahShowdownScreen(viewModel = viewModel)
    } else if (selectedTab == 1 || selectedTab == 2) {
        // Tab 1: Messages / Direct Chats, Tab 2: Profile
        HomeScreen(viewModel = viewModel)
    } else if (activeRoomId != null || currentScreen == HollowNavScreen.LIVE_ROOM) {
        // When user clicks ANY room card, open Inside Room screen (Karachi Night Vibes, avatars, FREE x12 heart)
        LiveVoiceRoomScreen(
            viewModel = viewModel,
            onNavigateTab = { tab -> viewModel.setSelectedTab(tab) }
        )
    } else {
        // Tab 0: Vehari Home & Flow Navigation
        when (currentScreen) {
            HollowNavScreen.VEHARI_HOME -> {
                VehariHomeScreen(
                    viewModel = viewModel,
                    onOpenFemaleOnlyRooms = { viewModel.openFemaleOnlyRooms() },
                    onOpenCityScreen = { viewModel.openCityScreen() },
                    onOpenRoom = { roomId -> viewModel.openRoom(roomId) },
                    onOpenBadshahShowdown = { viewModel.setSelectedTab(3) }
                )
            }
            HollowNavScreen.FEMALE_ONLY_ROOMS -> {
                FemaleOnlyRoomsScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.openVehariHome() },
                    onOpenRoom = { roomId -> viewModel.openRoom(roomId) }
                )
            }
            HollowNavScreen.CITY -> {
                ChatCitiesScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.openVehariHome() },
                    onCitySelected = { city ->
                        viewModel.selectCity(city)
                    }
                )
            }
            HollowNavScreen.GENDER -> {
                GenderScreen(
                    cityName = selectedCity,
                    viewModel = viewModel,
                    onBack = { viewModel.navigateBackInFlow() },
                    onGenderSelected = { gender ->
                        viewModel.selectGender(gender)
                    }
                )
            }
            HollowNavScreen.ROOM_TYPE -> {
                RoomTypeScreen(
                    title = "$selectedGender - $selectedCity",
                    viewModel = viewModel,
                    onBack = { viewModel.navigateBackInFlow() },
                    onEveryoneRoomClick = { viewModel.enterEveryoneRoom() },
                    onPrivateRoomClick = { viewModel.openPasswordScreen() },
                    onRoomClick = { room ->
                        if (room.isPrivate) {
                            viewModel.openPasswordScreen()
                        } else {
                            viewModel.openRoom(room.id)
                        }
                    },
                    onCreateRoomClick = { viewModel.setCreateRoomDialogVisible(true) }
                )
            }
            HollowNavScreen.PASSWORD -> {
                PasswordScreen(
                    title = "Private Room Password",
                    onBack = { viewModel.navigateBackInFlow() },
                    onSuccess = { code ->
                        viewModel.verifyPasswordAndEnter(code)
                    },
                    onCreateHostRoom = { code ->
                        viewModel.setPrivateCodeAndCreateRoom(code)
                    }
                )
            }
            HollowNavScreen.LIVE_ROOM -> {
                LiveVoiceRoomScreen(
                    viewModel = viewModel,
                    onNavigateTab = { tab -> viewModel.setSelectedTab(tab) }
                )
            }
        }
    }
}
