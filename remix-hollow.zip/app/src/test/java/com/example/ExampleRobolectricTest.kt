package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.MessageEntity
import com.example.data.model.Message
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("HOLLOW", appName)
    }

    @Test
    fun `message entity domain conversion test`() {
        val domainMsg = Message(
            id = "test_1",
            roomId = "room_lounge",
            senderId = "user_me",
            senderName = "Alex Reed",
            senderAvatarColor = "#00F2FE",
            text = "Testing Hollow real-time chat",
            mediaType = "image",
            mediaUri = "res:drawable:hollow_room_banner_1791097569067",
            reactions = mapOf("🔥" to 3, "❤️" to 5)
        )

        val entity = MessageEntity.fromDomain(domainMsg)
        val converted = entity.toDomain()

        assertEquals("test_1", converted.id)
        assertEquals("room_lounge", converted.roomId)
        assertEquals("Testing Hollow real-time chat", converted.text)
        assertEquals(3, converted.reactions["🔥"])
        assertEquals(5, converted.reactions["❤️"])
        assertTrue(converted.mediaUri?.contains("hollow_room_banner") == true)
    }
}
