package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HoloDarkColorScheme = darkColorScheme(
    primary = HoloCyan,
    onPrimary = HoloDarkBackground,
    secondary = HoloRed,
    onSecondary = HoloTextPrimary,
    background = HoloDarkBackground,
    onBackground = HoloTextPrimary,
    surface = HoloSurface,
    onSurface = HoloTextPrimary,
    surfaceVariant = HoloSurfaceVariant,
    onSurfaceVariant = HoloTextSecondary,
    error = HoloRed,
    onError = HoloTextPrimary
)

@Composable
fun HoloTheme(
    content: @Composable () -> Unit
) {
  MaterialTheme(
      colorScheme = HoloDarkColorScheme,
      typography = Typography,
      content = content
  )
}
