package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloRed
import com.example.ui.theme.HoloSurface
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomScreen(
    onJoinRoom: (String, String, String) -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var isSearching by remember { mutableStateOf(false) }

  Scaffold(
      topBar = {
        TopAppBar(
            title = {
              if (isSearching) {
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search rooms...", color = HoloTextSecondary) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = HoloCyan,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = HoloTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("search_text_field")
                )
              } else {
                Text("Holo", style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, color = HoloTextPrimary))
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black),
            actions = {
              IconButton(
                  onClick = { isSearching = !isSearching },
                  modifier = Modifier.testTag("search_button")
              ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = HoloTextPrimary
                )
              }
              IconButton(
                  onClick = { /* Handle notifications */ },
                  modifier = Modifier.testTag("notifications_button")
              ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = HoloTextPrimary
                )
              }
            }
        )
      },
      containerColor = Color.Black
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 12.dp)
    ) {
      // Featured Live Stream Card
      Box(
          modifier = Modifier
              .fillMaxWidth()
              .height(340.dp)
              .clip(RoundedCornerShape(20.dp))
              .background(HoloSurface)
              .clickable {
                onJoinRoom("Ayesha Live", "12.5k viewers", "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=500")
              }
              .testTag("featured_live_card")
      ) {
        AsyncImage(
            model = "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=500",
            contentDescription = "Featured Stream",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Live badge
        Surface(
            color = HoloRed,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.TopStart)
        ) {
          Text(
              text = "LIVE",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }

        // Bottom info row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
          ) {
            AsyncImage(
                model = "https://randomuser.me/api/portraits/women/44.jpg",
                contentDescription = "Host Avatar",
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                  text = "Ayesha Live",
                  color = HoloTextPrimary,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp
              )
              Text(
                  text = "12.5k viewers",
                  color = HoloTextSecondary,
                  fontSize = 12.sp
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RoomActionButton(icon = Icons.Default.Favorite, tint = HoloRed, testTag = "fav_btn")
            RoomActionButton(icon = Icons.Default.ChatBubble, tint = Color.White, testTag = "chat_btn")
            RoomActionButton(icon = Icons.Default.CardGiftcard, tint = HoloCyan, testTag = "gift_btn")
            RoomActionButton(icon = Icons.Default.Share, tint = Color.White, testTag = "share_btn")
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
          text = "Trending Rooms",
          style = TextStyle(color = HoloTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold),
          modifier = Modifier.padding(vertical = 4.dp)
      )

      // Grid of Live Rooms
      val rooms = listOf(
          Pair("Zoya Stream", "8.2k"),
          Pair("Zara PK", "15.1k"),
          Pair("Hamza Gaming", "4.3k"),
          Pair("Fatima Talks", "9.7k"),
          Pair("Bilal Voice", "6.5k"),
          Pair("Ali Music", "11.2k")
      )

      LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxSize().testTag("rooms_grid")
      ) {
        items(rooms.size) { index ->
          val room = rooms[index]
          Box(
              modifier = Modifier
                  .height(210.dp)
                  .clip(RoundedCornerShape(16.dp))
                  .background(HoloSurface)
                  .clickable {
                    onJoinRoom(room.first, "${room.second} viewers", "https://picsum.photos/300/400?random=$index")
                  }
                  .testTag("room_item_$index")
          ) {
            AsyncImage(
                model = "https://picsum.photos/300/400?random=$index",
                contentDescription = room.first,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Live Badge
            Surface(
                color = HoloRed,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .padding(8.dp)
                    .align(Alignment.TopStart)
            ) {
              Text(
                  text = "LIVE",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }

            // Info at bottom
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(8.dp)
            ) {
              Text(
                  text = room.first,
                  color = HoloTextPrimary,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  maxLines = 1
              )
              Text(
                  text = "${room.second} viewers",
                  color = HoloTextSecondary,
                  fontSize = 11.sp
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun RoomActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, testTag: String) {
  Box(
      modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.5f))
          .testTag(testTag),
      contentAlignment = Alignment.Center
  ) {
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = tint,
        modifier = Modifier.size(18.dp)
    )
  }
}
