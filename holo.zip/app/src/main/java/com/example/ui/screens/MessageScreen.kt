package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary

data class Conversation(val id: Int, val name: String, val lastMessage: String, val time: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageScreen(
    onOpenChat: (String) -> Unit
) {
  val conversations = remember {
    listOf(
        Conversation(1, "Zoya Khan", "Hey, are you joining my live room tonight?", "2m ago"),
        Conversation(2, "Ali Ahmed", "Thanks for the gift! Appreciate it.", "15m ago"),
        Conversation(3, "Sara Malik", "Check out my new broadcast video.", "1h ago"),
        Conversation(4, "Hamza Ali", "Let's collab on a PK battle soon.", "3h ago"),
        Conversation(5, "Fatima Noor", "Hey, how are you doing?", "Yesterday")
    )
  }

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Messages", style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, color = HoloTextPrimary)) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black)
        )
      },
      containerColor = Color.Black
  ) { padding ->
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .testTag("messages_list")
    ) {
      items(conversations) { convo ->
        ListItem(
            headlineContent = { Text(convo.name, color = HoloTextPrimary, fontWeight = FontWeight.Bold) },
            supportingContent = { Text(convo.lastMessage, color = HoloTextSecondary, fontSize = 13.sp, maxLines = 1) },
            leadingContent = {
              AsyncImage(
                  model = "https://randomuser.me/api/portraits/men/${convo.id + 10}.jpg",
                  contentDescription = convo.name,
                  modifier = Modifier
                      .size(50.dp)
                      .clip(CircleShape),
                  contentScale = ContentScale.Crop
              )
            },
            trailingContent = { Text(convo.time, color = HoloTextSecondary, fontSize = 11.sp) },
            colors = ListItemDefaults.colors(containerColor = Color.Black),
            modifier = Modifier
                .clickable { onOpenChat(convo.name) }
                .testTag("conversation_item_${convo.id}")
        )
      }
    }
  }
}
