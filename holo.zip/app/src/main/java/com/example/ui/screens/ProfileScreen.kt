package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloRed
import com.example.ui.theme.HoloSurface
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary
import com.google.firebase.auth.FirebaseAuth

@Composable
fun ProfileScreen(
    onLogout: () -> Unit
) {
  val currentUser = FirebaseAuth.getInstance().currentUser
  val userEmail = currentUser?.email ?: "@muzzamil_holo"

  Scaffold(
      containerColor = Color.Black
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(24.dp)
            .testTag("profile_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(20.dp))

      // Avatar
      Box(contentAlignment = Alignment.BottomEnd) {
        AsyncImage(
            model = "https://randomuser.me/api/portraits/men/32.jpg",
            contentDescription = "Profile Avatar",
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
        Surface(
            color = HoloCyan,
            shape = CircleShape,
            modifier = Modifier.size(32.dp)
        ) {
          IconButton(onClick = { /* Edit profile photo */ }, modifier = Modifier.testTag("edit_avatar_btn")) {
            Icon(Icons.Default.Edit, contentDescription = "Edit photo", tint = Color.Black, modifier = Modifier.size(16.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
          text = currentUser?.displayName ?: "Muzzamil Ali",
          style = TextStyle(color = HoloTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
      )
      Text(
          text = userEmail,
          style = TextStyle(color = HoloTextSecondary, fontSize = 14.sp)
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Stats row
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
      ) {
        ProfileStatItem(title = "Following", count = "120", testTag = "stat_following")
        ProfileStatItem(title = "Followers", count = "45.2K", testTag = "stat_followers")
        ProfileStatItem(title = "Likes", count = "1.2M", testTag = "stat_likes")
      }

      Spacer(modifier = Modifier.height(30.dp))

      // Wallet Card
      Card(
          colors = CardDefaults.cardColors(containerColor = HoloSurface),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
              .fillMaxWidth()
              .testTag("wallet_card")
      ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Diamond, contentDescription = "Diamonds", tint = HoloCyan, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("My Diamonds", color = HoloTextSecondary, fontSize = 12.sp)
              Text("12,450 💎", color = HoloTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
          }
          Button(
              onClick = { /* Top up */ },
              colors = ButtonDefaults.buttonColors(containerColor = HoloCyan),
              modifier = Modifier.testTag("top_up_btn")
          ) {
            Text("Top Up", color = Color.Black, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Menu options
      ProfileMenuItem(icon = Icons.Default.Videocam, title = "My Live Broadcasts", testTag = "my_broadcasts_btn") {}
      ProfileMenuItem(icon = Icons.Default.Settings, title = "Settings & Privacy", testTag = "settings_btn") {}
      ProfileMenuItem(icon = Icons.Default.Logout, title = "Logout", tint = HoloRed, testTag = "logout_btn") {
        FirebaseAuth.getInstance().signOut()
        onLogout()
      }
    }
  }
}

@Composable
fun ProfileStatItem(title: String, count: String, testTag: String) {
  Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier.testTag(testTag)
  ) {
    Text(text = count, style = TextStyle(color = HoloTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold))
    Text(text = title, style = TextStyle(color = HoloTextSecondary, fontSize = 13.sp))
  }
}

@Composable
fun ProfileMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    tint: Color = HoloCyan,
    testTag: String,
    onClick: () -> Unit
) {
  Surface(
      color = HoloSurface,
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
          .clickable(onClick = onClick)
          .testTag(testTag)
  ) {
    Row(
        modifier = Modifier.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
      Spacer(modifier = Modifier.width(16.dp))
      Text(text = title, color = if (tint == HoloRed) HoloRed else HoloTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
  }
}
