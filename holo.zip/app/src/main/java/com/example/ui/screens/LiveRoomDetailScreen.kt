package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloRed
import com.example.ui.theme.HoloSurface
import com.example.ui.theme.HoloSurfaceVariant
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary
import com.example.ui.theme.HoloYellow

data class ChatMessage(val user: String, val message: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveRoomDetailScreen(
    roomTitle: String,
    viewerCount: String,
    streamImageUrl: String,
    onBack: () -> Unit
) {
  var chatInput by remember { mutableStateOf("") }
  var messages = remember {
    mutableStateListOf(
        ChatMessage("Ayesha", "Welcome everyone to the stream! ❤️"),
        ChatMessage("Ali", "Amazing voice! 🔥"),
        ChatMessage("Zainab", "Hello from Islamabad!"),
        ChatMessage("Hassan", "Sent a Diamond 💎")
    )
  }
  var likesCount by remember { mutableStateOf(1420) }
  var showGiftDialog by remember { mutableStateOf(false) }
  var giftMessage by remember { mutableStateOf<String?>(null) }

  Box(
      modifier = Modifier
          .fillMaxSize()
          .background(Color.Black)
          .testTag("live_room_detail_screen")
  ) {
    // Stream background
    AsyncImage(
        model = streamImageUrl,
        contentDescription = roomTitle,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )

    // Dark gradient overlay
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
    )

    // Top Header & Host Info
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          AsyncImage(
              model = "https://randomuser.me/api/portraits/women/44.jpg",
              contentDescription = "Host",
              modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape),
              contentScale = ContentScale.Crop
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
                text = roomTitle,
                color = HoloTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = viewerCount,
                color = HoloTextSecondary,
                fontSize = 12.sp
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Button(
              onClick = { /* Follow host */ },
              colors = ButtonDefaults.buttonColors(containerColor = HoloCyan),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
              modifier = Modifier.height(30.dp).testTag("follow_host_btn")
          ) {
            Text("Follow", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }

        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .testTag("close_room_btn")
        ) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
        }
      }

      Spacer(modifier = Modifier.weight(1f))

      // Gift Banner Alert if sent
      giftMessage?.let {
        Surface(
            color = HoloYellow.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("gift_banner")
        ) {
          Text(
              text = it,
              color = Color.Black,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              modifier = Modifier.padding(12.dp)
          )
        }
      }

      // Live Chat Messages List
      LazyColumn(
          modifier = Modifier
              .fillMaxWidth()
              .height(220.dp)
              .padding(horizontal = 16.dp)
              .testTag("live_chat_list"),
          verticalArrangement = Arrangement.spacedBy(8.dp),
          reverseLayout = true
      ) {
        items(messages.reversed()) { msg ->
          Row(
              modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color.Black.copy(alpha = 0.5f))
                  .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
                text = "${msg.user}: ",
                color = HoloCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = msg.message,
                color = HoloTextPrimary,
                fontSize = 13.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Bottom Interaction Bar
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .background(Color.Black.copy(alpha = 0.8f))
              .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
            value = chatInput,
            onValueChange = { chatInput = it },
            placeholder = { Text("Say something...", color = HoloTextSecondary, fontSize = 13.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = HoloCyan,
                unfocusedBorderColor = HoloSurfaceVariant,
                focusedTextColor = HoloTextPrimary,
                unfocusedTextColor = HoloTextPrimary,
                cursorColor = HoloCyan
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("chat_input")
        )

        IconButton(
            onClick = {
              if (chatInput.isNotBlank()) {
                messages.add(ChatMessage("You", chatInput))
                chatInput = ""
              }
            },
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(HoloCyan)
                .testTag("send_chat_btn")
        ) {
          Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.Black)
        }

        IconButton(
            onClick = { showGiftDialog = true },
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(HoloSurfaceVariant)
                .testTag("open_gifts_btn")
        ) {
          Icon(Icons.Default.CardGiftcard, contentDescription = "Gifts", tint = HoloYellow)
        }

        IconButton(
            onClick = { likesCount++ },
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(HoloSurfaceVariant)
                .testTag("like_stream_btn")
        ) {
          Icon(Icons.Default.Favorite, contentDescription = "Like", tint = HoloRed)
        }
      }
    }

    // Gift Dialog
    if (showGiftDialog) {
      AlertDialog(
          onDismissRequest = { showGiftDialog = false },
          containerColor = HoloSurface,
          title = { Text("Send Virtual Gift", color = HoloTextPrimary, fontWeight = FontWeight.Bold) },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              GiftOptionItem("🌹 Red Rose (10 coins)", onClick = {
                giftMessage = "You sent a Red Rose 🌹 to Ayesha!"
                showGiftDialog = false
              })
              GiftOptionItem("💎 Diamond (100 coins)", onClick = {
                giftMessage = "You sent a Diamond 💎 to Ayesha!"
                showGiftDialog = false
              })
              GiftOptionItem("👑 Royal Crown (500 coins)", onClick = {
                giftMessage = "You sent a Royal Crown 👑 to Ayesha!"
                showGiftDialog = false
              })
              GiftOptionItem("🚀 Rocket (1000 coins)", onClick = {
                giftMessage = "You sent a Rocket 🚀 to Ayesha!"
                showGiftDialog = false
              })
            }
          },
          confirmButton = {
            TextButton(onClick = { showGiftDialog = false }) {
              Text("Cancel", color = HoloCyan)
            }
          }
      )
    }
  }
}

@Composable
fun GiftOptionItem(title: String, onClick: () -> Unit) {
  Row(
      modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .clickable(onClick = onClick)
          .background(HoloSurfaceVariant)
          .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = title, color = HoloTextPrimary, fontWeight = FontWeight.Medium, fontSize = 14.sp)
  }
}
