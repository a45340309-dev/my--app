package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloSurfaceVariant
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var isLogin by remember { mutableStateOf(true) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isLoading by remember { mutableStateOf(false) }

  val auth = FirebaseAuth.getInstance()

  fun authAction() {
    if (email.isBlank() || password.isBlank()) {
      errorMessage = "Please enter email and password"
      return
    }
    isLoading = true
    errorMessage = null
    if (isLogin) {
      auth.signInWithEmailAndPassword(email, password)
          .addOnCompleteListener { task ->
            isLoading = false
            if (task.isSuccessful) {
              onLoginSuccess()
            } else {
              errorMessage = task.exception?.localizedMessage ?: "Authentication failed"
            }
          }
    } else {
      auth.createUserWithEmailAndPassword(email, password)
          .addOnCompleteListener { task ->
            isLoading = false
            if (task.isSuccessful) {
              onLoginSuccess()
            } else {
              errorMessage = task.exception?.localizedMessage ?: "Registration failed"
            }
          }
    }
  }

  Box(
      modifier = Modifier
          .fillMaxSize()
          .background(Color.Black)
          .padding(25.dp)
          .testTag("login_screen"),
      contentAlignment = Alignment.Center
  ) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
      Text(
          text = if (isLogin) "Holo App - Login" else "Holo App - Register",
          style = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, color = HoloTextPrimary)
      )

      Spacer(modifier = Modifier.height(24.dp))

      OutlinedTextField(
          value = email,
          onValueChange = { email = it },
          label = { Text("Email", color = HoloTextSecondary) },
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = HoloCyan,
              unfocusedBorderColor = HoloSurfaceVariant,
              focusedTextColor = HoloTextPrimary,
              unfocusedTextColor = HoloTextPrimary,
              cursorColor = HoloCyan
          ),
          modifier = Modifier.fillMaxWidth().testTag("email_input")
      )

      Spacer(modifier = Modifier.height(12.dp))

      OutlinedTextField(
          value = password,
          onValueChange = { password = it },
          label = { Text("Password", color = HoloTextSecondary) },
          singleLine = true,
          visualTransformation = PasswordVisualTransformation(),
          colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = HoloCyan,
              unfocusedBorderColor = HoloSurfaceVariant,
              focusedTextColor = HoloTextPrimary,
              unfocusedTextColor = HoloTextPrimary,
              cursorColor = HoloCyan
          ),
          modifier = Modifier.fillMaxWidth().testTag("password_input")
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
      }

      Spacer(modifier = Modifier.height(24.dp))

      Button(
          onClick = { authAction() },
          colors = ButtonDefaults.buttonColors(containerColor = HoloCyan),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("auth_submit_btn")
      ) {
        if (isLoading) {
          CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
        } else {
          Text(
              text = if (isLogin) "LOGIN" else "REGISTER",
              color = Color.Black,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
          )
        }
      }

      TextButton(
          onClick = { isLogin = !isLogin },
          modifier = Modifier.testTag("toggle_auth_mode_btn")
      ) {
        Text(
            text = if (isLogin) "نیا اکاؤنٹ بنانا ہے؟" else "پہلے سے اکاؤنٹ ہے؟",
            color = HoloCyan,
            fontSize = 14.sp
        )
      }
    }
  }
}
