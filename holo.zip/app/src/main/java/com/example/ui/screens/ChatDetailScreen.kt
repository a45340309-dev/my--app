package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloSurface
import com.example.ui.theme.HoloSurfaceVariant
import com.example.ui.theme.HoloTextPrimary
import com.example.ui.theme.HoloTextSecondary

data class DirectMessage(val text: String, val isMe: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    contactName: String,
    onBack: () -> Unit
) {
  var messageInput by remember { mutableStateOf("") }
  var messages = remember {
    mutableStateListOf(
        DirectMessage("Hey! Are you joining my live room tonight?", false),
        DirectMessage("Yes definitely! Looking forward to it.", true),
        DirectMessage("Awesome, see you there!", false)
    )
  }

  Scaffold(
      topBar = {
        TopAppBar(
            title = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(contactName, style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp, color = HoloTextPrimary))
              }
            },
            navigationIcon = {
              IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_btn")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = HoloTextPrimary)
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black)
        )
      },
      containerColor = Color.Black
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .testTag("chat_detail_screen")
    ) {
      LazyColumn(
          modifier = Modifier
              .weight(1f)
              .fillMaxWidth()
              .padding(horizontal = 16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
          reverseLayout = true
      ) {
        items(messages.reversed()) { msg ->
          Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = if (msg.isMe) Arrangement.End else Arrangement.Start
          ) {
            Surface(
                color = if (msg.isMe) HoloCyan else HoloSurfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.widthIn(max = 280.dp)
            ) {
              Text(
                  text = msg.text,
                  color = if (msg.isMe) Color.Black else HoloTextPrimary,
                  fontSize = 14.sp,
                  modifier = Modifier.padding(12.dp)
              )
            }
          }
        }
      }

      // Input Row
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .background(HoloSurface)
              .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            placeholder = { Text("Type a message...", color = HoloTextSecondary, fontSize = 14.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = HoloCyan,
                unfocusedBorderColor = HoloSurfaceVariant,
                focusedTextColor = HoloTextPrimary,
                unfocusedTextColor = HoloTextPrimary,
                cursorColor = HoloCyan
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("direct_message_input")
        )

        IconButton(
            onClick = {
              if (messageInput.isNotBlank()) {
                messages.add(DirectMessage(messageInput, true))
                messageInput = ""
              }
            },
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(HoloCyan)
                .testTag("send_dm_btn")
        ) {
          Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.Black)
        }
      }
    }
  }
}
