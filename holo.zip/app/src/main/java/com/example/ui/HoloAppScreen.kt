package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import com.example.ui.screens.*
import com.example.ui.theme.HoloCyan
import com.example.ui.theme.HoloSurface
import com.google.firebase.auth.FirebaseAuth

data class RoomArgs(val title: String, val viewers: String, val imageUrl: String)

@Composable
fun HoloAppScreen() {
  val auth = FirebaseAuth.getInstance()
  var isLoggedIn by remember { mutableStateOf(auth.currentUser != null) }

  var selectedTab by remember { mutableIntStateOf(0) }
  var activeRoom by remember { mutableStateOf<RoomArgs?>(null) }
  var activeChatContact by remember { mutableStateOf<String?>(null) }

  if (!isLoggedIn) {
    LoginScreen(
        onLoginSuccess = { isLoggedIn = true }
    )
    return
  }

  // Handle system back button when inside a detail screen
  if (activeRoom != null) {
    BackHandler { activeRoom = null }
  } else if (activeChatContact != null) {
    BackHandler { activeChatContact = null }
  }

  Scaffold(
      bottomBar = {
        if (activeRoom == null && activeChatContact == null) {
          NavigationBar(
              containerColor = HoloSurface,
              modifier = Modifier.testTag("bottom_navigation_bar")
          ) {
            NavigationBarItem(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                icon = { Icon(Icons.Default.LiveTv, contentDescription = "Room") },
                label = { Text("Room") },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = HoloCyan,
                    indicatorColor = HoloCyan,
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                ),
                modifier = Modifier.testTag("nav_item_room")
            )
            NavigationBarItem(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                icon = { Icon(Icons.Default.Message, contentDescription = "Message") },
                label = { Text("Message") },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = HoloCyan,
                    indicatorColor = HoloCyan,
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                ),
                modifier = Modifier.testTag("nav_item_message")
            )
            NavigationBarItem(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                label = { Text("Profile") },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = HoloCyan,
                    indicatorColor = HoloCyan,
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                ),
                modifier = Modifier.testTag("nav_item_profile")
            )
          }
        }
      }
  ) { padding ->
    Box(modifier = Modifier.fillMaxSize().padding(padding)) {
      when {
        activeRoom != null -> {
          LiveRoomDetailScreen(
              roomTitle = activeRoom!!.title,
              viewerCount = activeRoom!!.viewers,
              streamImageUrl = activeRoom!!.imageUrl,
              onBack = { activeRoom = null }
          )
        }
        activeChatContact != null -> {
          ChatDetailScreen(
              contactName = activeChatContact!!,
              onBack = { activeChatContact = null }
          )
        }
        else -> {
          when (selectedTab) {
            0 -> RoomScreen(
                onJoinRoom = { title, viewers, imgUrl ->
                  activeRoom = RoomArgs(title, viewers, imgUrl)
                }
            )
            1 -> MessageScreen(
                onOpenChat = { contactName ->
                  activeChatContact = contactName
                }
            )
            2 -> ProfileScreen(
                onLogout = { isLoggedIn = false }
            )
          }
        }
      }
    }
  }
}
