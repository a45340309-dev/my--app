package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HoloCyan = Color(0xFF00D4FF)
val HoloRed = Color(0xFFFF3B30)
val HoloDarkBackground = Color(0xFF000000)
val HoloSurface = Color(0xFF1C1C1E)
val HoloSurfaceVariant = Color(0xFF2C2C2E)
val HoloTextPrimary = Color(0xFFFFFFFF)
val HoloTextSecondary = Color(0xFF8E8E93)
val HoloYellow = Color(0xFFFFCC00)
